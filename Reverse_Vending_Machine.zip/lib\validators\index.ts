import { z } from 'zod';

// Auth Validators
export const registerSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  mobile: z.string().regex(/^[6-9]\d{9}$/, 'Mobile must be a valid 10-digit Indian number'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/\d/, 'Password must contain at least one number'),
});

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

// Location Validators
export const locationSchema = z.object({
  state: z.string().min(1, 'State is required'),
  district: z.string().min(1, 'District is required'),
  area: z.string().min(1, 'Area is required'),
  exactLocation: z.string().min(1, 'Exact location details required'),
  gps: z.object({
    lat: z.number().min(-90).max(90),
    lng: z.number().min(-180).max(180),
  }),
  type: z.enum(['street', 'public_place', 'station', 'mall', 'airport', 'other']),
});

// Machine Validators
export const createMachineSchema = z.object({
  machineId: z.string().min(3, 'Machine ID is required (e.g. RVM-CBE-001)'),
  name: z.string().min(2, 'Machine name is required'),
  location: z.string().min(1, 'Location ID is required'),
  gps: z.object({
    lat: z.number(),
    lng: z.number(),
  }),
  storageCapacity: z.number().positive('Storage capacity must be a positive number'),
  assignedEmployee: z.string().optional(),
  installationDate: z.string().optional(),
});

export const updateMachineSchema = createMachineSchema.partial().extend({
  status: z.enum(['online', 'offline', 'active', 'full', 'under_maintenance', 'damaged', 'inactive']).optional(),
  connectivity: z.enum(['connected', 'disconnected']).optional(),
  sensorStatus: z.enum(['ok', 'error', 'unknown']).optional(),
  powerStatus: z.enum(['on', 'off', 'battery']).optional(),
});

// Employee Validators
export const createEmployeeSchema = z.object({
  name: z.string().min(2, 'Name is required'),
  email: z.string().email('Invalid email address'),
  mobile: z.string().regex(/^[6-9]\d{9}$/, 'Mobile must be a valid 10-digit Indian number'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  assignedMachines: z.array(z.string()).optional(),
});

export const updateEmployeeSchema = createEmployeeSchema.partial().extend({
  isActive: z.boolean().optional(),
});

// Transaction Validators
export const depositTransactionSchema = z.object({
  machineId: z.string().min(1, 'Machine ID is required'),
  bottlesDeposited: z.number().int().positive('Must deposit at least 1 bottle'),
});

// Green Coin Validators
export const redeemCoinsSchema = z.object({
  amount: z.number().positive('Redeem amount must be greater than 0'),
  note: z.string().optional(),
});

export const withdrawCoinsSchema = z.object({
  amount: z.number().positive('Withdraw amount must be greater than 0'),
  bankDetails: z.string().min(5, 'Bank or UPI details required'),
});

// Maintenance Validators
export const createMaintenanceSchema = z.object({
  machine: z.string().min(1, 'Machine ID is required'),
  employee: z.string().min(1, 'Employee ID is required'),
  serviceType: z.enum(['collection', 'repair', 'cleaning', 'inspection', 'other']),
  problemReported: z.string().optional(),
  remarks: z.string().optional(),
});

export const updateMaintenanceSchema = z.object({
  status: z.enum(['assigned', 'in_progress', 'completed', 'cancelled']),
  actionTaken: z.string().optional(),
  wasteCollected: z.number().nonnegative().optional(),
  remarks: z.string().optional(),
});

// Alert Validators
export const createAlertSchema = z.object({
  machine: z.string().min(1, 'Machine ID is required'),
  type: z.enum(['storage', 'maintenance', 'offline', 'error', 'service_required']),
  message: z.string().min(1, 'Alert message is required'),
  severity: z.enum(['info', 'warning', 'critical']),
  assignedEmployee: z.string().optional(),
});

export const updateAlertSchema = z.object({
  isResolved: z.boolean().optional(),
  assignedEmployee: z.string().optional(),
});

// IoT Ingestion Validator
export const iotTelemetrySchema = z.object({
  machineId: z.string().min(1, 'machineId is required'),
  bottlesDetected: z.number().int().nonnegative().optional(),
  currentStorageLevel: z.number().nonnegative(),
  sensorStatus: z.enum(['ok', 'error', 'unknown']).optional(),
  powerStatus: z.enum(['on', 'off', 'battery']).optional(),
  connectivity: z.enum(['connected', 'disconnected']).optional(),
  timestamp: z.string().optional(),
});
