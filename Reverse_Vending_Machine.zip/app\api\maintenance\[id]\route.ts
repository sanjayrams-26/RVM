import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Maintenance } from '@/models/Maintenance';
import { Machine } from '@/models/Machine';
import { Alert } from '@/models/Alert';
import { StorageLog } from '@/models/StorageLog';
import { requireRole } from '@/lib/rbac';
import { updateMaintenanceSchema } from '@/lib/validators';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase();
    const task = await Maintenance.findById(params.id)
      .populate('employee', 'name email employeeId mobile')
      .populate({
        path: 'machine',
        populate: { path: 'location' },
      });

    if (!task) {
      return NextResponse.json(
        { error: { message: 'Maintenance record not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    return NextResponse.json({ task });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin', 'employee']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const body = await req.json();
    const validatedData = updateMaintenanceSchema.parse(body);

    const task = await Maintenance.findById(params.id);
    if (!task) {
      return NextResponse.json(
        { error: { message: 'Maintenance task not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    if (validatedData.status) task.status = validatedData.status;
    if (validatedData.actionTaken) task.actionTaken = validatedData.actionTaken;
    if (validatedData.wasteCollected !== undefined) task.wasteCollected = validatedData.wasteCollected;
    if (validatedData.remarks) task.remarks = validatedData.remarks;

    if (validatedData.status === 'completed') {
      task.completionTime = new Date();

      // If service type was collection or repair, reset storage & machine status
      const machine = await Machine.findById(task.machine);
      if (machine) {
        if (task.serviceType === 'collection') {
          machine.currentStorageLevel = 0;
          machine.status = 'active';
        } else if (machine.status === 'full' || machine.status === 'under_maintenance') {
          machine.status = 'active';
        }

        machine.lastMaintenanceDate = new Date();
        // Calculate next maintenance date (+30 days default)
        const nextDate = new Date();
        nextDate.setDate(nextDate.getDate() + 30);
        machine.nextMaintenanceDate = nextDate;

        await machine.save();

        // Log storage reset snapshot
        await StorageLog.create({
          machine: machine._id,
          storageLevel: machine.currentStorageLevel,
          storagePercent: 0,
          timestamp: new Date(),
        });

        // Resolve storage alerts for this machine
        await Alert.updateMany(
          { machine: machine._id, isResolved: false, type: { $in: ['storage', 'maintenance'] } },
          { isResolved: true, resolvedAt: new Date() }
        );
      }
    }

    await task.save();

    const updatedTask = await Maintenance.findById(params.id)
      .populate('employee', 'name email employeeId mobile')
      .populate({
        path: 'machine',
        populate: { path: 'location' },
      });

    return NextResponse.json({ success: true, task: updatedTask });
  } catch (error) {
    return handleApiError(error);
  }
}
