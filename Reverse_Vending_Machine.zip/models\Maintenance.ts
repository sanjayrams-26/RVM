import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IMaintenance extends Document {
  machine: mongoose.Types.ObjectId;
  employee: mongoose.Types.ObjectId;
  serviceDate: Date;
  serviceType: 'collection' | 'repair' | 'cleaning' | 'inspection' | 'other';
  problemReported?: string;
  actionTaken?: string;
  wasteCollected?: number;
  completionTime?: Date;
  remarks?: string;
  status: 'assigned' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}

const MaintenanceSchema = new Schema<IMaintenance>(
  {
    machine: { type: Schema.Types.ObjectId, ref: 'Machine', required: true },
    employee: { type: Schema.Types.ObjectId, ref: 'Employee', required: true },
    serviceDate: { type: Date, default: Date.now },
    serviceType: {
      type: String,
      enum: ['collection', 'repair', 'cleaning', 'inspection', 'other'],
      default: 'collection',
    },
    problemReported: String,
    actionTaken: String,
    wasteCollected: Number,
    completionTime: Date,
    remarks: String,
    status: {
      type: String,
      enum: ['assigned', 'in_progress', 'completed', 'cancelled'],
      default: 'assigned',
    },
  },
  { timestamps: true }
);

MaintenanceSchema.index({ machine: 1, createdAt: -1 });
MaintenanceSchema.index({ employee: 1, status: 1 });

export const Maintenance: Model<IMaintenance> =
  mongoose.models.Maintenance ||
  mongoose.model<IMaintenance>('Maintenance', MaintenanceSchema);
