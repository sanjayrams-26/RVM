import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Location } from '@/models/Location';
import { Machine } from '@/models/Machine';
import { requireRole } from '@/lib/rbac';
import { locationSchema } from '@/lib/validators';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase();
    const location = await Location.findById(params.id);
    if (!location) {
      return NextResponse.json(
        { error: { message: 'Location not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }
    return NextResponse.json({ location });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const body = await req.json();
    const validatedData = locationSchema.partial().parse(body);

    const location = await Location.findByIdAndUpdate(params.id, validatedData, { new: true });
    if (!location) {
      return NextResponse.json(
        { error: { message: 'Location not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }
    return NextResponse.json({ success: true, location });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();

    // Check dependent machines
    const dependentCount = await Machine.countDocuments({ location: params.id });
    if (dependentCount > 0) {
      return NextResponse.json(
        {
          error: {
            message: `Cannot delete location. There are ${dependentCount} machine(s) linked to this location.`,
            code: 'DEPENDENCY_EXISTS',
          },
        },
        { status: 400 }
      );
    }

    const location = await Location.findByIdAndDelete(params.id);
    if (!location) {
      return NextResponse.json(
        { error: { message: 'Location not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, message: 'Location deleted successfully' });
  } catch (error) {
    return handleApiError(error);
  }
}
