'use client';

import React from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { Wrench, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function EmployeeTasksPage() {
  const { data: meData } = useSWR('/api/auth/me', fetcher);
  const employeeId = meData?.user?.id;

  const { data: tasksData, isLoading } = useSWR(
    employeeId ? `/api/employees/${employeeId}/tasks` : null,
    fetcher
  );

  const tasks = tasksData?.tasks || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-slate-900">Assigned Service Tasks</h1>
        <p className="text-xs text-slate-500 mt-1">Accept, update progress, and log waste collection details for assigned RVM units</p>
      </div>

      <Card>
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading tasks...</div>
        ) : tasks.length === 0 ? (
          <div className="text-center py-12 text-slate-400">No service tasks assigned.</div>
        ) : (
          <div className="space-y-4">
            {tasks.map((t: any) => (
              <div key={t._id} className="p-4 rounded-2xl border border-slate-200 bg-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-xs font-black uppercase text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      {t.serviceType}
                    </span>
                    <span className="text-xs font-bold text-slate-500 uppercase">• {t.status}</span>
                  </div>
                  <h3 className="font-extrabold text-slate-800 text-base">{t.machine?.machineId} ({t.machine?.name})</h3>
                  <p className="text-xs text-slate-500 mt-0.5">{t.machine?.location?.district}, {t.machine?.location?.area}</p>
                </div>

                <Link href={`/employee/tasks/${t._id}`}>
                  <Button size="sm" className="bg-amber-600 hover:bg-amber-700 text-white font-bold">
                    Open Task <ArrowRight className="w-3.5 h-3.5 ml-1" />
                  </Button>
                </Link>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
