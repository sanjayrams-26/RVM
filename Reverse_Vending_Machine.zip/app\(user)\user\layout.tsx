import React from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { Sidebar } from '@/components/layout/Sidebar';
import { getSessionFromCookies } from '@/lib/auth';

export default function UserLayout({ children }: { children: React.ReactNode }) {
  const session = getSessionFromCookies();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar userName={session?.name || 'Recycler User'} role="user" />
      <div className="flex flex-1">
        <Sidebar role="user" />
        <main className="flex-1 p-6 lg:p-8 max-w-7xl mx-auto w-full">{children}</main>
      </div>
    </div>
  );
}
