import React from 'react';
import Link from 'next/link';
import { Recycle, CheckCircle2, ArrowLeft } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-slate-50 py-12 px-6 lg:px-12 max-w-4xl mx-auto">
      <Link href="/" className="inline-flex items-center text-sm font-semibold text-emerald-600 hover:text-emerald-700 mb-8">
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Home
      </Link>

      <div className="bg-white p-8 sm:p-12 rounded-3xl border border-slate-200 shadow-sm">
        <div className="w-14 h-14 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-600 mb-6">
          <Recycle className="w-8 h-8" />
        </div>

        <h1 className="text-3xl font-black text-slate-900 mb-4">About RVM Green Coin Platform</h1>
        <p className="text-base text-slate-600 leading-relaxed mb-8">
          The IoT Reverse Vending Machine (RVM) Management Platform is an end-to-end smart city initiative designed to incentivize plastic bottle recycling. By integrating physical IoT sensors with web technologies, our network empowers citizens to turn plastic waste into digital rewards.
        </p>

        <h3 className="text-xl font-bold text-slate-800 mb-4">Core Objectives</h3>
        <ul className="space-y-4 text-slate-600 text-sm mb-8">
          <li className="flex items-start">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 mr-3 flex-shrink-0 mt-0.5" />
            <span><strong>Automated Waste Collection:</strong> Live sensors continuously stream storage levels and alert field crews before overflow occurs.</span>
          </li>
          <li className="flex items-start">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 mr-3 flex-shrink-0 mt-0.5" />
            <span><strong>Direct Financial Incentives:</strong> Citizens earn 5 Green Coins per plastic bottle deposited, withdrawable to UPI/Bank accounts.</span>
          </li>
          <li className="flex items-start">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 mr-3 flex-shrink-0 mt-0.5" />
            <span><strong>District-Level Analytics:</strong> Real-time operational monitoring for municipal waste administrators across Tamil Nadu.</span>
          </li>
        </ul>

        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6">
          <h4 className="text-sm font-bold text-emerald-900 mb-1">Security & Data Privacy Note</h4>
          <p className="text-xs text-emerald-700">
            All user authentication uses encrypted httpOnly JWT session cookies and bcrypt password hashing. MongoDB Atlas connections are secured using environment variable parameterization.
          </p>
        </div>
      </div>
    </div>
  );
}
