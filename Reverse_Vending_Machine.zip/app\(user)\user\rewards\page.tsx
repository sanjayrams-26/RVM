'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { Gift, Wallet, ArrowUpRight, ArrowDownLeft, Coins, CheckCircle2 } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function UserRewardsPage() {
  const { data: balanceData, mutate: mutateBalance } = useSWR('/api/greencoins/balance', fetcher);
  const { data: historyData, mutate: mutateHistory } = useSWR('/api/greencoins/history', fetcher);

  const [isRedeemOpen, setIsRedeemOpen] = useState(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);

  const [redeemAmount, setRedeemAmount] = useState(50);
  const [withdrawAmount, setWithdrawAmount] = useState(100);
  const [bankDetails, setBankDetails] = useState('');

  const [statusMsg, setStatusMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const balance = balanceData?.balance ?? 0;
  const ledger = historyData?.ledger || [];

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setStatusMsg('');

    try {
      const res = await fetch('/api/greencoins/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: Number(redeemAmount), note: 'Voucher Redemption' }),
      });

      const data = await res.json();
      if (!res.ok) {
        setStatusMsg(data.error?.message || 'Redemption failed');
      } else {
        setStatusMsg('Success! Voucher code generated.');
        mutateBalance();
        mutateHistory();
        setTimeout(() => {
          setIsRedeemOpen(false);
          setStatusMsg('');
        }, 1500);
      }
    } catch {
      setStatusMsg('An error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setStatusMsg('');

    try {
      const res = await fetch('/api/greencoins/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: Number(withdrawAmount), bankDetails }),
      });

      const data = await res.json();
      if (!res.ok) {
        setStatusMsg(data.error?.message || 'Withdrawal failed');
      } else {
        setStatusMsg('Withdrawal request submitted!');
        mutateBalance();
        mutateHistory();
        setTimeout(() => {
          setIsWithdrawOpen(false);
          setStatusMsg('');
        }, 1500);
      }
    } catch {
      setStatusMsg('An error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-black text-slate-900">Green Coins & Rewards</h1>
        <p className="text-xs text-slate-500 mt-1">
          Redeem earned Green Coins for partner eco-vouchers or direct payouts
        </p>
      </div>

      {/* Balance Card Banner */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-3xl p-8 text-white flex flex-col md:flex-row items-center justify-between shadow-xl shadow-emerald-100">
        <div>
          <p className="text-xs font-extrabold uppercase tracking-widest text-emerald-200">Current Balance</p>
          <h2 className="text-4xl font-black mt-1">{balance} Coins</h2>
          <p className="text-xs text-emerald-100 mt-1">1 Bottle = 5 Green Coins (approx ₹1.00 value)</p>
        </div>

        <div className="mt-6 md:mt-0 flex space-x-3">
          <Button
            onClick={() => {
              setStatusMsg('');
              setIsRedeemOpen(true);
            }}
            className="bg-white text-emerald-800 hover:bg-emerald-50 font-bold border-0"
          >
            <Gift className="w-4 h-4 mr-2 text-emerald-600" /> Redeem Voucher
          </Button>
          <Button
            onClick={() => setIsWithdrawOpen(true)}
            className="bg-emerald-800 hover:bg-emerald-900 text-white font-bold border-0"
          >
            <Wallet className="w-4 h-4 mr-2" /> Direct Cashout
          </Button>
        </div>
      </div>

      {/* Ledger History */}
      <Card title="Green Coins Ledger" subtitle="Detailed audit record of earnings, redemptions, and withdrawals">
        {ledger.length === 0 ? (
          <div className="text-center py-12 text-slate-400">No ledger entries recorded.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4">Type</th>
                  <th className="py-3.5 px-4">Details / Note</th>
                  <th className="py-3.5 px-4 text-right">Amount</th>
                  <th className="py-3.5 px-4 text-right">Balance After</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {ledger.map((entry: any) => (
                  <tr key={entry._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 text-slate-600 font-medium">
                      {new Date(entry.createdAt).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`text-xs font-bold px-2.5 py-1 rounded-full uppercase border ${
                          entry.type === 'earn'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : entry.type === 'redeem'
                            ? 'bg-amber-50 text-amber-700 border-amber-200'
                            : 'bg-indigo-50 text-indigo-700 border-indigo-200'
                        }`}
                      >
                        {entry.type}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-700">{entry.note || '-'}</td>
                    <td
                      className={`py-3.5 px-4 text-right font-black ${
                        entry.amount > 0 ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {entry.amount > 0 ? `+${entry.amount}` : entry.amount}
                    </td>
                    <td className="py-3.5 px-4 text-right font-semibold text-slate-800">
                      {entry.balanceAfter ?? '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Redeem Voucher Modal */}
      <Modal isOpen={isRedeemOpen} onClose={() => setIsRedeemOpen(false)} title="Redeem Green Coins Voucher">
        <form onSubmit={handleRedeem} className="space-y-4">
          {statusMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center justify-between">
              <span>{statusMsg}</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Select Voucher Tier</label>
            <select
              value={redeemAmount}
              onChange={(e) => setRedeemAmount(Number(e.target.value))}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white font-medium"
            >
              <option value={50}>50 Coins (₹10 Supermarket Voucher)</option>
              <option value={100}>100 Coins (₹25 Coffee Pass)</option>
              <option value={250}>250 Coins (₹60 Eco Store Credit)</option>
              <option value={500}>500 Coins (₹150 Bus Transit Pass)</option>
            </select>
          </div>

          <p className="text-xs text-slate-500">
            Current Balance: <strong>{balance} Coins</strong>
          </p>

          <Button type="submit" isLoading={isLoading} className="w-full py-3">
            Confirm & Redeem Voucher
          </Button>
        </form>
      </Modal>

      {/* Withdraw Modal */}
      <Modal isOpen={isWithdrawOpen} onClose={() => setIsWithdrawOpen(false)} title="Direct UPI / Bank Cashout">
        <form onSubmit={handleWithdraw} className="space-y-4">
          {statusMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl">
              {statusMsg}
            </div>
          )}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Coins to Withdraw</label>
            <input
              type="number"
              min={50}
              step={10}
              required
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(Number(e.target.value))}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">UPI ID / Bank Details</label>
            <input
              type="text"
              required
              placeholder="user@upi or Account No & IFSC"
              value={bankDetails}
              onChange={(e) => setBankDetails(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <Button type="submit" isLoading={isLoading} className="w-full py-3">
            Submit Cashout Request
          </Button>
        </form>
      </Modal>
    </div>
  );
}
