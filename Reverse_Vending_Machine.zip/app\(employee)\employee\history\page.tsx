'use client';

import React from 'react';
import useSWR from 'swr';
import { History, CheckCircle2 } from 'lucide-react';
import { Card } from '@/components/ui/Card';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function EmployeeHistoryPage() {
  const { data: meData } = useSWR('/api/auth/me', fetcher);
  const employeeId = meData?.user?.id;

  const { data: tasksData, isLoading } = useSWR(
    employeeId ? `/api/employees/${employeeId}/tasks` : null,
    fetcher
  );

  const tasks = tasksData?.tasks || [];
  const completedTasks = tasks.filter((t: any) => t.status === 'completed');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-slate-900">Completed Service History</h1>
        <p className="text-xs text-slate-500 mt-1">Audit log of all completed collections and repairs</p>
      </div>

      <Card>
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading history...</div>
        ) : completedTasks.length === 0 ? (
          <div className="text-center py-12 text-slate-400">No completed tasks yet.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">Completion Date</th>
                  <th className="py-3.5 px-4">Machine ID</th>
                  <th className="py-3.5 px-4">Action Type</th>
                  <th className="py-3.5 px-4">Waste Collected</th>
                  <th className="py-3.5 px-4">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {completedTasks.map((t: any) => (
                  <tr key={t._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-medium text-slate-700">
                      {new Date(t.completionTime || t.updatedAt).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-800">{t.machine?.machineId}</td>
                    <td className="py-3.5 px-4 uppercase text-xs font-bold text-amber-700">{t.serviceType}</td>
                    <td className="py-3.5 px-4 font-bold text-emerald-600">
                      {t.wasteCollected ? `${t.wasteCollected} bottles` : '-'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">{t.remarks || t.actionTaken || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
