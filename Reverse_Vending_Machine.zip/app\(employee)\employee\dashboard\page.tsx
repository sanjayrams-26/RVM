'use client';

import React from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { Wrench, AlertTriangle, CheckCircle2, Cpu, ArrowRight } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function EmployeeDashboardPage() {
  const { data: meData } = useSWR('/api/auth/me', fetcher);
  const employeeId = meData?.user?.id;

  const { data: tasksData, isLoading } = useSWR(
    employeeId ? `/api/employees/${employeeId}/tasks` : null,
    fetcher
  );

  const tasks = tasksData?.tasks || [];
  const alerts = tasksData?.alerts || [];
  const assignedMachines = meData?.profile?.assignedMachines || [];

  const pendingTasks = tasks.filter((t: any) => t.status !== 'completed' && t.status !== 'cancelled');

  return (
    <div className="space-y-6">
      {/* Mobile Top Header Banner */}
      <div className="bg-gradient-to-r from-amber-600 to-amber-700 rounded-3xl p-6 text-white shadow-lg shadow-amber-100">
        <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider">
          Field Technician Portal
        </span>
        <h1 className="text-2xl font-black mt-2">Today's Service Overview</h1>
        <p className="text-amber-100 text-xs mt-1">
          {pendingTasks.length} pending service task(s) • {alerts.length} active alert(s) requiring attention
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-amber-50/50 border-amber-200/60">
          <p className="text-xs font-bold text-slate-500 uppercase">Assigned RVM Units</p>
          <h3 className="text-2xl font-black text-amber-800 mt-1">{assignedMachines.length}</h3>
        </Card>
        <Card className="bg-rose-50/50 border-rose-200/60">
          <p className="text-xs font-bold text-slate-500 uppercase">Pending Service Tasks</p>
          <h3 className="text-2xl font-black text-rose-700 mt-1">{pendingTasks.length}</h3>
        </Card>
      </div>

      {/* Active Work Orders / Tasks */}
      <Card title="Today's Work Orders" subtitle="Assigned collections, bin resets, and maintenance tasks">
        {isLoading ? (
          <div className="text-center py-8 text-slate-400">Loading work orders...</div>
        ) : tasks.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-50" />
            <p className="font-bold text-slate-700 text-sm">No work orders assigned currently.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {tasks.map((task: any) => (
              <div
                key={task._id}
                className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-amber-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
              >
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-xs font-extrabold uppercase px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                      {task.serviceType}
                    </span>
                    <span
                      className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        task.status === 'completed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {task.status}
                    </span>
                  </div>
                  <h4 className="font-bold text-slate-800 text-sm">
                    {task.machine?.machineId} ({task.machine?.location?.district} - {task.machine?.location?.area})
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">{task.problemReported || 'Scheduled routine service'}</p>
                </div>

                <Link href={`/employee/tasks/${task._id}`}>
                  <Button size="sm" className="w-full sm:w-auto bg-amber-600 hover:bg-amber-700 text-white font-bold">
                    Execute Work Order <ArrowRight className="w-3.5 h-3.5 ml-1" />
                  </Button>
                </Link>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
