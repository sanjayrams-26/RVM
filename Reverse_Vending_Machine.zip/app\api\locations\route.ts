import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Location } from '@/models/Location';
import { MOCK_LOCATIONS } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();
    const dbLocs = await Location.find().sort({ district: 1, area: 1 });
    if (dbLocs.length > 0) {
      return NextResponse.json({ locations: dbLocs });
    }
  } catch (e) {
    console.warn('Serving mock locations fallback');
  }

  return NextResponse.json({ locations: MOCK_LOCATIONS });
}

export async function POST(req: NextRequest) {
  try {
    await connectToDatabase();
    const body = await req.json();
    const location = await Location.create(body);
    return NextResponse.json({ success: true, location }, { status: 201 });
  } catch (e) {
    const body = await req.json();
    const mockLoc = { _id: `loc_${Date.now()}`, ...body };
    MOCK_LOCATIONS.push(mockLoc);
    return NextResponse.json({ success: true, location: mockLoc }, { status: 201 });
  }
}
