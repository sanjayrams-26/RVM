'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { BarChart3, Download, Calendar, Filter, FileText } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminReportsPage() {
  const [activeTab, setActiveTab] = useState<'district' | 'machine' | 'weekly'>('district');

  const { data: districtData } = useSWR('/api/reports/district-wise', fetcher);
  const { data: machineData } = useSWR('/api/reports/machine-performance', fetcher);
  const { data: weeklyData } = useSWR('/api/reports/weekly', fetcher);

  const handleExport = (type: string) => {
    window.open(`/api/reports/export?type=${type}`, '_blank');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">Analytics & CSV Reports</h1>
          <p className="text-xs text-slate-500 mt-1">Export district performance summaries, machine metrics, and deposit audit trails</p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={() => handleExport('district')} size="sm" variant="outline">
            <Download className="w-4 h-4 mr-1.5" /> District CSV
          </Button>
          <Button onClick={() => handleExport('machines')} size="sm" variant="outline">
            <Download className="w-4 h-4 mr-1.5" /> Machines CSV
          </Button>
        </div>
      </div>

      {/* Tabs Header */}
      <div className="flex space-x-2 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('district')}
          className={`pb-3 px-4 font-bold text-sm border-b-2 transition-colors ${
            activeTab === 'district'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          District Performance
        </button>
        <button
          onClick={() => setActiveTab('machine')}
          className={`pb-3 px-4 font-bold text-sm border-b-2 transition-colors ${
            activeTab === 'machine'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          Machine Fleet Metrics
        </button>
        <button
          onClick={() => setActiveTab('weekly')}
          className={`pb-3 px-4 font-bold text-sm border-b-2 transition-colors ${
            activeTab === 'weekly'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          7-Day Trend
        </button>
      </div>

      {activeTab === 'district' && (
        <Card title="District Collection Aggregation">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">District</th>
                  <th className="py-3.5 px-4">Active RVM Machines</th>
                  <th className="py-3.5 px-4">Total Bottles Recycled</th>
                  <th className="py-3.5 px-4 text-right">Green Coins Generated</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {(districtData?.report || []).map((row: any) => (
                  <tr key={row.district} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-extrabold text-slate-800">{row.district}</td>
                    <td className="py-3.5 px-4 font-semibold text-slate-700">{row.totalMachines} units</td>
                    <td className="py-3.5 px-4 font-bold text-emerald-700">{row.totalBottlesCollected} bottles</td>
                    <td className="py-3.5 px-4 text-right font-black text-indigo-600">{row.totalGreenCoinsGenerated} Coins</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {activeTab === 'machine' && (
        <Card title="Machine Performance Metrics">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">Machine ID</th>
                  <th className="py-3.5 px-4">District / Area</th>
                  <th className="py-3.5 px-4">Fill Level</th>
                  <th className="py-3.5 px-4">Total Bottles</th>
                  <th className="py-3.5 px-4">Assigned Tech</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {(machineData?.report || []).map((m: any) => (
                  <tr key={m.machineId} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-extrabold text-slate-800">{m.machineId}</td>
                    <td className="py-3.5 px-4 text-slate-600">{m.district}, {m.area}</td>
                    <td className="py-3.5 px-4 font-bold text-slate-700">{m.storagePercent}%</td>
                    <td className="py-3.5 px-4 font-bold text-emerald-600">{m.bottlesCollectedTotal}</td>
                    <td className="py-3.5 px-4 text-slate-600">{m.assignedEmployee}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {activeTab === 'weekly' && (
        <Card title="7-Day Trend Breakdown">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4">Total Transactions</th>
                  <th className="py-3.5 px-4">Bottles Recycled</th>
                  <th className="py-3.5 px-4 text-right">Coins Issued</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {(weeklyData?.report || []).map((w: any) => (
                  <tr key={w.date} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-800">{w.date}</td>
                    <td className="py-3.5 px-4 font-medium text-slate-700">{w.totalTransactions}</td>
                    <td className="py-3.5 px-4 font-bold text-emerald-600">{w.totalBottles} bottles</td>
                    <td className="py-3.5 px-4 text-right font-black text-indigo-600">{w.totalCoins} Coins</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
