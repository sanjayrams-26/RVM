'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ArrowLeft, CheckCircle2, Wrench, MapPin, Truck } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function EmployeeTaskExecutionPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { data, mutate } = useSWR(`/api/maintenance/${params.id}`, fetcher);
  const task = data?.task;

  const [status, setStatus] = useState('');
  const [actionTaken, setActionTaken] = useState('');
  const [wasteCollected, setWasteCollected] = useState(0);
  const [remarks, setRemarks] = useState('');

  const [statusMsg, setStatusMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  React.useEffect(() => {
    if (task) {
      setStatus(task.status || 'assigned');
      setActionTaken(task.actionTaken || '');
      setWasteCollected(task.wasteCollected || task.machine?.currentStorageLevel || 0);
      setRemarks(task.remarks || '');
    }
  }, [task]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setStatusMsg('');

    try {
      const res = await fetch(`/api/maintenance/${params.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          actionTaken,
          wasteCollected: Number(wasteCollected),
          remarks,
        }),
      });

      const resData = await res.json();
      if (!res.ok) {
        setStatusMsg(resData.error?.message || 'Failed to update work order');
      } else {
        setStatusMsg('Work order updated successfully!');
        mutate();
        if (status === 'completed') {
          setTimeout(() => {
            router.push('/employee/tasks');
          }, 1500);
        }
      }
    } catch {
      setStatusMsg('An error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!task) {
    return <div className="p-8 text-center text-slate-500">Loading work order details...</div>;
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <Link href="/employee/tasks" className="inline-flex items-center text-xs font-bold text-amber-700 hover:text-amber-800">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to Service Tasks
      </Link>

      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black uppercase text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
            Service Type: {task.serviceType}
          </span>
          <span className="text-xs font-bold uppercase text-slate-500">Status: {task.status}</span>
        </div>

        <h1 className="text-2xl font-black text-slate-900">{task.machine?.machineId} ({task.machine?.name})</h1>
        <p className="text-xs text-slate-600 font-medium">
          📍 {task.machine?.location?.district}, {task.machine?.location?.area} - {task.machine?.location?.exactLocation}
        </p>
      </div>

      <Card title="Technician Service Completion Form">
        {statusMsg && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center">
            <CheckCircle2 className="w-4 h-4 mr-2" /> {statusMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Work Order Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
            >
              <option value="assigned">Assigned</option>
              <option value="in_progress">En Route / In Progress</option>
              <option value="completed font-bold">Completed & Reset Capacity</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Action Taken Details</label>
            <textarea
              rows={3}
              required
              placeholder="Emptied bin storage, verified optic sensor alignment, cleaned conveyor..."
              value={actionTaken}
              onChange={(e) => setActionTaken(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {task.serviceType === 'collection' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Plastic Bottles Collected Count</label>
              <input
                type="number"
                required
                value={wasteCollected}
                onChange={(e) => setWasteCollected(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <p className="text-[11px] text-amber-700 font-semibold mt-1">
                Note: Completing collection resets machine storage fill level to 0 bottles.
              </p>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Technician Remarks</label>
            <input
              type="text"
              placeholder="Machine operating in 100% healthy condition."
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <Button type="submit" isLoading={isLoading} className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold">
            Submit Service Report
          </Button>
        </form>
      </Card>
    </div>
  );
}
