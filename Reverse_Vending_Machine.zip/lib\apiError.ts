import { NextResponse } from 'next/server';
import { ZodError } from 'zod';

export function handleApiError(error: unknown): NextResponse {
  console.error('[API Error]:', error);

  if (error instanceof ZodError) {
    const issueMap: Record<string, string> = {};
    error.issues.forEach((issue) => {
      const field = issue.path.join('.') || 'body';
      issueMap[field] = issue.message;
    });

    return NextResponse.json(
      {
        error: {
          message: 'Validation failed',
          code: 'VALIDATION_ERROR',
          fields: issueMap,
        },
      },
      { status: 400 }
    );
  }

  if (error instanceof Error) {
    // Handle Mongoose duplicate key error (11000)
    if ('code' in error && (error as { code: number }).code === 11000) {
      return NextResponse.json(
        {
          error: {
            message: 'A record with this unique identifier already exists',
            code: 'DUPLICATE_KEY',
          },
        },
        { status: 409 }
      );
    }

    return NextResponse.json(
      {
        error: {
          message: error.message || 'An unexpected error occurred',
          code: 'INTERNAL_ERROR',
        },
      },
      { status: 500 }
    );
  }

  return NextResponse.json(
    {
      error: {
        message: 'Internal server error',
        code: 'UNKNOWN_ERROR',
      },
    },
    { status: 500 }
  );
}
