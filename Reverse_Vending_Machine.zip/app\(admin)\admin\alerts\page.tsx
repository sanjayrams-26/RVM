'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { AlertTriangle, CheckCircle2, ShieldAlert, Filter, UserPlus } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminAlertsPage() {
  const [resolvedFilter, setResolvedFilter] = useState('false');
  const [severityFilter, setSeverityFilter] = useState('');

  const queryParams = new URLSearchParams();
  if (resolvedFilter !== '') queryParams.set('resolved', resolvedFilter);
  if (severityFilter) queryParams.set('severity', severityFilter);

  const { data, isLoading, mutate } = useSWR(`/api/alerts?${queryParams.toString()}`, fetcher);
  const { data: employeesData } = useSWR('/api/employees', fetcher);

  const alerts = data?.alerts || [];
  const employees = employeesData?.employees || [];

  const handleResolve = async (alertId: string) => {
    try {
      await fetch(`/api/alerts/${alertId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isResolved: true }),
      });
      mutate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleAssignEmployee = async (alertId: string, employeeId: string) => {
    try {
      await fetch(`/api/alerts/${alertId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ assignedEmployee: employeeId || null }),
      });
      mutate();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">IoT Operations Alert Feed</h1>
          <p className="text-xs text-slate-500 mt-1">Real-time alerts for machine storage overflow, offline status, and hardware faults</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap gap-3">
        <select
          value={resolvedFilter}
          onChange={(e) => setResolvedFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
        >
          <option value="false">Unresolved Alerts</option>
          <option value="true">Resolved Alerts</option>
          <option value="">All Alerts</option>
        </select>

        <select
          value={severityFilter}
          onChange={(e) => setSeverityFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
        >
          <option value="">All Severities</option>
          <option value="critical">Critical</option>
          <option value="warning">Warning</option>
          <option value="info">Info</option>
        </select>
      </div>

      <Card>
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading alerts feed...</div>
        ) : alerts.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-2 opacity-60" />
            <p className="font-bold text-slate-700">All clear! No active alerts matching criteria.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {alerts.map((alert: any) => (
              <div key={alert._id} className="p-4 sm:p-6 hover:bg-slate-50/80 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <Badge severity={alert.severity} />
                    <span className="text-xs font-bold text-slate-400 uppercase">{alert.type}</span>
                    <span className="text-xs font-bold text-slate-700">• {alert.machine?.machineId} ({alert.machine?.location?.district})</span>
                  </div>
                  <p className="text-sm font-bold text-slate-800">{alert.message}</p>
                  <p className="text-xs text-slate-400">Created: {new Date(alert.createdAt).toLocaleString()}</p>
                </div>

                <div className="flex items-center space-x-3">
                  {/* Employee assign dropdown */}
                  <select
                    value={alert.assignedEmployee?._id || ''}
                    onChange={(e) => handleAssignEmployee(alert._id, e.target.value)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs bg-white text-slate-700"
                  >
                    <option value="">-- Assign Tech --</option>
                    {employees.map((emp: any) => (
                      <option key={emp._id} value={emp._id}>
                        {emp.name} ({emp.employeeId})
                      </option>
                    ))}
                  </select>

                  {!alert.isResolved && (
                    <Button
                      size="sm"
                      onClick={() => handleResolve(alert._id)}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white"
                    >
                      Resolve Alert
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
