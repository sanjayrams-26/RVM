import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IEmployee extends Document {
  name: string;
  email: string;
  mobile: string;
  passwordHash: string;
  employeeId: string; // e.g. EMP-0001
  assignedMachines: mongoose.Types.ObjectId[];
  role: 'employee';
  isActive: boolean;
  joinDate: Date;
  createdAt: Date;
  updatedAt: Date;
}

const EmployeeSchema = new Schema<IEmployee>(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    mobile: { type: String, required: true, trim: true },
    passwordHash: { type: String, required: true, select: false },
    employeeId: { type: String, required: true, unique: true, uppercase: true, trim: true },
    assignedMachines: [{ type: Schema.Types.ObjectId, ref: 'Machine' }],
    role: { type: String, default: 'employee', immutable: true },
    isActive: { type: Boolean, default: true },
    joinDate: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

EmployeeSchema.index({ email: 1 });
EmployeeSchema.index({ employeeId: 1 });

export const Employee: Model<IEmployee> =
  mongoose.models.Employee || mongoose.model<IEmployee>('Employee', EmployeeSchema);
