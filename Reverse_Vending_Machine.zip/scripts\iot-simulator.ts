import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

const API_KEY = process.env.IOT_API_KEY || 'rvm_iot_secret_api_key_2026_device_auth';
const APP_URL = process.env.APP_URL || 'http://localhost:3000';

const sampleMachines = ['RVM-CBE-001', 'RVM-CBE-002', 'RVM-CHN-001', 'RVM-MDU-001'];

async function simulateTelemetry() {
  const machineId = sampleMachines[Math.floor(Math.random() * sampleMachines.length)];
  const bottlesDetected = Math.floor(Math.random() * 4) + 1; // 1 to 4 bottles
  const simulatedStorageLevel = Math.floor(Math.random() * 150) + 320; // 320 to 470

  const payload = {
    machineId,
    bottlesDetected,
    currentStorageLevel: simulatedStorageLevel,
    sensorStatus: Math.random() > 0.95 ? 'error' : 'ok',
    powerStatus: 'on',
    connectivity: 'connected',
    timestamp: new Date().toISOString(),
  };

  console.log(`[IoT Telemetry Simulator] Transmitting hardware payload for ${machineId}...`);

  try {
    const res = await fetch(`${APP_URL}/api/iot/machine-data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-iot-api-key': API_KEY,
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (res.ok) {
      console.log(`[IoT Response 200 OK]: ${machineId} Storage: ${data.storagePercent}%, Status: ${data.status}`);
    } else {
      console.error(`[IoT Error ${res.status}]:`, data);
    }
  } catch (err) {
    console.error('[IoT Simulator Connection Error]: Make sure dev server is running on http://localhost:3000', err);
  }
}

console.log('🚀 Starting IoT Hardware Simulator (Sending pulse every 5 seconds)...');
console.log('Target Endpoint:', `${APP_URL}/api/iot/machine-data`);
console.log('Press Ctrl+C to stop.\n');

setInterval(simulateTelemetry, 5000);
