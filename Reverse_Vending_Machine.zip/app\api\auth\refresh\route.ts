import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verifyRefreshToken, setAuthCookies } from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const cookieStore = cookies();
    const refreshToken = cookieStore.get('rvm_refresh')?.value;

    if (!refreshToken) {
      return NextResponse.json(
        { error: { message: 'Refresh token missing', code: 'UNAUTHORIZED' } },
        { status: 401 }
      );
    }

    const payload = verifyRefreshToken(refreshToken);
    if (!payload) {
      return NextResponse.json(
        { error: { message: 'Invalid or expired refresh token', code: 'UNAUTHORIZED' } },
        { status: 401 }
      );
    }

    const newPayload = {
      id: payload.id,
      name: payload.name,
      email: payload.email,
      role: payload.role,
    };

    setAuthCookies(newPayload);

    return NextResponse.json({ success: true, user: newPayload });
  } catch (error) {
    return NextResponse.json(
      { error: { message: 'Failed to refresh token', code: 'SERVER_ERROR' } },
      { status: 500 }
    );
  }
}
