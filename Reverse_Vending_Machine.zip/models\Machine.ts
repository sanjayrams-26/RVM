import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IErrorLog {
  code: string;
  message: string;
  timestamp: Date;
}

export interface IMachine extends Document {
  machineId: string; // RVM-CBE-001
  name: string;
  location: mongoose.Types.ObjectId;
  gps: { lat: number; lng: number };
  status: 'online' | 'offline' | 'active' | 'full' | 'under_maintenance' | 'damaged' | 'inactive';
  storageCapacity: number;
  currentStorageLevel: number;
  bottlesCollectedTotal: number;
  uniqueUsersCount: number;
  totalGreenCoinsGenerated: number;
  assignedEmployee?: mongoose.Types.ObjectId;
  installationDate?: Date;
  lastMaintenanceDate?: Date;
  nextMaintenanceDate?: Date;
  connectivity: 'connected' | 'disconnected';
  sensorStatus: 'ok' | 'error' | 'unknown';
  powerStatus: 'on' | 'off' | 'battery';
  lastSyncAt?: Date;
  errorLog: IErrorLog[];
  storagePercent: number; // Virtual
  createdAt: Date;
  updatedAt: Date;
}

const MachineSchema = new Schema<IMachine>(
  {
    machineId: { type: String, required: true, unique: true, uppercase: true, trim: true },
    name: { type: String, required: true, trim: true },
    location: { type: Schema.Types.ObjectId, ref: 'Location', required: true },
    gps: {
      lat: { type: Number, required: true },
      lng: { type: Number, required: true },
    },
    status: {
      type: String,
      enum: ['online', 'offline', 'active', 'full', 'under_maintenance', 'damaged', 'inactive'],
      default: 'inactive',
    },
    storageCapacity: { type: Number, required: true, default: 500 },
    currentStorageLevel: { type: Number, default: 0 },
    bottlesCollectedTotal: { type: Number, default: 0 },
    uniqueUsersCount: { type: Number, default: 0 },
    totalGreenCoinsGenerated: { type: Number, default: 0 },
    assignedEmployee: { type: Schema.Types.ObjectId, ref: 'Employee' },
    installationDate: { type: Date, default: Date.now },
    lastMaintenanceDate: Date,
    nextMaintenanceDate: Date,
    connectivity: {
      type: String,
      enum: ['connected', 'disconnected'],
      default: 'disconnected',
    },
    sensorStatus: {
      type: String,
      enum: ['ok', 'error', 'unknown'],
      default: 'unknown',
    },
    powerStatus: {
      type: String,
      enum: ['on', 'off', 'battery'],
      default: 'off',
    },
    lastSyncAt: Date,
    errorLog: [
      {
        code: String,
        message: String,
        timestamp: { type: Date, default: Date.now },
      },
    ],
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

MachineSchema.virtual('storagePercent').get(function (this: IMachine) {
  if (!this.storageCapacity || this.storageCapacity === 0) return 0;
  return Math.min(100, Math.round((this.currentStorageLevel / this.storageCapacity) * 100));
});

MachineSchema.index({ machineId: 1 });
MachineSchema.index({ location: 1 });
MachineSchema.index({ status: 1 });
MachineSchema.index({ assignedEmployee: 1 });

export const Machine: Model<IMachine> =
  mongoose.models.Machine || mongoose.model<IMachine>('Machine', MachineSchema);
