'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  MapPin,
  History,
  Gift,
  User,
  Cpu,
  Users,
  Briefcase,
  AlertTriangle,
  Wrench,
  BarChart3,
  Building,
} from 'lucide-react';

interface SidebarProps {
  role: 'user' | 'admin' | 'employee';
}

export const Sidebar: React.FC<SidebarProps> = ({ role }) => {
  const pathname = usePathname();

  const userLinks = [
    { href: '/user/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/user/machines', label: 'RVM Locator', icon: MapPin },
    { href: '/user/transactions', label: 'History', icon: History },
    { href: '/user/rewards', label: 'Green Coins', icon: Gift },
    { href: '/user/profile', label: 'Profile', icon: User },
  ];

  const adminLinks = [
    { href: '/admin/dashboard', label: 'Overview', icon: LayoutDashboard },
    { href: '/admin/machines', label: 'Machines', icon: Cpu },
    { href: '/admin/locations', label: 'Locations Tree', icon: Building },
    { href: '/admin/users', label: 'Recyclers', icon: Users },
    { href: '/admin/employees', label: 'Field Staff', icon: Briefcase },
    { href: '/admin/alerts', label: 'IoT Alerts', icon: AlertTriangle },
    { href: '/admin/transactions', label: 'Transactions', icon: History },
    { href: '/admin/maintenance', label: 'Maintenance', icon: Wrench },
    { href: '/admin/reports', label: 'Analytics & CSV', icon: BarChart3 },
  ];

  const employeeLinks = [
    { href: '/employee/dashboard', label: 'Task Center', icon: LayoutDashboard },
    { href: '/employee/tasks', label: 'Assigned Service', icon: Wrench },
    { href: '/employee/history', label: 'Completed Log', icon: History },
    { href: '/employee/profile', label: 'Profile', icon: User },
  ];

  const links = role === 'admin' ? adminLinks : role === 'employee' ? employeeLinks : userLinks;

  const roleStyles = {
    user: {
      sidebarBg: 'bg-emerald-50/40 border-emerald-100',
      activeLink: 'bg-emerald-600 text-white shadow-sm shadow-emerald-200 font-bold',
      inactiveLink: 'text-emerald-950 hover:bg-emerald-100/60 hover:text-emerald-800',
      tag: 'User Portal',
    },
    admin: {
      sidebarBg: 'bg-slate-50 border-slate-200',
      activeLink: 'bg-indigo-600 text-white shadow-sm shadow-indigo-200 font-bold',
      inactiveLink: 'text-slate-700 hover:bg-slate-200/60 hover:text-slate-900',
      tag: 'Admin Console',
    },
    employee: {
      sidebarBg: 'bg-amber-50/40 border-amber-100',
      activeLink: 'bg-amber-600 text-white shadow-sm shadow-amber-200 font-bold',
      inactiveLink: 'text-amber-950 hover:bg-amber-100/60 hover:text-amber-900',
      tag: 'Service Portal',
    },
  };

  const style = roleStyles[role];

  return (
    <aside className={`w-64 min-h-[calc(100vh-4rem)] border-r ${style.sidebarBg} p-4 flex flex-col justify-between`}>
      <div>
        <div className="px-3 py-2 mb-4">
          <span className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
            {style.tag}
          </span>
        </div>
        <nav className="space-y-1.5">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = pathname === link.href || pathname.startsWith(`${link.href}/`);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm transition-all duration-150 ${
                  isActive ? style.activeLink : style.inactiveLink
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span>{link.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="p-3.5 bg-white/80 rounded-xl border border-slate-200/60 shadow-2xs">
        <p className="text-xs font-medium text-slate-500">Reverse Vending Machine Network</p>
        <p className="text-[10px] text-emerald-600 font-bold mt-0.5">🟢 Status: Operational</p>
      </div>
    </aside>
  );
};
