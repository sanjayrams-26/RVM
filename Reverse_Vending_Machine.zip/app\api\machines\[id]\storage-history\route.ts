import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { StorageLog } from '@/models/StorageLog';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase();
    const history = await StorageLog.find({ machine: params.id })
      .sort({ timestamp: -1 })
      .limit(50);

    return NextResponse.json({ history: history.reverse() });
  } catch (error) {
    return handleApiError(error);
  }
}
