import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { User } from '@/models/User';
import { hashPassword, setAuthCookies } from '@/lib/auth';
import { registerSchema } from '@/lib/validators';
import { handleApiError } from '@/lib/apiError';

export async function POST(req: NextRequest) {
  try {
    await connectToDatabase();
    const body = await req.json();
    const validatedData = registerSchema.parse(body);

    // Check existing email or mobile
    const existingUser = await User.findOne({
      $or: [{ email: validatedData.email.toLowerCase() }, { mobile: validatedData.mobile }],
    });

    if (existingUser) {
      return NextResponse.json(
        {
          error: {
            message: 'User with this email or mobile number already exists',
            code: 'USER_EXISTS',
          },
        },
        { status: 400 }
      );
    }

    const passwordHash = await hashPassword(validatedData.password);

    const newUser = await User.create({
      name: validatedData.name,
      email: validatedData.email.toLowerCase(),
      mobile: validatedData.mobile,
      passwordHash,
      role: 'user',
    });

    const sessionPayload = {
      id: newUser._id.toString(),
      name: newUser.name,
      email: newUser.email,
      role: 'user' as const,
    };

    setAuthCookies(sessionPayload);

    return NextResponse.json(
      {
        success: true,
        user: {
          id: newUser._id,
          name: newUser.name,
          email: newUser.email,
          mobile: newUser.mobile,
          role: newUser.role,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    return handleApiError(error);
  }
}
