'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { Building, Plus, Trash2, MapPin, ChevronRight } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminLocationsPage() {
  const { data, isLoading, mutate } = useSWR('/api/locations', fetcher);
  const locations = data?.locations || [];

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [stateName, setStateName] = useState('Tamil Nadu');
  const [district, setDistrict] = useState('Coimbatore');
  const [area, setArea] = useState('');
  const [exactLocation, setExactLocation] = useState('');
  const [type, setType] = useState('public_place');
  const [lat, setLat] = useState(11.0168);
  const [lng, setLng] = useState(76.9558);

  const [statusMsg, setStatusMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAddLocation = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setStatusMsg('');

    try {
      const res = await fetch('/api/locations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          state: stateName,
          district,
          area,
          exactLocation,
          type,
          gps: { lat: Number(lat), lng: Number(lng) },
        }),
      });

      const resData = await res.json();
      if (!res.ok) {
        setStatusMsg(resData.error?.message || 'Failed to add location');
      } else {
        setStatusMsg('Location node added successfully!');
        mutate();
        setTimeout(() => {
          setIsAddModalOpen(false);
          setStatusMsg('');
          setArea('');
          setExactLocation('');
        }, 1200);
      }
    } catch {
      setStatusMsg('An error occurred.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this location node?')) return;

    try {
      const res = await fetch(`/api/locations/${id}`, { method: 'DELETE' });
      const resData = await res.json();
      if (!res.ok) {
        alert(resData.error?.message || 'Delete failed');
      } else {
        mutate();
      }
    } catch {
      alert('Delete error occurred');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">Location Tree Hierarchy</h1>
          <p className="text-xs text-slate-500 mt-1">
            Manage State → District → Area → Location nodes for machine deployment
          </p>
        </div>
        <Button onClick={() => setIsAddModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" /> Add Location Node
        </Button>
      </div>

      <Card>
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading location tree...</div>
        ) : locations.length === 0 ? (
          <div className="text-center py-12 text-slate-400">No location nodes configured yet.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">State</th>
                  <th className="py-3.5 px-4">District</th>
                  <th className="py-3.5 px-4">Area</th>
                  <th className="py-3.5 px-4">Exact Landmark</th>
                  <th className="py-3.5 px-4">Category Type</th>
                  <th className="py-3.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {locations.map((loc: any) => (
                  <tr key={loc._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-slate-800">{loc.state}</td>
                    <td className="py-3.5 px-4 font-bold text-emerald-700">{loc.district}</td>
                    <td className="py-3.5 px-4 font-medium text-slate-800">{loc.area}</td>
                    <td className="py-3.5 px-4 text-slate-600">{loc.exactLocation}</td>
                    <td className="py-3.5 px-4">
                      <span className="text-xs font-bold px-2.5 py-1 rounded-full uppercase bg-slate-100 text-slate-700 border border-slate-200">
                        {loc.type}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => handleDelete(loc._id)}
                        className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete Location"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Add Location Modal */}
      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Add New Location Node">
        <form onSubmit={handleAddLocation} className="space-y-4">
          {statusMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl">
              {statusMsg}
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">State</label>
              <input
                type="text"
                required
                value={stateName}
                onChange={(e) => setStateName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">District</label>
              <input
                type="text"
                required
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Area / Suburb</label>
            <input
              type="text"
              required
              placeholder="Gandhipuram Bus Stand"
              value={area}
              onChange={(e) => setArea(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Exact Landmark</label>
            <input
              type="text"
              required
              placeholder="Platform 2, Main Entrance"
              value={exactLocation}
              onChange={(e) => setExactLocation(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="w-full px-2.5 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="public_place">Public Place</option>
                <option value="street">Street</option>
                <option value="station">Station</option>
                <option value="mall">Mall</option>
                <option value="airport">Airport</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Lat</label>
              <input
                type="number"
                step="any"
                required
                value={lat}
                onChange={(e) => setLat(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Lng</label>
              <input
                type="number"
                step="any"
                required
                value={lng}
                onChange={(e) => setLng(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm"
              />
            </div>
          </div>

          <Button type="submit" isLoading={isSubmitting} className="w-full py-3">
            Save Location Node
          </Button>
        </form>
      </Modal>
    </div>
  );
}
