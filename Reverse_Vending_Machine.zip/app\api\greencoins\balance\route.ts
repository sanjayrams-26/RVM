import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { User } from '@/models/User';
import { getSessionFromCookies } from '@/lib/auth';
import { MOCK_USERS } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  const session = getSessionFromCookies();
  const userId = session?.id || 'usr_1';

  try {
    await connectToDatabase();
    const userDoc = await User.findById(userId).lean();
    if (userDoc) {
      return NextResponse.json(
        {
          balance: userDoc.currentBalance,
          totalEarned: userDoc.totalGreenCoinsEarned,
          totalRedeemed: userDoc.greenCoinsRedeemed,
          totalWithdrawn: userDoc.greenCoinsWithdrawn,
          totalBottles: userDoc.totalBottlesRecycled,
        },
        {
          headers: {
            'Cache-Control': 'private, max-age=5, stale-while-revalidate=15',
          },
        }
      );
    }
  } catch (e) {
    console.warn('Serving mock balance fallback');
  }

  const mockUser = MOCK_USERS[0];
  return NextResponse.json({
    balance: mockUser.currentBalance,
    totalEarned: mockUser.totalGreenCoinsEarned,
    totalRedeemed: mockUser.greenCoinsRedeemed,
    totalWithdrawn: mockUser.greenCoinsWithdrawn,
    totalBottles: mockUser.totalBottlesRecycled,
  });
}
