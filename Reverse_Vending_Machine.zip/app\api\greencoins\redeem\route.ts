import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { User } from '@/models/User';
import { GreenCoinLedger } from '@/models/GreenCoinLedger';
import { requireRole } from '@/lib/rbac';
import { redeemCoinsSchema } from '@/lib/validators';
import { handleApiError } from '@/lib/apiError';

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireRole(req, ['user', 'admin']);
    if (authResult instanceof NextResponse) return authResult;

    const { user: sessionUser } = authResult;
    await connectToDatabase();

    const body = await req.json();
    const { amount, note } = redeemCoinsSchema.parse(body);

    const userDoc = await User.findById(sessionUser.id);
    if (!userDoc) {
      return NextResponse.json(
        { error: { message: 'User not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    if (userDoc.currentBalance < amount) {
      return NextResponse.json(
        { error: { message: `Insufficient Green Coins balance. Available: ${userDoc.currentBalance}`, code: 'INSUFFICIENT_BALANCE' } },
        { status: 400 }
      );
    }

    userDoc.currentBalance -= amount;
    userDoc.greenCoinsRedeemed += amount;
    await userDoc.save();

    const ledger = await GreenCoinLedger.create({
      user: sessionUser.id,
      type: 'redeem',
      amount: -amount,
      balanceAfter: userDoc.currentBalance,
      note: note || `Redeemed ${amount} Green Coins for reward voucher`,
    });

    return NextResponse.json({
      success: true,
      newBalance: userDoc.currentBalance,
      ledger,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
