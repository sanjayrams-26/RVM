import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Employee } from '@/models/Employee';
import { Machine } from '@/models/Machine';
import { requireRole } from '@/lib/rbac';
import { updateEmployeeSchema } from '@/lib/validators';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase();
    const employee = await Employee.findById(params.id)
      .select('-passwordHash')
      .populate({
        path: 'assignedMachines',
        populate: { path: 'location' },
      });

    if (!employee) {
      return NextResponse.json(
        { error: { message: 'Employee not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    return NextResponse.json({ employee });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin', 'employee']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const body = await req.json();
    const validatedData = updateEmployeeSchema.parse(body);

    const oldEmployee = await Employee.findById(params.id);
    if (!oldEmployee) {
      return NextResponse.json(
        { error: { message: 'Employee not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    // Update assigned machines sync
    if (validatedData.assignedMachines) {
      // Unassign from machines no longer in array
      await Machine.updateMany(
        { assignedEmployee: params.id, _id: { $nin: validatedData.assignedMachines } },
        { $unset: { assignedEmployee: '' } }
      );
      // Assign to new machines
      await Machine.updateMany(
        { _id: { $in: validatedData.assignedMachines } },
        { assignedEmployee: params.id }
      );
    }

    const updatedEmployee = await Employee.findByIdAndUpdate(params.id, validatedData, {
      new: true,
    })
      .select('-passwordHash')
      .populate('assignedMachines');

    return NextResponse.json({ success: true, employee: updatedEmployee });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const employee = await Employee.findByIdAndDelete(params.id);
    if (!employee) {
      return NextResponse.json(
        { error: { message: 'Employee not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    // Clear employee assignment from machines
    await Machine.updateMany({ assignedEmployee: params.id }, { $unset: { assignedEmployee: '' } });

    return NextResponse.json({ success: true, message: 'Employee deleted successfully' });
  } catch (error) {
    return handleApiError(error);
  }
}
