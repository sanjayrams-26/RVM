import React from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { Sidebar } from '@/components/layout/Sidebar';
import { getSessionFromCookies } from '@/lib/auth';

export default function EmployeeLayout({ children }: { children: React.ReactNode }) {
  const session = getSessionFromCookies();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar userName={session?.name || 'Field Staff'} role="employee" />
      <div className="flex flex-1">
        <Sidebar role="employee" />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto w-full">{children}</main>
      </div>
    </div>
  );
}
