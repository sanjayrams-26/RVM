import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Transaction } from '@/models/Transaction';
import { requireRole } from '@/lib/rbac';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin', 'user']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const transaction = await Transaction.findById(params.id)
      .populate('user', 'name email mobile')
      .populate({
        path: 'machine',
        populate: { path: 'location' },
      });

    if (!transaction) {
      return NextResponse.json(
        { error: { message: 'Transaction not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    return NextResponse.json({ transaction });
  } catch (error) {
    return handleApiError(error);
  }
}
