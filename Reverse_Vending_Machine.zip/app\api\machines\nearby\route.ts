import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { MOCK_MACHINES } from '@/lib/mockData';

function getDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const userLat = parseFloat(searchParams.get('lat') || '11.0168');
  const userLng = parseFloat(searchParams.get('lng') || '76.9558');
  const radiusKm = parseFloat(searchParams.get('radiusKm') || '100');

  try {
    await connectToDatabase();
    const dbMachines = await Machine.find({ status: { $ne: 'inactive' } }).populate('location');
    if (dbMachines.length > 0) {
      const nearby = dbMachines
        .map((m) => ({
          ...m.toObject(),
          distanceKm: getDistanceKm(userLat, userLng, m.gps.lat, m.gps.lng),
        }))
        .filter((m) => m.distanceKm <= radiusKm)
        .sort((a, b) => a.distanceKm - b.distanceKm);

      return NextResponse.json({ machines: nearby });
    }
  } catch (e) {
    console.warn('Serving mock nearby machines fallback');
  }

  // Fallback Mock
  const nearbyMock = MOCK_MACHINES.map((m) => ({
    ...m,
    distanceKm: getDistanceKm(userLat, userLng, m.gps.lat, m.gps.lng),
  }))
    .filter((m) => m.distanceKm <= radiusKm)
    .sort((a, b) => a.distanceKm - b.distanceKm);

  return NextResponse.json({ machines: nearbyMock });
}
