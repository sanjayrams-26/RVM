import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Transaction } from '@/models/Transaction';
import { Machine } from '@/models/Machine';
import { User } from '@/models/User';
import { getSessionFromCookies } from '@/lib/auth';
import { depositTransactionSchema } from '@/lib/validators';
import { calculateNaviRandomCoins } from '@/lib/naviRewardEngine';
import { MOCK_TRANSACTIONS, MOCK_MACHINES, MOCK_USERS } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();
    const dbTxs = await Transaction.find()
      .populate('user', 'name email mobile')
      .populate({ path: 'machine', populate: { path: 'location' } })
      .sort({ timestamp: -1 });

    if (dbTxs.length > 0) {
      return NextResponse.json({ transactions: dbTxs });
    }
  } catch (e) {
    console.warn('Serving mock transactions fallback');
  }

  return NextResponse.json({ transactions: MOCK_TRANSACTIONS });
}

export async function POST(req: NextRequest) {
  try {
    const session = getSessionFromCookies();
    const body = await req.json();
    const { machineId, bottlesDeposited } = depositTransactionSchema.parse(body);

    // Navi App Algorithm Concept: calculate dynamic random coins for each bottle
    const naviReward = calculateNaviRandomCoins(bottlesDeposited);
    const coinsEarned = naviReward.totalCoinsEarned;

    try {
      await connectToDatabase();
      const machine = await Machine.findOne({
        $or: [{ _id: machineId.match(/^[0-9a-fA-F]{24}$/) ? machineId : null }, { machineId: machineId.toUpperCase() }],
      });

      if (machine) {
        machine.currentStorageLevel += bottlesDeposited;
        machine.bottlesCollectedTotal += bottlesDeposited;
        machine.totalGreenCoinsGenerated += coinsEarned;
        await machine.save();

        const userDoc = await User.findById(session?.id);
        if (userDoc) {
          userDoc.totalBottlesRecycled += bottlesDeposited;
          userDoc.totalGreenCoinsEarned += coinsEarned;
          userDoc.currentBalance += coinsEarned;
          await userDoc.save();
        }

        const transaction = await Transaction.create({
          user: session?.id,
          machine: machine._id,
          bottlesDeposited,
          coinsEarned,
          timestamp: new Date(),
          status: 'success',
        });

        return NextResponse.json({
          success: true,
          transaction,
          newBalance: userDoc?.currentBalance || 200,
          coinsEarned,
          naviReward,
          storagePercent: machine.storagePercent,
        });
      }
    } catch (dbErr) {
      console.warn('Database offline, simulating deposit update');
    }

    // Mock deposit response
    const mockTx = {
      _id: `tx_${Date.now()}`,
      user: { _id: session?.id || 'usr_1', name: session?.name || 'Mohammed Suhail', email: 'user1@example.com', mobile: '9876543210' },
      machine: MOCK_MACHINES[0],
      bottlesDeposited,
      coinsEarned,
      timestamp: new Date().toISOString(),
      status: 'success' as const,
    };

    MOCK_TRANSACTIONS.unshift(mockTx);
    MOCK_USERS[0].currentBalance += coinsEarned;
    MOCK_USERS[0].totalBottlesRecycled += bottlesDeposited;
    MOCK_USERS[0].totalGreenCoinsEarned += coinsEarned;

    return NextResponse.json({
      success: true,
      transaction: mockTx,
      newBalance: MOCK_USERS[0].currentBalance,
      coinsEarned,
      naviReward,
      storagePercent: 88,
    });
  } catch (error: any) {
    return NextResponse.json({ error: { message: error.message || 'Deposit failed' } }, { status: 400 });
  }
}

