'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { MapPin, Search, Navigation, Filter, Cpu, ArrowRight } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { MOCK_LOCATIONS } from '@/lib/mockData';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

const districtOptions = Array.from(new Set(MOCK_LOCATIONS.map((location) => location.district))).sort();

export default function UserMachinesPage() {
  const [district, setDistrict] = useState('');
  const [search, setSearch] = useState('');

  const { data, isLoading } = useSWR(
    `/api/machines/nearby?lat=11.0168&lng=76.9558&radiusKm=100`,
    fetcher
  );

  const machines = data?.machines || [];

  const filteredMachines = machines.filter((m: any) => {
    const matchesDistrict = !district || m.location?.district?.toLowerCase() === district.toLowerCase();
    const matchesSearch =
      !search ||
      m.machineId.toLowerCase().includes(search.toLowerCase()) ||
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.location?.area?.toLowerCase().includes(search.toLowerCase());
    return matchesDistrict && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">RVM Machine Locator</h1>
          <p className="text-xs text-slate-500 mt-1">
            Locate active Reverse Vending Machines near you to deposit plastic bottles
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by Machine ID, Area, or Name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="sm:w-48">
          <select
            value={district}
            onChange={(e) => setDistrict(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
          >
            <option value="">All Districts</option>
            {districtOptions.map((districtName) => (
              <option key={districtName} value={districtName}>
                {districtName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Machine Cards Grid */}
      {isLoading ? (
        <div className="text-center py-12 text-slate-400">Loading machines...</div>
      ) : filteredMachines.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
          <MapPin className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="font-bold">No RVM machines match your filter criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMachines.map((m: any) => (
            <Card key={m._id} className="flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-emerald-600 bg-emerald-50 border border-emerald-100 px-2.5 py-1 rounded-full">
                    {m.distanceKm ? `${m.distanceKm} km away` : 'Nearby'}
                  </span>
                  <Badge status={m.status} />
                </div>

                <h3 className="text-base font-extrabold text-slate-800 mb-1">{m.name}</h3>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-3">{m.machineId}</p>

                <div className="space-y-1.5 text-xs text-slate-600 mb-4 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <p className="font-medium text-slate-800">
                    📍 {m.location?.district}, {m.location?.area}
                  </p>
                  <p className="text-slate-500">{m.location?.exactLocation}</p>
                </div>

                {/* Storage Bar */}
                <div className="space-y-1 mb-4">
                  <div className="flex justify-between text-xs font-bold text-slate-600">
                    <span>Storage Fill Level</span>
                    <span>{m.storagePercent}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        m.storagePercent >= 90
                          ? 'bg-rose-500'
                          : m.storagePercent >= 80
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${m.storagePercent}%` }}
                    />
                  </div>
                </div>
              </div>

              <Link
                href={`/user/machines/${m._id}`}
                className="w-full py-2.5 rounded-xl border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-100/60 text-emerald-700 font-bold text-xs flex items-center justify-center space-x-1 transition-colors mt-2"
              >
                <span>View Details & Navigation</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
