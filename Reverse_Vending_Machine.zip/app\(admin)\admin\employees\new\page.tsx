'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function NewEmployeePage() {
  const router = useRouter();
  const { data: machinesData } = useSWR('/api/machines', fetcher);
  const machines = machinesData?.machines || [];

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [selectedMachines, setSelectedMachines] = useState<string[]>([]);

  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/employees', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          mobile,
          password,
          assignedMachines: selectedMachines,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error?.message || 'Failed to create employee');
        setIsLoading(false);
        return;
      }

      router.push('/admin/employees');
      router.refresh();
    } catch {
      setErrorMsg('An unexpected error occurred.');
      setIsLoading(false);
    }
  };

  const toggleMachineSelect = (id: string) => {
    if (selectedMachines.includes(id)) {
      setSelectedMachines(selectedMachines.filter((m) => m !== id));
    } else {
      setSelectedMachines([...selectedMachines, id]);
    }
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <Link href="/admin/employees" className="inline-flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-700">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to Staff List
      </Link>

      <div>
        <h1 className="text-2xl font-black text-slate-900">Add Field Staff Account</h1>
        <p className="text-xs text-slate-500 mt-1">Create employee credentials and assign machine units</p>
      </div>

      <Card>
        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Full Name</label>
            <input
              type="text"
              required
              placeholder="Ramesh Kumar"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Email Address</label>
              <input
                type="email"
                required
                placeholder="tech@rvm.org"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Mobile Number</label>
              <input
                type="text"
                required
                pattern="[6-9][0-9]{9}"
                placeholder="9876543210"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Initial Password</label>
            <input
              type="password"
              required
              minLength={8}
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-2">Assign Machines</label>
            <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl p-3 space-y-2 bg-slate-50">
              {machines.map((m: any) => (
                <label key={m._id} className="flex items-center space-x-3 text-xs text-slate-700 cursor-pointer font-medium">
                  <input
                    type="checkbox"
                    checked={selectedMachines.includes(m._id)}
                    onChange={() => toggleMachineSelect(m._id)}
                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>
                    <strong>{m.machineId}</strong> - {m.name} ({m.location?.district})
                  </span>
                </label>
              ))}
            </div>
          </div>

          <Button type="submit" isLoading={isLoading} className="w-full py-3 mt-4">
            Create Employee Account
          </Button>
        </form>
      </Card>
    </div>
  );
}
