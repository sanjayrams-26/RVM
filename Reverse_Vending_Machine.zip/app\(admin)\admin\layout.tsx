import React from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { Sidebar } from '@/components/layout/Sidebar';
import { getSessionFromCookies } from '@/lib/auth';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = getSessionFromCookies();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar userName={session?.name || 'Administrator'} role="admin" />
      <div className="flex flex-1">
        <Sidebar role="admin" />
        <main className="flex-1 p-6 lg:p-8 max-w-7xl mx-auto w-full">{children}</main>
      </div>
    </div>
  );
}
