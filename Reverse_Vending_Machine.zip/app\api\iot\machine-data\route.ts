import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { StorageLog } from '@/models/StorageLog';
import { Alert } from '@/models/Alert';
import { iotTelemetrySchema } from '@/lib/validators';
import { handleApiError } from '@/lib/apiError';

export async function POST(req: NextRequest) {
  try {
    const apiKey = req.headers.get('x-iot-api-key');
    const validApiKey = process.env.IOT_API_KEY || 'rvm_iot_secret_api_key_2026_device_auth';

    if (!apiKey || apiKey !== validApiKey) {
      return NextResponse.json(
        { error: { message: 'Invalid or missing IoT API Key header', code: 'UNAUTHORIZED_DEVICE' } },
        { status: 401 }
      );
    }

    await connectToDatabase();
    const body = await req.json();
    const data = iotTelemetrySchema.parse(body);

    const machine = await Machine.findOne({
      machineId: data.machineId.toUpperCase(),
    });

    if (!machine) {
      return NextResponse.json(
        { error: { message: `Machine ${data.machineId} not found`, code: 'MACHINE_NOT_FOUND' } },
        { status: 404 }
      );
    }

    // Update telemetry
    if (data.currentStorageLevel !== undefined) {
      machine.currentStorageLevel = data.currentStorageLevel;
    }
    if (data.sensorStatus) machine.sensorStatus = data.sensorStatus;
    if (data.powerStatus) machine.powerStatus = data.powerStatus;
    if (data.connectivity) machine.connectivity = data.connectivity;
    machine.lastSyncAt = new Date();

    if (data.bottlesDetected && data.bottlesDetected > 0) {
      machine.bottlesCollectedTotal += data.bottlesDetected;
    }

    // Calculate Storage %
    const storagePercent = Math.min(
      100,
      Math.round((machine.currentStorageLevel / machine.storageCapacity) * 100)
    );

    // Update status
    const alertThreshold = Number(process.env.NEXT_PUBLIC_STORAGE_ALERT_THRESHOLD || 80);
    const criticalThreshold = Number(process.env.NEXT_PUBLIC_STORAGE_CRITICAL_THRESHOLD || 90);

    if (storagePercent >= criticalThreshold) {
      machine.status = 'full';
    } else if (machine.status === 'full' && storagePercent < criticalThreshold) {
      machine.status = 'active';
    } else if (machine.status === 'offline' || machine.status === 'inactive') {
      machine.status = 'active';
    }

    await machine.save();

    // Log storage snapshot
    await StorageLog.create({
      machine: machine._id,
      storageLevel: machine.currentStorageLevel,
      storagePercent,
      timestamp: new Date(),
    });

    // Alert Automation
    if (storagePercent >= alertThreshold) {
      const severity = storagePercent >= criticalThreshold ? 'critical' : 'warning';
      const msg = `IoT Telemetry Alert: RVM ${machine.machineId} storage level at ${storagePercent}% (${machine.currentStorageLevel}/${machine.storageCapacity} bottles).`;

      const existingAlert = await Alert.findOne({
        machine: machine._id,
        type: 'storage',
        isResolved: false,
      });

      if (existingAlert) {
        existingAlert.severity = severity;
        existingAlert.message = msg;
        await existingAlert.save();
      } else {
        await Alert.create({
          machine: machine._id,
          type: 'storage',
          message: msg,
          severity,
          assignedEmployee: machine.assignedEmployee || undefined,
        });
      }
    }

    // Sensor Error Alert Automation
    if (data.sensorStatus === 'error') {
      const existingSensorAlert = await Alert.findOne({
        machine: machine._id,
        type: 'error',
        isResolved: false,
      });
      if (!existingSensorAlert) {
        await Alert.create({
          machine: machine._id,
          type: 'error',
          message: `Hardware Sensor Fault reported by IoT controller on ${machine.machineId}`,
          severity: 'warning',
          assignedEmployee: machine.assignedEmployee || undefined,
        });
      }
    }

    return NextResponse.json({
      success: true,
      machineId: machine.machineId,
      currentStorageLevel: machine.currentStorageLevel,
      storagePercent,
      status: machine.status,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
