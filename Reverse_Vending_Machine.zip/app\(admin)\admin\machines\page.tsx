'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { Plus, Search, Filter, Cpu, ArrowRight } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { MOCK_LOCATIONS } from '@/lib/mockData';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

const districtOptions = Array.from(new Set(MOCK_LOCATIONS.map((location) => location.district))).sort();

export default function AdminMachinesPage() {
  const [search, setSearch] = useState('');
  const [district, setDistrict] = useState('');
  const [status, setStatus] = useState('');

  const queryParams = new URLSearchParams();
  if (search) queryParams.set('search', search);
  if (district) queryParams.set('district', district);
  if (status) queryParams.set('status', status);

  const { data, isLoading } = useSWR(`/api/machines?${queryParams.toString()}`, fetcher);
  const machines = data?.machines || [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">RVM Machine Fleet</h1>
          <p className="text-xs text-slate-500 mt-1">Manage physical hardware units, location linkages, and employee assignments</p>
        </div>
        <Link href="/admin/machines/new">
          <Button className="w-full sm:w-auto">
            <Plus className="w-4 h-4 mr-2" /> Add New Machine
          </Button>
        </Link>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by Machine ID or Name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <select
          value={district}
          onChange={(e) => setDistrict(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white sm:w-44"
        >
          <option value="">All Districts</option>
          {districtOptions.map((districtName) => (
            <option key={districtName} value={districtName}>
              {districtName}
            </option>
          ))}
        </select>

        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white sm:w-44"
        >
          <option value="">All Statuses</option>
          <option value="active">Active</option>
          <option value="full">Full</option>
          <option value="offline">Offline</option>
          <option value="under_maintenance">Under Maintenance</option>
          <option value="damaged">Damaged</option>
        </select>
      </div>

      {/* Machines Table */}
      <Card>
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading machine fleet...</div>
        ) : machines.length === 0 ? (
          <div className="text-center py-12 text-slate-400">No machines match criteria.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">Machine ID</th>
                  <th className="py-3.5 px-4">Location</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Storage Level</th>
                  <th className="py-3.5 px-4">Assigned Staff</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {machines.map((m: any) => (
                  <tr key={m._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-extrabold text-slate-800">
                      <div>{m.machineId}</div>
                      <div className="text-xs font-normal text-slate-500">{m.name}</div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      <div>
                        {m.location?.district}, {m.location?.area}
                      </div>
                      <div className="text-xs text-slate-400">{m.location?.exactLocation}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <Badge status={m.status} />
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="w-32">
                        <div className="flex justify-between text-xs font-bold text-slate-600 mb-1">
                          <span>{m.currentStorageLevel}/{m.storageCapacity}</span>
                          <span>{m.storagePercent}%</span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              m.storagePercent >= 90
                                ? 'bg-rose-500'
                                : m.storagePercent >= 80
                                ? 'bg-amber-500'
                                : 'bg-emerald-500'
                            }`}
                            style={{ width: `${m.storagePercent}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-700">
                      {m.assignedEmployee ? (
                        <span>{m.assignedEmployee.name} ({m.assignedEmployee.employeeId})</span>
                      ) : (
                        <span className="text-slate-400 text-xs italic">Unassigned</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <Link
                        href={`/admin/machines/${m._id}`}
                        className="inline-flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-3 py-1.5 rounded-lg border border-indigo-100"
                      >
                        Manage <ArrowRight className="w-3.5 h-3.5 ml-1" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
