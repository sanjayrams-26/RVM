import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Alert } from '@/models/Alert';
import { requireRole } from '@/lib/rbac';
import { updateAlertSchema } from '@/lib/validators';
import { handleApiError } from '@/lib/apiError';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin', 'employee']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const body = await req.json();
    const validatedData = updateAlertSchema.parse(body);

    const updateFields: any = {};
    if (validatedData.isResolved !== undefined) {
      updateFields.isResolved = validatedData.isResolved;
      if (validatedData.isResolved) {
        updateFields.resolvedAt = new Date();
      }
    }
    if (validatedData.assignedEmployee !== undefined) {
      updateFields.assignedEmployee = validatedData.assignedEmployee;
    }

    const alert = await Alert.findByIdAndUpdate(params.id, updateFields, { new: true })
      .populate('assignedEmployee', 'name email employeeId mobile')
      .populate({
        path: 'machine',
        populate: { path: 'location' },
      });

    if (!alert) {
      return NextResponse.json(
        { error: { message: 'Alert not found', code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, alert });
  } catch (error) {
    return handleApiError(error);
  }
}
