import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { MOCK_MACHINES } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();
    const report = await Machine.aggregate([
      {
        $lookup: {
          from: 'locations',
          localField: 'location',
          foreignField: '_id',
          as: 'locationInfo',
        },
      },
      { $unwind: '$locationInfo' },
      {
        $group: {
          _id: '$locationInfo.district',
          district: { $first: '$locationInfo.district' },
          totalMachines: { $sum: 1 },
          totalBottlesCollected: { $sum: '$bottlesCollectedTotal' },
          totalGreenCoinsGenerated: { $sum: '$totalGreenCoinsGenerated' },
        },
      },
      { $sort: { totalBottlesCollected: -1 } },
    ]);

    if (report.length > 0) {
      return NextResponse.json({ report });
    }
  } catch (e) {
    console.warn('Serving mock district report fallback');
  }

  // Mock Aggregation
  const districtMap: Record<string, { district: string; totalMachines: number; totalBottlesCollected: number; totalGreenCoinsGenerated: number }> = {};

  for (const m of MOCK_MACHINES) {
    const dist = m.location.district;
    if (!districtMap[dist]) {
      districtMap[dist] = { district: dist, totalMachines: 0, totalBottlesCollected: 0, totalGreenCoinsGenerated: 0 };
    }
    districtMap[dist].totalMachines += 1;
    districtMap[dist].totalBottlesCollected += m.bottlesCollectedTotal;
    districtMap[dist].totalGreenCoinsGenerated += m.totalGreenCoinsGenerated;
  }

  const mockReport = Object.values(districtMap).sort((a, b) => b.totalBottlesCollected - a.totalBottlesCollected);
  return NextResponse.json({ report: mockReport });
}
