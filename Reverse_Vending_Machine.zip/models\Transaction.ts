import mongoose, { Schema, Document, Model } from 'mongoose';

export interface ITransaction extends Document {
  user: mongoose.Types.ObjectId;
  machine: mongoose.Types.ObjectId;
  bottlesDeposited: number;
  coinsEarned: number;
  timestamp: Date;
  status: 'success' | 'failed' | 'flagged';
  createdAt: Date;
  updatedAt: Date;
}

const TransactionSchema = new Schema<ITransaction>(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    machine: { type: Schema.Types.ObjectId, ref: 'Machine', required: true },
    bottlesDeposited: { type: Number, required: true },
    coinsEarned: { type: Number, required: true },
    timestamp: { type: Date, default: Date.now },
    status: {
      type: String,
      enum: ['success', 'failed', 'flagged'],
      default: 'success',
    },
  },
  { timestamps: true }
);

TransactionSchema.index({ user: 1, timestamp: -1 });
TransactionSchema.index({ machine: 1, timestamp: -1 });

export const Transaction: Model<ITransaction> =
  mongoose.models.Transaction || mongoose.model<ITransaction>('Transaction', TransactionSchema);
