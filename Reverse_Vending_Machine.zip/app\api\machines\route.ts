import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { Location } from '@/models/Location';
import { Employee } from '@/models/Employee';
import { createMachineSchema } from '@/lib/validators';
import { handleApiError } from '@/lib/apiError';
import { MOCK_MACHINES } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();
    const { searchParams } = new URL(req.url);
    const search = searchParams.get('search');
    const status = searchParams.get('status');
    const district = searchParams.get('district');
    const area = searchParams.get('area');

    const filter: any = {};
    if (search) {
      filter.$or = [{ machineId: new RegExp(search, 'i') }, { name: new RegExp(search, 'i') }];
    }
    if (status) filter.status = status;

    if (district || area) {
      const locFilter: any = {};
      if (district) locFilter.district = new RegExp(district, 'i');
      if (area) locFilter.area = new RegExp(area, 'i');
      const matchingLocs = await Location.find(locFilter).select('_id');
      const locIds = matchingLocs.map((l) => l._id);
      filter.location = { $in: locIds };
    }

    const machines = await Machine.find(filter)
      .populate('location')
      .populate('assignedEmployee', 'name email employeeId mobile')
      .sort({ createdAt: -1 });

    if (machines.length > 0) {
      return NextResponse.json({ machines });
    }
  } catch (e) {
    console.warn('Using mock machines fallback');
  }

  const { searchParams } = new URL(req.url);
  const search = searchParams.get('search');
  const status = searchParams.get('status');
  const district = searchParams.get('district');

  let filtered = [...MOCK_MACHINES];
  if (search) {
    filtered = filtered.filter(
      (m) =>
        m.machineId.toLowerCase().includes(search.toLowerCase()) ||
        m.name.toLowerCase().includes(search.toLowerCase())
    );
  }
  if (status) {
    filtered = filtered.filter((m) => m.status === status);
  }
  if (district) {
    filtered = filtered.filter((m) => m.location?.district?.toLowerCase() === district.toLowerCase());
  }

  return NextResponse.json({ machines: filtered });
}

export async function POST(req: NextRequest) {
  try {
    await connectToDatabase();
    const body = await req.json();
    const validatedData = createMachineSchema.parse(body);

    const locationObj = await Location.findById(validatedData.location);
    const machine = await Machine.create({
      machineId: validatedData.machineId.toUpperCase(),
      name: validatedData.name,
      location: validatedData.location,
      gps: validatedData.gps,
      storageCapacity: validatedData.storageCapacity,
      assignedEmployee: validatedData.assignedEmployee || null,
      installationDate: new Date(),
      status: 'active',
      connectivity: 'connected',
      sensorStatus: 'ok',
      powerStatus: 'on',
      lastSyncAt: new Date(),
    });

    return NextResponse.json({ success: true, machine }, { status: 201 });
  } catch (error) {
    return handleApiError(error);
  }
}
