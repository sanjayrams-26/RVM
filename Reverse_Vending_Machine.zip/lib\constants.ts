export const COINS_PER_BOTTLE = 5;

export const MACHINE_STATUSES = [
  'online',
  'offline',
  'active',
  'full',
  'under_maintenance',
  'damaged',
  'inactive',
] as const;

export type MachineStatus = (typeof MACHINE_STATUSES)[number];

export const MACHINE_STATUS_BADGES: Record<
  MachineStatus,
  { label: string; bgClass: string; textClass: string; borderClass: string }
> = {
  active: {
    label: 'Active',
    bgClass: 'bg-emerald-50',
    textClass: 'text-emerald-700',
    borderClass: 'border-emerald-200',
  },
  online: {
    label: 'Online',
    bgClass: 'bg-emerald-50',
    textClass: 'text-emerald-700',
    borderClass: 'border-emerald-200',
  },
  full: {
    label: 'Capacity Full',
    bgClass: 'bg-rose-50',
    textClass: 'text-rose-700',
    borderClass: 'border-rose-200',
  },
  offline: {
    label: 'Offline',
    bgClass: 'bg-slate-100',
    textClass: 'text-slate-700',
    borderClass: 'border-slate-200',
  },
  under_maintenance: {
    label: 'Under Maintenance',
    bgClass: 'bg-amber-50',
    textClass: 'text-amber-700',
    borderClass: 'border-amber-200',
  },
  damaged: {
    label: 'Damaged',
    bgClass: 'bg-red-100',
    textClass: 'text-red-800',
    borderClass: 'border-red-300',
  },
  inactive: {
    label: 'Inactive',
    bgClass: 'bg-zinc-100',
    textClass: 'text-zinc-600',
    borderClass: 'border-zinc-200',
  },
};

export const ALERT_SEVERITY_BADGES = {
  info: { label: 'Info', bgClass: 'bg-sky-50', textClass: 'text-sky-700', borderClass: 'border-sky-200' },
  warning: { label: 'Warning', bgClass: 'bg-amber-50', textClass: 'text-amber-700', borderClass: 'border-amber-200' },
  critical: { label: 'Critical', bgClass: 'bg-rose-50', textClass: 'text-rose-700', borderClass: 'border-rose-200' },
};

export const LOCATION_TYPES = [
  'street',
  'public_place',
  'station',
  'mall',
  'airport',
  'other',
] as const;

export const MAINTENANCE_SERVICE_TYPES = [
  'collection',
  'repair',
  'cleaning',
  'inspection',
  'other',
] as const;

export const MAINTENANCE_STATUSES = [
  'assigned',
  'in_progress',
  'completed',
  'cancelled',
] as const;
