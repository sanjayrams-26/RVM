import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IStorageLog extends Document {
  machine: mongoose.Types.ObjectId;
  storageLevel: number;
  storagePercent: number;
  timestamp: Date;
}

const StorageLogSchema = new Schema<IStorageLog>(
  {
    machine: { type: Schema.Types.ObjectId, ref: 'Machine', required: true },
    storageLevel: { type: Number, required: true },
    storagePercent: { type: Number, required: true },
    timestamp: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

StorageLogSchema.index({ machine: 1, timestamp: -1 });

export const StorageLog: Model<IStorageLog> =
  mongoose.models.StorageLog || mongoose.model<IStorageLog>('StorageLog', StorageLogSchema);
