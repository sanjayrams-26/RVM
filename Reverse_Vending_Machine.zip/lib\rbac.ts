import { NextRequest, NextResponse } from 'next/server';
import { getSessionFromCookies, TokenPayload, verifyAccessToken } from './auth';

export async function requireRole(
  req: NextRequest,
  allowedRoles: Array<'user' | 'admin' | 'employee'>
): Promise<{ user: TokenPayload } | NextResponse> {
  // First check cookie session
  let session = getSessionFromCookies();

  // If no cookie session, check Authorization header (Bearer token) if provided
  if (!session) {
    const authHeader = req.headers.get('authorization');
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      session = verifyAccessToken(token);
    }
  }

  if (!session) {
    return NextResponse.json(
      { error: { message: 'Unauthorized access', code: 'UNAUTHORIZED' } },
      { status: 401 }
    );
  }

  if (!allowedRoles.includes(session.role)) {
    return NextResponse.json(
      { error: { message: 'Forbidden: Insufficient permissions', code: 'FORBIDDEN' } },
      { status: 403 }
    );
  }

  return { user: session };
}
