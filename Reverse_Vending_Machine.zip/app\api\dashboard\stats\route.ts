import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { User } from '@/models/User';
import { GreenCoinLedger } from '@/models/GreenCoinLedger';
import { MOCK_MACHINES, MOCK_USERS } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();

    const [
      totalMachines,
      activeMachines,
      offlineMachines,
      machinesRequiringService,
      totalUsers,
      machineAgg,
      coinAgg,
    ] = await Promise.all([
      Machine.countDocuments(),
      Machine.countDocuments({ status: { $in: ['active', 'online'] } }),
      Machine.countDocuments({ status: 'offline' }),
      Machine.countDocuments({
        status: { $in: ['full', 'under_maintenance', 'damaged'] },
      }),
      User.countDocuments(),
      Machine.aggregate([
        {
          $group: {
            _id: null,
            totalBottles: { $sum: '$bottlesCollectedTotal' },
            totalCoinsGenerated: { $sum: '$totalGreenCoinsGenerated' },
          },
        },
      ]),
      GreenCoinLedger.aggregate([
        { $match: { type: 'redeem' } },
        {
          $group: {
            _id: null,
            totalRedeemed: { $sum: { $abs: '$amount' } },
          },
        },
      ]),
    ]);

    if (totalMachines > 0) {
      return NextResponse.json(
        {
          totalMachines,
          activeMachines,
          offlineMachines,
          machinesRequiringService,
          totalUsers,
          totalBottlesCollected: machineAgg[0]?.totalBottles || 0,
          totalGreenCoinsGenerated: machineAgg[0]?.totalCoinsGenerated || 0,
          totalGreenCoinsRedeemed: coinAgg[0]?.totalRedeemed || 0,
        },
        {
          headers: {
            'Cache-Control': 'private, max-age=5, stale-while-revalidate=15',
          },
        }
      );
    }
  } catch (e) {
    console.warn('Database offline or unpopulated, serving rich mock dashboard stats');
  }

  // Fallback Mock Stats
  const activeCount = MOCK_MACHINES.filter((m) => m.status === 'active' || m.status === 'online').length;
  const offlineCount = MOCK_MACHINES.filter((m) => m.status === 'offline').length;
  const serviceCount = MOCK_MACHINES.filter((m) => m.status === 'full' || m.status === 'under_maintenance' || m.status === 'damaged').length;
  const totalBottles = MOCK_MACHINES.reduce((acc, m) => acc + m.bottlesCollectedTotal, 0);
  const totalCoins = MOCK_MACHINES.reduce((acc, m) => acc + m.totalGreenCoinsGenerated, 0);

  return NextResponse.json({
    totalMachines: MOCK_MACHINES.length,
    activeMachines: activeCount,
    offlineMachines: offlineCount,
    machinesRequiringService: serviceCount,
    totalUsers: MOCK_USERS.length,
    totalBottlesCollected: totalBottles,
    totalGreenCoinsGenerated: totalCoins,
    totalGreenCoinsRedeemed: 450,
  });
}
