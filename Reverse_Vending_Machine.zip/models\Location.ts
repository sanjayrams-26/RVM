import mongoose, { Schema, Document, Model } from 'mongoose';

export interface ILocation extends Document {
  state: string;
  district: string;
  area: string;
  exactLocation: string;
  gps: { lat: number; lng: number };
  type: 'street' | 'public_place' | 'station' | 'mall' | 'airport' | 'other';
  createdAt: Date;
  updatedAt: Date;
}

const LocationSchema = new Schema<ILocation>(
  {
    state: { type: String, required: true, trim: true },
    district: { type: String, required: true, trim: true },
    area: { type: String, required: true, trim: true },
    exactLocation: { type: String, required: true, trim: true },
    gps: {
      lat: { type: Number, required: true },
      lng: { type: Number, required: true },
    },
    type: {
      type: String,
      enum: ['street', 'public_place', 'station', 'mall', 'airport', 'other'],
      default: 'public_place',
    },
  },
  { timestamps: true }
);

LocationSchema.index({ district: 1, area: 1 });

export const Location: Model<ILocation> =
  mongoose.models.Location || mongoose.model<ILocation>('Location', LocationSchema);
