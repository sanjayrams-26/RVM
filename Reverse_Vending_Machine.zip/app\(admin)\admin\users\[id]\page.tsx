'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { ArrowLeft, User, Mail, Phone, History, Coins, ShieldAlert } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminUserDetailPage({ params }: { params: { id: string } }) {
  const { data: userData, mutate } = useSWR(`/api/users/${params.id}`, fetcher);
  const { data: txData } = useSWR(`/api/users/${params.id}/transactions`, fetcher);
  const { data: coinsData } = useSWR(`/api/users/${params.id}/coins`, fetcher);

  const user = userData?.user;
  const transactions = txData?.transactions || [];
  const ledger = coinsData?.ledger || [];

  const [isLoading, setIsLoading] = useState(false);

  const toggleStatus = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      await fetch(`/api/users/${user._id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !user.isActive }),
      });
      mutate();
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return <div className="p-8 text-center text-slate-500">Loading user profile...</div>;
  }

  return (
    <div className="space-y-6">
      <Link href="/admin/users" className="inline-flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-700">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to Recyclers List
      </Link>

      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div>
          <h1 className="text-2xl font-black text-slate-900">{user.name}</h1>
          <p className="text-xs text-slate-500 mt-0.5">{user.email} • {user.mobile}</p>
          <p className="text-xs font-semibold text-emerald-600 mt-2">
            Joined: {new Date(user.registrationDate || user.createdAt).toLocaleDateString()}
          </p>
        </div>

        <Button
          onClick={toggleStatus}
          isLoading={isLoading}
          variant={user.isActive ? 'danger' : 'primary'}
        >
          {user.isActive ? 'Deactivate Account' : 'Activate Account'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <p className="text-xs font-bold text-slate-400 uppercase">Current Balance</p>
          <h3 className="text-2xl font-black text-emerald-600 mt-1">{user.currentBalance} Coins</h3>
        </Card>
        <Card>
          <p className="text-xs font-bold text-slate-400 uppercase">Bottles Recycled</p>
          <h3 className="text-2xl font-black text-slate-800 mt-1">{user.totalBottlesRecycled}</h3>
        </Card>
        <Card>
          <p className="text-xs font-bold text-slate-400 uppercase">Coins Earned</p>
          <h3 className="text-2xl font-black text-slate-800 mt-1">{user.totalGreenCoinsEarned}</h3>
        </Card>
        <Card>
          <p className="text-xs font-bold text-slate-400 uppercase">Coins Redeemed</p>
          <h3 className="text-2xl font-black text-slate-800 mt-1">{user.greenCoinsRedeemed}</h3>
        </Card>
      </div>

      <Card title="User Deposit History">
        {transactions.length === 0 ? (
          <div className="text-center py-8 text-slate-400">No deposit history for this user.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold text-slate-400 uppercase bg-slate-50">
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Machine</th>
                  <th className="py-2.5 px-3">Bottles</th>
                  <th className="py-2.5 px-3 text-right">Coins</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {transactions.map((tx: any) => (
                  <tr key={tx._id}>
                    <td className="py-2.5 px-3">{new Date(tx.timestamp).toLocaleString()}</td>
                    <td className="py-2.5 px-3 font-bold">{tx.machine?.machineId}</td>
                    <td className="py-2.5 px-3">{tx.bottlesDeposited}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-emerald-600">+{tx.coinsEarned}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
