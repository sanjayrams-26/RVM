'use client';

import React from 'react';
import useSWR from 'swr';
import { History, Download } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminTransactionsPage() {
  const { data, isLoading } = useSWR('/api/transactions', fetcher);
  const transactions = data?.transactions || [];

  const handleExportCSV = () => {
    window.open('/api/reports/export?type=transactions', '_blank');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">Network Transactions Log</h1>
          <p className="text-xs text-slate-500 mt-1">Audit log of all bottle deposits and Green Coin issuances across the platform</p>
        </div>
        <Button onClick={handleExportCSV} variant="outline">
          <Download className="w-4 h-4 mr-2" /> Export CSV
        </Button>
      </div>

      <Card>
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading transactions...</div>
        ) : transactions.length === 0 ? (
          <div className="text-center py-12 text-slate-400">No transactions recorded.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">Timestamp</th>
                  <th className="py-3.5 px-4">User</th>
                  <th className="py-3.5 px-4">Machine ID</th>
                  <th className="py-3.5 px-4">Location</th>
                  <th className="py-3.5 px-4">Bottles</th>
                  <th className="py-3.5 px-4 text-right">Coins Issued</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {transactions.map((tx: any) => (
                  <tr key={tx._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 text-slate-600 font-medium">
                      {new Date(tx.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-800">
                      <div>{tx.user?.name || 'User'}</div>
                      <div className="text-xs text-slate-400">{tx.user?.mobile}</div>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-indigo-700">
                      {tx.machine?.machineId || 'RVM Unit'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {tx.machine?.location?.district}, {tx.machine?.location?.area}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-800">{tx.bottlesDeposited} bottles</td>
                    <td className="py-3.5 px-4 text-right font-black text-emerald-600">
                      +{tx.coinsEarned} Coins
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
