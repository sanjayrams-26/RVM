import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { requireRole } from '@/lib/rbac';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireRole(req, ['admin']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();

    const machines = await Machine.find()
      .populate('location')
      .populate('assignedEmployee', 'name employeeId')
      .sort({ bottlesCollectedTotal: -1 });

    const report = machines.map((m) => ({
      machineId: m.machineId,
      name: m.name,
      district: (m.location as any)?.district || 'N/A',
      area: (m.location as any)?.area || 'N/A',
      status: m.status,
      storageCapacity: m.storageCapacity,
      currentStorageLevel: m.currentStorageLevel,
      storagePercent: m.storagePercent,
      bottlesCollectedTotal: m.bottlesCollectedTotal,
      uniqueUsersCount: m.uniqueUsersCount,
      totalGreenCoinsGenerated: m.totalGreenCoinsGenerated,
      assignedEmployee: (m.assignedEmployee as any)?.name || 'Unassigned',
    }));

    return NextResponse.json({ report });
  } catch (error) {
    return handleApiError(error);
  }
}
