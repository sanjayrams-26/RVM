import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Transaction } from '@/models/Transaction';
import { requireRole } from '@/lib/rbac';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireRole(req, ['admin']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const { searchParams } = new URL(req.url);
    const dateStr = searchParams.get('date');

    const startDate = dateStr ? new Date(dateStr) : new Date();
    startDate.setHours(0, 0, 0, 0);

    const endDate = new Date(startDate);
    endDate.setHours(23, 59, 59, 999);

    const report = await Transaction.aggregate([
      {
        $match: {
          timestamp: { $gte: startDate, $lte: endDate },
        },
      },
      {
        $group: {
          _id: { $hour: '$timestamp' },
          hour: { $first: { $hour: '$timestamp' } },
          totalTransactions: { $sum: 1 },
          totalBottles: { $sum: '$bottlesDeposited' },
          totalCoins: { $sum: '$coinsEarned' },
        },
      },
      { $sort: { hour: 1 } },
    ]);

    return NextResponse.json({ date: startDate.toISOString().split('T')[0], report });
  } catch (error) {
    return handleApiError(error);
  }
}
