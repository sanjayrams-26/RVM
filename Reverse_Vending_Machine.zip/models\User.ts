import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IUser extends Document {
  name: string;
  email: string;
  mobile: string;
  passwordHash: string;
  registrationDate: Date;
  totalBottlesRecycled: number;
  totalGreenCoinsEarned: number;
  greenCoinsRedeemed: number;
  greenCoinsWithdrawn: number;
  currentBalance: number;
  isActive: boolean;
  role: 'user';
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema = new Schema<IUser>(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    mobile: { type: String, required: true, unique: true, trim: true },
    passwordHash: { type: String, required: true, select: false },
    registrationDate: { type: Date, default: Date.now },
    totalBottlesRecycled: { type: Number, default: 0 },
    totalGreenCoinsEarned: { type: Number, default: 0 },
    greenCoinsRedeemed: { type: Number, default: 0 },
    greenCoinsWithdrawn: { type: Number, default: 0 },
    currentBalance: { type: Number, default: 0 },
    isActive: { type: Boolean, default: true },
    role: { type: String, default: 'user', immutable: true },
  },
  { timestamps: true }
);

UserSchema.index({ email: 1 });
UserSchema.index({ mobile: 1 });

export const User: Model<IUser> =
  mongoose.models.User || mongoose.model<IUser>('User', UserSchema);
