'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { History, Calendar, Coins, Recycle } from 'lucide-react';
import { Card } from '@/components/ui/Card';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function UserTransactionsPage() {
  const { data, isLoading } = useSWR('/api/transactions', fetcher);
  const transactions = data?.transactions || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-slate-900">Recycling History</h1>
        <p className="text-xs text-slate-500 mt-1">Complete log of plastic bottle deposits and earned Green Coins</p>
      </div>

      <Card>
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading transaction history...</div>
        ) : transactions.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <History className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="font-bold">No transactions found.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">Timestamp</th>
                  <th className="py-3.5 px-4">Machine ID</th>
                  <th className="py-3.5 px-4">Location</th>
                  <th className="py-3.5 px-4">Bottles Deposited</th>
                  <th className="py-3.5 px-4 text-right">Coins Earned</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {transactions.map((tx: any) => (
                  <tr key={tx._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-medium text-slate-700">
                      {new Date(tx.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-800">
                      {tx.machine?.machineId || 'RVM Machine'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {tx.machine?.location?.district}, {tx.machine?.location?.area}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-700">{tx.bottlesDeposited} bottles</td>
                    <td className="py-3.5 px-4 text-right font-black text-emerald-600">
                      +{tx.coinsEarned} Green Coins
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
