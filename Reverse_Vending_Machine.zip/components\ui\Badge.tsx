import React from 'react';
import { MACHINE_STATUS_BADGES, ALERT_SEVERITY_BADGES, MachineStatus } from '@/lib/constants';

interface BadgeProps {
  status?: MachineStatus | string;
  severity?: 'info' | 'warning' | 'critical' | string;
  label?: string;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ status, severity, label, className = '' }) => {
  if (status && MACHINE_STATUS_BADGES[status as MachineStatus]) {
    const config = MACHINE_STATUS_BADGES[status as MachineStatus];
    return (
      <span
        className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${config.bgClass} ${config.textClass} ${config.borderClass} ${className}`}
      >
        <span className="w-1.5 h-1.5 rounded-full mr-1.5 bg-current animate-pulse" />
        {config.label}
      </span>
    );
  }

  if (severity && ALERT_SEVERITY_BADGES[severity as keyof typeof ALERT_SEVERITY_BADGES]) {
    const config = ALERT_SEVERITY_BADGES[severity as keyof typeof ALERT_SEVERITY_BADGES];
    return (
      <span
        className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${config.bgClass} ${config.textClass} ${config.borderClass} ${className}`}
      >
        {config.label}
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800 border border-gray-200 ${className}`}
    >
      {label || status || severity || 'Unknown'}
    </span>
  );
};
