import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { User } from '@/models/User';
import { MOCK_USERS } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();
    const dbUsers = await User.find().select('-passwordHash').sort({ createdAt: -1 });
    if (dbUsers.length > 0) {
      return NextResponse.json({ users: dbUsers });
    }
  } catch (e) {
    console.warn('Serving mock users fallback');
  }

  const { searchParams } = new URL(req.url);
  const search = searchParams.get('search');
  let filtered = [...MOCK_USERS];
  if (search) {
    filtered = filtered.filter(
      (u) =>
        u.name.toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase())
    );
  }

  return NextResponse.json({ users: filtered });
}
