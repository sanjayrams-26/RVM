import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { GreenCoinLedger } from '@/models/GreenCoinLedger';
import { requireRole } from '@/lib/rbac';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin', 'user']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const ledger = await GreenCoinLedger.find({ user: params.id })
      .populate('relatedMachine')
      .sort({ createdAt: -1 });

    return NextResponse.json({ ledger });
  } catch (error) {
    return handleApiError(error);
  }
}
