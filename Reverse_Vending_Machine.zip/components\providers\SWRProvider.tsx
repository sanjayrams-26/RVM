'use client';

import React from 'react';
import { SWRConfig } from 'swr';

const defaultFetcher = (url: string) => fetch(url).then((res) => res.json());

export function SWRProvider({ children }: { children: React.ReactNode }) {
  return (
    <SWRConfig
      value={{
        fetcher: defaultFetcher,
        dedupingInterval: 4000,
        revalidateOnFocus: false,
        revalidateIfStale: false,
        keepPreviousData: true,
      }}
    >
      {children}
    </SWRConfig>
  );
}
