'use client';

import React from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { ArrowLeft, MapPin, Cpu, Calendar, ShieldCheck, Activity } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function UserMachineDetailPage({ params }: { params: { id: string } }) {
  const { data, isLoading } = useSWR(`/api/machines/${params.id}`, fetcher);
  const machine = data?.machine;

  if (isLoading) {
    return <div className="p-8 text-center text-slate-500">Loading machine details...</div>;
  }

  if (!machine) {
    return <div className="p-8 text-center text-slate-500">Machine not found.</div>;
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <Link href="/user/machines" className="inline-flex items-center text-xs font-bold text-emerald-600 hover:text-emerald-700">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to Machine Locator
      </Link>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <div className="flex items-center space-x-3 mb-2">
              <h1 className="text-2xl font-black text-slate-900">{machine.name}</h1>
              <Badge status={machine.status} />
            </div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{machine.machineId}</p>
          </div>
        </div>

        {/* Location Box */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 space-y-2">
          <div className="flex items-center space-x-2 text-slate-800 font-bold text-sm">
            <MapPin className="w-4 h-4 text-emerald-600" />
            <span>
              {machine.location?.district}, {machine.location?.area} ({machine.location?.state})
            </span>
          </div>
          <p className="text-xs text-slate-500 pl-6">{machine.location?.exactLocation}</p>
          <p className="text-[11px] text-slate-400 pl-6 pt-1">
            GPS Coordinates: {machine.gps?.lat}, {machine.gps?.lng}
          </p>
        </div>

        {/* Storage Fill Meter */}
        <Card title="Live Storage Capacity" subtitle="Updated continuously via IoT sensor telemetry">
          <div className="space-y-2">
            <div className="flex justify-between text-sm font-bold text-slate-700">
              <span>Current Level: {machine.currentStorageLevel} / {machine.storageCapacity} bottles</span>
              <span className="text-emerald-600">{machine.storagePercent}% Capacity</span>
            </div>
            <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden p-0.5 border border-slate-200">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  machine.storagePercent >= 90
                    ? 'bg-rose-500'
                    : machine.storagePercent >= 80
                    ? 'bg-amber-500'
                    : 'bg-emerald-500'
                }`}
                style={{ width: `${machine.storagePercent}%` }}
              />
            </div>
          </div>
        </Card>

        {/* Metadata Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <p className="text-slate-400 font-bold uppercase mb-1">Total Bottles Collected</p>
            <p className="text-lg font-black text-slate-800">{machine.bottlesCollectedTotal}</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <p className="text-slate-400 font-bold uppercase mb-1">Green Coins Issued</p>
            <p className="text-lg font-black text-emerald-600">{machine.totalGreenCoinsGenerated}</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <p className="text-slate-400 font-bold uppercase mb-1">Last Sync</p>
            <p className="text-sm font-bold text-slate-700">
              {machine.lastSyncAt ? new Date(machine.lastSyncAt).toLocaleTimeString() : 'Online'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
