'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { ArrowLeft, Cpu, MapPin, Wrench, Shield, CheckCircle2, AlertTriangle, Trash2 } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminMachineDetailPage({ params }: { params: { id: string } }) {
  const { data: machineData, mutate } = useSWR(`/api/machines/${params.id}`, fetcher);
  const { data: historyData } = useSWR(`/api/machines/${params.id}/storage-history`, fetcher);
  const { data: employeesData } = useSWR('/api/employees', fetcher);

  const machine = machineData?.machine;
  const history = historyData?.history || [];
  const employees = employeesData?.employees || [];

  const [assignedEmployee, setAssignedEmployee] = useState('');
  const [statusOverride, setStatusOverride] = useState('');
  const [statusMsg, setStatusMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  React.useEffect(() => {
    if (machine) {
      setAssignedEmployee(machine.assignedEmployee?._id || '');
      setStatusOverride(machine.status || 'active');
    }
  }, [machine]);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setStatusMsg('');

    try {
      const res = await fetch(`/api/machines/${params.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assignedEmployee: assignedEmployee || null,
          status: statusOverride,
        }),
      });

      if (res.ok) {
        setStatusMsg('Machine settings updated!');
        mutate();
      } else {
        setStatusMsg('Failed to update machine.');
      }
    } catch {
      setStatusMsg('An error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!machine) {
    return <div className="p-8 text-center text-slate-500">Loading machine details...</div>;
  }

  return (
    <div className="space-y-6">
      <Link href="/admin/machines" className="inline-flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-700">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to Machine Fleet
      </Link>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <h1 className="text-2xl font-black text-slate-900">{machine.name}</h1>
            <Badge status={machine.status} />
          </div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">{machine.machineId}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Details & Storage Meter */}
        <div className="lg:col-span-2 space-y-6">
          <Card title="Hardware Telemetry & Storage Level">
            <div className="space-y-4">
              <div className="flex justify-between text-sm font-bold text-slate-700">
                <span>Current Capacity Level: {machine.currentStorageLevel} / {machine.storageCapacity} bottles</span>
                <span className="text-emerald-600 font-extrabold">{machine.storagePercent}%</span>
              </div>
              <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden p-0.5 border border-slate-200">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    machine.storagePercent >= 90
                      ? 'bg-rose-500'
                      : machine.storagePercent >= 80
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                  }`}
                  style={{ width: `${machine.storagePercent}%` }}
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-100 text-xs">
                <div className="bg-slate-50 p-3 rounded-xl">
                  <p className="text-slate-400 font-bold uppercase">Sensor Status</p>
                  <p className="font-extrabold text-slate-800 uppercase mt-0.5">{machine.sensorStatus}</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl">
                  <p className="text-slate-400 font-bold uppercase">Power State</p>
                  <p className="font-extrabold text-slate-800 uppercase mt-0.5">{machine.powerStatus}</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl">
                  <p className="text-slate-400 font-bold uppercase">Connectivity</p>
                  <p className="font-extrabold text-slate-800 uppercase mt-0.5">{machine.connectivity}</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl">
                  <p className="text-slate-400 font-bold uppercase">Unique Recyclers</p>
                  <p className="font-extrabold text-indigo-600 mt-0.5">{machine.uniqueUsersCount}</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Location details */}
          <Card title="Linked Location Node">
            <div className="text-sm space-y-1 text-slate-700">
              <p className="font-bold">{machine.location?.district}, {machine.location?.area}</p>
              <p className="text-slate-500 text-xs">{machine.location?.exactLocation}</p>
              <p className="text-xs text-slate-400">GPS: {machine.gps?.lat}, {machine.gps?.lng}</p>
            </div>
          </Card>
        </div>

        {/* Management Controls */}
        <div>
          <Card title="Admin Controls">
            {statusMsg && (
              <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl">
                {statusMsg}
              </div>
            )}

            <form onSubmit={handleUpdate} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Status Override</label>
                <select
                  value={statusOverride}
                  onChange={(e) => setStatusOverride(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                >
                  <option value="active">Active</option>
                  <option value="full">Full</option>
                  <option value="offline">Offline</option>
                  <option value="under_maintenance">Under Maintenance</option>
                  <option value="damaged">Damaged</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Assigned Field Technician</label>
                <select
                  value={assignedEmployee}
                  onChange={(e) => setAssignedEmployee(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                >
                  <option value="">Unassigned</option>
                  {employees.map((emp: any) => (
                    <option key={emp._id} value={emp._id}>
                      {emp.name} ({emp.employeeId})
                    </option>
                  ))}
                </select>
              </div>

              <Button type="submit" isLoading={isLoading} className="w-full py-2.5">
                Save Changes
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </div>
  );
}
