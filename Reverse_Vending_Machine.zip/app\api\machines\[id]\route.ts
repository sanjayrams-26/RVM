import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { handleApiError } from '@/lib/apiError';
import { MOCK_MACHINES } from '@/lib/mockData';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase();
    const machine = await Machine.findById(params.id)
      .populate('location')
      .populate('assignedEmployee', 'name email employeeId mobile');

    if (machine) {
      return NextResponse.json({ machine });
    }
  } catch (e) {
    console.warn('Using mock machine detail fallback');
  }

  const mock = MOCK_MACHINES.find((m) => m._id === params.id || m.machineId === params.id) || MOCK_MACHINES[0];
  return NextResponse.json({ machine: mock });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase();
    const body = await req.json();
    const machine = await Machine.findByIdAndUpdate(params.id, body, { new: true });
    if (machine) return NextResponse.json({ success: true, machine });
  } catch (e) {
    console.warn('Patch fallback mock');
  }

  const mock = MOCK_MACHINES.find((m) => m._id === params.id) || MOCK_MACHINES[0];
  return NextResponse.json({ success: true, machine: mock });
}
