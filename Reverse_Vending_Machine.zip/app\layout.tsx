import type { Metadata } from 'next';
import { SWRProvider } from '@/components/providers/SWRProvider';
import './globals.css';

export const metadata: Metadata = {
  title: 'rvm',
  description: 'Centralized management platform for IoT Reverse Vending Machines. Deposit plastic bottles and earn Green Coins.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="h-full bg-slate-50 text-slate-900">
      <body className="min-h-full flex flex-col antialiased bg-slate-50">
        <SWRProvider>{children}</SWRProvider>
      </body>
    </html>
  );
}
