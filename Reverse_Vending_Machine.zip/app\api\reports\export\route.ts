import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { Transaction } from '@/models/Transaction';
import { requireRole } from '@/lib/rbac';
import { convertToCSV } from '@/lib/exportCsv';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireRole(req, ['admin']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const { searchParams } = new URL(req.url);
    const type = searchParams.get('type') || 'machines';

    let data: any[] = [];
    let filename = `${type}_report_${new Date().toISOString().split('T')[0]}.csv`;

    if (type === 'district') {
      data = await Machine.aggregate([
        {
          $lookup: {
            from: 'locations',
            localField: 'location',
            foreignField: '_id',
            as: 'locationInfo',
          },
        },
        { $unwind: '$locationInfo' },
        {
          $group: {
            _id: '$locationInfo.district',
            District: { $first: '$locationInfo.district' },
            Total_Machines: { $sum: 1 },
            Total_Bottles_Collected: { $sum: '$bottlesCollectedTotal' },
            Total_GreenCoins_Generated: { $sum: '$totalGreenCoinsGenerated' },
          },
        },
      ]);
    } else if (type === 'machines') {
      const machines = await Machine.find()
        .populate('location')
        .populate('assignedEmployee', 'name employeeId');

      data = machines.map((m) => ({
        Machine_ID: m.machineId,
        Name: m.name,
        District: (m.location as any)?.district || 'N/A',
        Area: (m.location as any)?.area || 'N/A',
        Status: m.status,
        Storage_Capacity: m.storageCapacity,
        Current_Storage_Level: m.currentStorageLevel,
        Storage_Percent: m.storagePercent,
        Bottles_Collected: m.bottlesCollectedTotal,
        Unique_Users: m.uniqueUsersCount,
        GreenCoins_Generated: m.totalGreenCoinsGenerated,
        Assigned_Employee: (m.assignedEmployee as any)?.name || 'Unassigned',
      }));
    } else {
      const txs = await Transaction.find()
        .populate('user', 'name email mobile')
        .populate('machine', 'machineId name');

      data = txs.map((t) => ({
        Transaction_ID: t._id,
        User_Name: (t.user as any)?.name || 'N/A',
        User_Mobile: (t.user as any)?.mobile || 'N/A',
        Machine_ID: (t.machine as any)?.machineId || 'N/A',
        Bottles_Deposited: t.bottlesDeposited,
        Coins_Earned: t.coinsEarned,
        Timestamp: t.timestamp.toISOString(),
      }));
    }

    const csvContent = convertToCSV(data);

    return new NextResponse(csvContent, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
