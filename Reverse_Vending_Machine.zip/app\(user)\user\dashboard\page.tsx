'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { Recycle, Coins, Wallet, History, PlusCircle, ArrowUpRight, CheckCircle2, Sparkles } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { NaviScratchCardModal } from '@/components/ui/NaviScratchCardModal';
import { NaviRewardCalculation } from '@/lib/naviRewardEngine';
import Link from 'next/link';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function UserDashboard() {
  const { data: balanceData, mutate: mutateBalance } = useSWR('/api/greencoins/balance', fetcher);
  const { data: txData, mutate: mutateTx } = useSWR('/api/transactions', fetcher);
  const { data: machinesData } = useSWR('/api/machines', fetcher);

  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState('');
  const [bottlesCount, setBottlesCount] = useState(3);
  const [depositStatus, setDepositStatus] = useState<string | null>(null);
  const [isDepositing, setIsDepositing] = useState(false);

  // Navi Scratch Card Modal State
  const [isNaviModalOpen, setIsNaviModalOpen] = useState(false);
  const [activeNaviReward, setActiveNaviReward] = useState<NaviRewardCalculation | null>(null);
  const [activeMachineName, setActiveMachineName] = useState<string>('RVM Machine');

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMachine) return;

    setIsDepositing(true);
    setDepositStatus(null);

    try {
      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          machineId: selectedMachine,
          bottlesDeposited: Number(bottlesCount),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setDepositStatus(data.error?.message || 'Deposit failed');
      } else {
        setDepositStatus(`Success! You earned Green Coins via Navi Random Reward Engine!`);
        mutateBalance();
        mutateTx();

        const selectedMachineObj = machines.find((m: any) => m._id === selectedMachine);
        setActiveMachineName(selectedMachineObj ? `${selectedMachineObj.machineId} (${selectedMachineObj.location?.district})` : 'RVM Machine');

        if (data.naviReward) {
          setActiveNaviReward(data.naviReward);
          setTimeout(() => {
            setIsDepositModalOpen(false);
            setDepositStatus(null);
            setIsNaviModalOpen(true);
          }, 600);
        } else {
          setTimeout(() => {
            setIsDepositModalOpen(false);
            setDepositStatus(null);
          }, 1800);
        }
      }
    } catch {
      setDepositStatus('An error occurred during deposit.');
    } finally {
      setIsDepositing(false);
    }
  };


  const balance = balanceData?.balance ?? 0;
  const totalEarned = balanceData?.totalEarned ?? 0;
  const totalBottles = balanceData?.totalBottles ?? 0;
  const totalRedeemed = balanceData?.totalRedeemed ?? 0;
  const transactions = txData?.transactions || [];
  const machines = machinesData?.machines || [];

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between bg-gradient-to-r from-emerald-600 to-teal-700 rounded-3xl p-8 text-white shadow-xl shadow-emerald-100">
        <div>
          <span className="px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold uppercase tracking-wider">
            Recycler Overview
          </span>
          <h1 className="text-3xl font-black mt-2">Welcome Back!</h1>
          <p className="text-emerald-100 text-sm mt-1 max-w-lg">
            Every bottle recycled reduces plastic waste and earns Green Coins. Deposit at any nearby RVM machine.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-emerald-50/80 to-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Green Coins Balance</p>
              <h3 className="text-3xl font-black text-emerald-600 mt-2">{balance}</h3>
              <p className="text-[11px] text-slate-400 mt-1">Available for redemption</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-600">
              <Wallet className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Bottles Recycled</p>
              <h3 className="text-3xl font-black text-slate-800 mt-2">{totalBottles}</h3>
              <p className="text-[11px] text-emerald-600 font-semibold mt-1">Total lifetime impact</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-sky-100 flex items-center justify-center text-sky-600">
              <Recycle className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Coins Earned</p>
              <h3 className="text-3xl font-black text-slate-800 mt-2">{totalEarned}</h3>
              <p className="text-[11px] text-slate-400 mt-1">Lifetime total earned</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-600">
              <Coins className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Coins Redeemed</p>
              <h3 className="text-3xl font-black text-slate-800 mt-2">{totalRedeemed}</h3>
              <p className="text-[11px] text-slate-400 mt-1">Converted to rewards</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-indigo-100 flex items-center justify-center text-indigo-600">
              <ArrowUpRight className="w-6 h-6" />
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Activity Table */}
      <Card title="Recent Deposit Activity" subtitle="Your latest recycling transactions across RVM machines">
        {transactions.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <History className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p className="text-sm font-semibold">No recycling transactions recorded yet.</p>
            <p className="text-xs mt-1">Deposit bottles at any nearby RVM machine to earn Green Coins!</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50/50">
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Machine ID</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4">Bottles</th>
                  <th className="py-3 px-4 text-right">Coins Earned</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {transactions.slice(0, 5).map((tx: any) => (
                  <tr key={tx._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-medium text-slate-700">
                      {new Date(tx.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-800">
                      {tx.machine?.machineId || 'RVM-CBE-001'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {tx.machine?.location?.district}, {tx.machine?.location?.area}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-700">{tx.bottlesDeposited} bottles</td>
                    <td className="py-3.5 px-4 text-right font-extrabold text-emerald-600">
                      +{tx.coinsEarned} Coins
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Simulation Deposit Modal */}
      <Modal
        isOpen={isDepositModalOpen}
        onClose={() => setIsDepositModalOpen(false)}
        title="Simulate RVM Bottle Deposit"
      >
        <form onSubmit={handleDepositSubmit} className="space-y-4">
          <p className="text-xs text-slate-500">
            Select a machine in the network and specify the number of plastic bottles inserted.
          </p>

          {depositStatus && (
            <div
              className={`p-3.5 rounded-xl text-xs font-bold ${
                depositStatus.startsWith('Success')
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : 'bg-rose-50 text-rose-700 border border-rose-200'
              }`}
            >
              {depositStatus}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Select Machine</label>
            <select
              required
              value={selectedMachine}
              onChange={(e) => setSelectedMachine(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">-- Choose RVM Machine --</option>
              {machines.map((m: any) => (
                <option key={m._id} value={m._id}>
                  {m.machineId} ({m.location?.district} - {m.location?.area}) - Storage: {m.storagePercent}%
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Bottles Deposited</label>
            <input
              type="number"
              min={1}
              max={50}
              required
              value={bottlesCount}
              onChange={(e) => setBottlesCount(Number(e.target.value))}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <p className="text-[11px] text-amber-700 font-bold mt-1.5 flex items-center">
              <Sparkles className="w-3.5 h-3.5 mr-1 text-amber-500" />
              Dynamic Reward: Navi Random Engine (Scratch card reveal on deposit)
            </p>
          </div>

          <Button type="submit" isLoading={isDepositing} className="w-full py-3">
            Confirm & Deposit
          </Button>
        </form>
      </Modal>

      {/* Navi Scratch Card Reveal Modal */}
      <NaviScratchCardModal
        isOpen={isNaviModalOpen}
        onClose={() => setIsNaviModalOpen(false)}
        rewardData={activeNaviReward}
        machineName={activeMachineName}
      />
    </div>
  );
}

