'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { User, Phone, Check } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function EmployeeProfilePage() {
  const { data, mutate } = useSWR('/api/auth/me', fetcher);
  const profile = data?.profile;

  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [statusMsg, setStatusMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  React.useEffect(() => {
    if (profile) {
      setName(profile.name || '');
      setMobile(profile.mobile || '');
    }
  }, [profile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile?._id) return;

    setIsLoading(true);
    setStatusMsg('');

    try {
      const res = await fetch(`/api/employees/${profile._id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, mobile }),
      });

      if (res.ok) {
        setStatusMsg('Profile details updated!');
        mutate();
      } else {
        setStatusMsg('Failed to update profile.');
      }
    } catch {
      setStatusMsg('An error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div>
        <h1 className="text-2xl font-black text-slate-900">Technician Profile</h1>
        <p className="text-xs text-slate-500 mt-1">Manage field credentials and mobile contact info</p>
      </div>

      <Card>
        {statusMsg && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center">
            <Check className="w-4 h-4 mr-2" /> {statusMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Employee ID (Read Only)</label>
            <input
              type="text"
              disabled
              value={profile?.employeeId || ''}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-amber-50 text-amber-900 font-extrabold cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Full Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Email</label>
            <input
              type="email"
              disabled
              value={profile?.email || ''}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-slate-100 text-slate-500 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Mobile Contact</label>
            <input
              type="text"
              required
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="pt-2">
            <Button type="submit" isLoading={isLoading} className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold">
              Save Technician Profile
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
