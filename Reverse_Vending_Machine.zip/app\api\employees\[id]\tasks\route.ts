import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Maintenance } from '@/models/Maintenance';
import { Alert } from '@/models/Alert';
import { requireRole } from '@/lib/rbac';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin', 'employee']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();

    const tasks = await Maintenance.find({ employee: params.id })
      .populate({
        path: 'machine',
        populate: { path: 'location' },
      })
      .sort({ createdAt: -1 });

    const alerts = await Alert.find({ assignedEmployee: params.id, isResolved: false })
      .populate({
        path: 'machine',
        populate: { path: 'location' },
      })
      .sort({ createdAt: -1 });

    return NextResponse.json({ tasks, alerts });
  } catch (error) {
    return handleApiError(error);
  }
}
