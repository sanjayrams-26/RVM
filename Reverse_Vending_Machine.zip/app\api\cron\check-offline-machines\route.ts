import { NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { Alert } from '@/models/Alert';

export async function GET() {
  try {
    await connectToDatabase();

    const thirtyMinsAgo = new Date(Date.now() - 30 * 60 * 1000);

    const offlineMachines = await Machine.find({
      $or: [{ lastSyncAt: { $lt: thirtyMinsAgo } }, { lastSyncAt: { $exists: false } }],
      connectivity: 'connected',
    });

    let count = 0;
    for (const machine of offlineMachines) {
      machine.connectivity = 'disconnected';
      machine.status = 'offline';
      await machine.save();

      // Prevent duplicate offline alert
      const existingAlert = await Alert.findOne({
        machine: machine._id,
        type: 'offline',
        isResolved: false,
      });

      if (!existingAlert) {
        await Alert.create({
          machine: machine._id,
          type: 'offline',
          message: `Machine ${machine.machineId} lost connectivity. Last heartbeat > 30 mins ago.`,
          severity: 'critical',
          assignedEmployee: machine.assignedEmployee || undefined,
        });
      }
      count++;
    }

    return NextResponse.json({
      success: true,
      message: `Scanned machines. ${count} machine(s) marked offline.`,
      markedOfflineCount: count,
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: { message: error.message || 'Cron execution failed' } },
      { status: 500 }
    );
  }
}
