'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { LogOut, User as UserIcon, Recycle } from 'lucide-react';

interface NavbarProps {
  userName?: string;
  role?: 'user' | 'admin' | 'employee';
}

export const Navbar: React.FC<NavbarProps> = ({ userName = 'Guest', role = 'user' }) => {
  const router = useRouter();

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/login');
      router.refresh();
    } catch (error) {
      console.error('Logout error', error);
    }
  };

  const roleColors = {
    user: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    admin: 'bg-indigo-100 text-indigo-800 border-indigo-200',
    employee: 'bg-amber-100 text-amber-800 border-amber-200',
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-30 shadow-xs">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-md shadow-emerald-200">
          <Recycle className="w-6 h-6 animate-spin-slow" />
        </div>
        <div>
          <span className="font-extrabold text-lg text-slate-800 tracking-tight">RVM Green Coin</span>
          <span className="text-xs text-emerald-600 font-bold ml-1.5 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-100">
            IoT Eco Network
          </span>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full uppercase border ${roleColors[role]}`}>
          {role}
        </span>
        <div className="flex items-center space-x-2 border-l border-slate-200 pl-4">
          <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-600 font-bold text-sm">
            {userName.charAt(0).toUpperCase()}
          </div>
          <span className="text-sm font-semibold text-slate-700 hidden sm:inline">{userName}</span>
        </div>

        <button
          onClick={handleLogout}
          title="Logout"
          className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
        >
          <LogOut className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};
