export interface BottleRewardResult {
  bottleNumber: number;
  tier: 'bronze' | 'silver' | 'gold' | 'jackpot';
  coins: number;
  message: string;
  isJackpot: boolean;
}

export interface NaviRewardCalculation {
  totalBottles: number;
  bottleBreakdown: BottleRewardResult[];
  baseCoins: number;
  streakBonus: number;
  totalCoinsEarned: number;
  highestTier: 'bronze' | 'silver' | 'gold' | 'jackpot';
  hasJackpot: boolean;
}

export interface NaviScratchCashbackResult {
  tier: 'bronze' | 'silver' | 'gold' | 'jackpot';
  cashbackCoins: number;
  multiplier: number;
  message: string;
}

/**
 * Navi App Redeem Algorithm Concept:
 * Calculates random coin reward for EACH bottle inserted based on dynamic probabilistic tiers.
 * 
 * - Bronze Tier (65% probability): 2 - 5 coins per bottle
 * - Silver Tier (22% probability): 6 - 10 coins per bottle
 * - Gold Tier (10% probability): 11 - 15 coins per bottle
 * - Mega Jackpot Tier (3% probability): 16 - 30 coins per bottle
 * 
 * Includes Navi Streak Multiplier:
 * - 3 - 4 bottles: +10% streak bonus
 * - 5 - 9 bottles: +15% streak bonus
 * - 10+ bottles: +25% streak bonus
 */
export function calculateNaviRandomCoins(bottlesDeposited: number): NaviRewardCalculation {
  const bottleBreakdown: BottleRewardResult[] = [];
  let baseCoinsSum = 0;
  let hasJackpot = false;
  let highestTierRank = 0; // 0: bronze, 1: silver, 2: gold, 3: jackpot

  const tiersMap = {
    0: 'bronze',
    1: 'silver',
    2: 'gold',
    3: 'jackpot',
  } as const;

  for (let i = 1; i <= bottlesDeposited; i++) {
    const rng = Math.random() * 100;
    let tier: 'bronze' | 'silver' | 'gold' | 'jackpot';
    let coins: number;
    let message = '';

    if (rng > 97) {
      // 3% Jackpot
      tier = 'jackpot';
      coins = Math.floor(Math.random() * 15) + 16; // 16 - 30 coins
      message = '🎉 MEGA JACKPOT! Super Lucky Bottle!';
      hasJackpot = true;
      highestTierRank = Math.max(highestTierRank, 3);
    } else if (rng > 87) {
      // 10% Gold
      tier = 'gold';
      coins = Math.floor(Math.random() * 5) + 11; // 11 - 15 coins
      message = '🌟 GOLDEN REWARD! High Value Insert!';
      highestTierRank = Math.max(highestTierRank, 2);
    } else if (rng > 65) {
      // 22% Silver
      tier = 'silver';
      coins = Math.floor(Math.random() * 5) + 6; // 6 - 10 coins
      message = '⚡ SILVER BOOST! Lucky Roll!';
      highestTierRank = Math.max(highestTierRank, 1);
    } else {
      // 65% Bronze
      tier = 'bronze';
      coins = Math.floor(Math.random() * 4) + 2; // 2 - 5 coins
      message = '🌱 Green Recycler Base Reward';
    }

    baseCoinsSum += coins;
    bottleBreakdown.push({
      bottleNumber: i,
      tier,
      coins,
      message,
      isJackpot: tier === 'jackpot',
    });
  }

  // Streak Multiplier Calculation
  let streakBonus = 0;
  if (bottlesDeposited >= 10) {
    streakBonus = Math.round(baseCoinsSum * 0.25);
  } else if (bottlesDeposited >= 5) {
    streakBonus = Math.round(baseCoinsSum * 0.15);
  } else if (bottlesDeposited >= 3) {
    streakBonus = Math.round(baseCoinsSum * 0.10);
  }

  const totalCoinsEarned = baseCoinsSum + streakBonus;

  return {
    totalBottles: bottlesDeposited,
    bottleBreakdown,
    baseCoins: baseCoinsSum,
    streakBonus,
    totalCoinsEarned,
    highestTier: tiersMap[highestTierRank as 0 | 1 | 2 | 3],
    hasJackpot,
  };
}

/**
 * Navi Mystery Scratch Cashback Algorithm:
 * Gives a random cashback bonus multiplier when redeeming coins for vouchers or mystery cards.
 */
export function calculateNaviScratchCashback(redeemedAmount: number): NaviScratchCashbackResult {
  const rng = Math.random() * 100;

  if (rng > 95) {
    // 5% Jackpot: 150% - 200% cashback
    const mult = Number((Math.random() * 0.5 + 1.5).toFixed(2));
    return {
      tier: 'jackpot',
      cashbackCoins: Math.round(redeemedAmount * mult),
      multiplier: mult,
      message: `🎉 JACKPOT SCRATCH! ${Math.round(mult * 100)}% Mega Cashback Bonus!`,
    };
  } else if (rng > 80) {
    // 15% Gold: 80% - 120% cashback
    const mult = Number((Math.random() * 0.4 + 0.8).toFixed(2));
    return {
      tier: 'gold',
      cashbackCoins: Math.round(redeemedAmount * mult),
      multiplier: mult,
      message: `🌟 GOLDEN SCRATCH! ${Math.round(mult * 100)}% Cashback Bonus!`,
    };
  } else if (rng > 50) {
    // 30% Silver: 40% - 70% cashback
    const mult = Number((Math.random() * 0.3 + 0.4).toFixed(2));
    return {
      tier: 'silver',
      cashbackCoins: Math.round(redeemedAmount * mult),
      multiplier: mult,
      message: `⚡ SILVER SCRATCH! ${Math.round(mult * 100)}% Cashback Return!`,
    };
  } else {
    // 50% Bronze: 15% - 35% cashback
    const mult = Number((Math.random() * 0.2 + 0.15).toFixed(2));
    return {
      tier: 'bronze',
      cashbackCoins: Math.round(redeemedAmount * mult),
      multiplier: mult,
      message: `🌱 BRONZE SCRATCH! ${Math.round(mult * 100)}% Coins Returned!`,
    };
  }
}
