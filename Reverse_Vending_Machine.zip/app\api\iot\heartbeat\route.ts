import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Machine } from '@/models/Machine';
import { handleApiError } from '@/lib/apiError';

export async function POST(req: NextRequest) {
  try {
    const apiKey = req.headers.get('x-iot-api-key');
    const validApiKey = process.env.IOT_API_KEY || 'rvm_iot_secret_api_key_2026_device_auth';

    if (!apiKey || apiKey !== validApiKey) {
      return NextResponse.json(
        { error: { message: 'Invalid or missing IoT API Key header', code: 'UNAUTHORIZED_DEVICE' } },
        { status: 401 }
      );
    }

    await connectToDatabase();
    const body = await req.json();
    const { machineId } = body;

    if (!machineId) {
      return NextResponse.json(
        { error: { message: 'machineId is required', code: 'MISSING_FIELD' } },
        { status: 400 }
      );
    }

    const machine = await Machine.findOneAndUpdate(
      { machineId: machineId.toUpperCase() },
      {
        connectivity: 'connected',
        lastSyncAt: new Date(),
      },
      { new: true }
    );

    if (!machine) {
      return NextResponse.json(
        { error: { message: `Machine ${machineId} not found`, code: 'NOT_FOUND' } },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, machineId: machine.machineId, lastSyncAt: machine.lastSyncAt });
  } catch (error) {
    return handleApiError(error);
  }
}
