import { NextResponse } from 'next/server';
import { getSessionFromCookies } from '@/lib/auth';
import { connectToDatabase } from '@/lib/db';
import { User } from '@/models/User';
import { Admin } from '@/models/Admin';
import { Employee } from '@/models/Employee';

export async function GET() {
  const session = getSessionFromCookies();
  if (!session) {
    return NextResponse.json({ user: null }, { status: 401 });
  }

  await connectToDatabase();
  let userDetails: any = null;

  if (session.role === 'admin') {
    userDetails = await Admin.findById(session.id).select('-passwordHash');
  } else if (session.role === 'employee') {
    userDetails = await Employee.findById(session.id)
      .select('-passwordHash')
      .populate('assignedMachines');
  } else if (session.role === 'user') {
    userDetails = await User.findById(session.id).select('-passwordHash');
  }

  return NextResponse.json({
    user: session,
    profile: userDetails,
  });
}
