'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { Search, Users, ShieldAlert, ArrowRight } from 'lucide-react';
import { Card } from '@/components/ui/Card';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminUsersPage() {
  const [search, setSearch] = useState('');
  const { data, isLoading } = useSWR(`/api/users?search=${encodeURIComponent(search)}`, fetcher);
  const users = data?.users || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-slate-900">Registered Recyclers</h1>
        <p className="text-xs text-slate-500 mt-1">Manage citizen accounts, view recycling statistics, and check Green Coin balances</p>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search recyclers by name, email, or mobile..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      <Card>
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading recyclers...</div>
        ) : users.length === 0 ? (
          <div className="text-center py-12 text-slate-400">No users found.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">Name</th>
                  <th className="py-3.5 px-4">Contact</th>
                  <th className="py-3.5 px-4">Bottles Recycled</th>
                  <th className="py-3.5 px-4">Current Coins</th>
                  <th className="py-3.5 px-4">Account Status</th>
                  <th className="py-3.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {users.map((u: any) => (
                  <tr key={u._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-800">{u.name}</td>
                    <td className="py-3.5 px-4 text-slate-600">
                      <div>{u.email}</div>
                      <div className="text-xs text-slate-400">{u.mobile}</div>
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-700">{u.totalBottlesRecycled} bottles</td>
                    <td className="py-3.5 px-4 font-black text-emerald-600">{u.currentBalance} Coins</td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`text-xs font-bold px-2.5 py-1 rounded-full uppercase border ${
                          u.isActive
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border-rose-200'
                        }`}
                      >
                        {u.isActive ? 'Active' : 'Deactivated'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <Link
                        href={`/admin/users/${u._id}`}
                        className="inline-flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-3 py-1 rounded-lg border border-indigo-100"
                      >
                        Details <ArrowRight className="w-3.5 h-3.5 ml-1" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
