import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Transaction } from '@/models/Transaction';
import { requireRole } from '@/lib/rbac';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requireRole(req, ['admin', 'user']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();
    const transactions = await Transaction.find({ user: params.id })
      .populate({
        path: 'machine',
        populate: { path: 'location' },
      })
      .sort({ timestamp: -1 });

    return NextResponse.json({ transactions });
  } catch (error) {
    return handleApiError(error);
  }
}
