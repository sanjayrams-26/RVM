import React from 'react';
import Link from 'next/link';
import { Recycle, Coins, MapPin, ShieldCheck, ArrowRight, Sparkles, Smartphone, BarChart } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header Navigation */}
      <nav className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50 px-6 lg:px-12 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-11 h-11 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-lg shadow-emerald-200">
            <Recycle className="w-7 h-7 animate-spin-slow" />
          </div>
          <div>
            <span className="font-extrabold text-xl text-slate-800 tracking-tight">RVM Green Coin</span>
            <span className="block text-xs font-semibold text-emerald-600">Smart IoT Recycling Network</span>
          </div>
        </div>

        <div className="flex items-center space-x-6">
          <Link href="/about" className="text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors hidden sm:block">
            About Us
          </Link>
          <Link href="/contact" className="text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors hidden sm:block">
            Contact & Support
          </Link>
          <Link href="/login" className="text-sm font-semibold text-slate-700 hover:text-emerald-600 transition-colors">
            Sign In
          </Link>
          <Link
            href="/register"
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md shadow-emerald-200 transition-all hover:scale-105"
          >
            Start Recycling
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="px-6 lg:px-12 py-16 lg:py-24 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-emerald-100/80 border border-emerald-200 text-emerald-800 text-xs font-bold mb-6">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>AI-Driven Reverse Vending Machines</span>
          </div>
          <h1 className="text-4xl lg:text-6xl font-black text-slate-900 tracking-tight leading-tight mb-6">
            Recycle Plastic Bottles. <br />
            <span className="text-emerald-600 underline decoration-emerald-300 underline-offset-8">Earn Green Coins.</span>
          </h1>
          <p className="text-lg text-slate-600 mb-8 leading-relaxed">
            Deposit plastic waste at smart IoT Reverse Vending Machines across Coimbatore, Chennai, and Madurai. Earn 5 Green Coins per bottle and redeem them for digital rewards or instant withdrawals.
          </p>

          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
            <Link
              href="/register"
              className="inline-flex items-center justify-center px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-base shadow-lg shadow-emerald-200 transition-all hover:scale-102"
            >
              Get Started Free <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
            <Link
              href="/login"
              className="inline-flex items-center justify-center px-8 py-4 rounded-2xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-base shadow-xs transition-colors"
            >
              Portal Login
            </Link>
          </div>

          <div className="mt-10 grid grid-cols-3 gap-6 pt-8 border-t border-slate-200">
            <div>
              <p className="text-2xl font-black text-slate-900">100%</p>
              <p className="text-xs font-semibold text-slate-500 mt-0.5">Automated Telemetry</p>
            </div>
            <div>
              <p className="text-2xl font-black text-emerald-600">5 Coins</p>
              <p className="text-xs font-semibold text-slate-500 mt-0.5">Per Bottle Recycled</p>
            </div>
            <div>
              <p className="text-2xl font-black text-slate-900">Real-Time</p>
              <p className="text-xs font-semibold text-slate-500 mt-0.5">Capacity Alerts</p>
            </div>
          </div>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-600 mb-4">
              <Recycle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">User Eco Rewards</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Track your plastic reduction impact, view live Green Coin balance, and cash out instantly.
            </p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-2xl bg-indigo-100 flex items-center justify-center text-indigo-600 mb-4">
              <BarChart className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">Admin Command Center</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Manage machine fleets, storage levels, district analytics, and generate CSV reports.
            </p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-600 mb-4">
              <Smartphone className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">Field Staff App</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Mobile-first maintenance portal for field technicians to clear full capacity & service RVMs.
            </p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-2xl bg-sky-100 flex items-center justify-center text-sky-600 mb-4">
              <MapPin className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">Machine Locator</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Interactive map locator filtering RVM machines by state, district, and area with live distance.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-8 px-6 text-center text-slate-500 text-xs">
        <p>© 2026 RVM Green Coin Platform. Built for Sustainable Smart Cities.</p>
      </footer>
    </div>
  );
}
