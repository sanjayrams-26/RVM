import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { GreenCoinLedger } from '@/models/GreenCoinLedger';
import { getSessionFromCookies } from '@/lib/auth';
import { MOCK_TRANSACTIONS } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  const session = getSessionFromCookies();
  const userId = session?.id || 'usr_1';

  try {
    await connectToDatabase();
    const ledger = await GreenCoinLedger.find({ user: userId })
      .populate('relatedMachine', 'machineId name')
      .sort({ createdAt: -1 });

    if (ledger.length > 0) {
      return NextResponse.json({ ledger });
    }
  } catch (e) {
    console.warn('Serving mock ledger history fallback');
  }

  const mockLedger = MOCK_TRANSACTIONS.map((tx) => ({
    _id: `led_${tx._id}`,
    user: tx.user._id,
    type: 'earn',
    amount: tx.coinsEarned,
    balanceAfter: 210,
    note: `Deposited ${tx.bottlesDeposited} bottle(s) at ${tx.machine.machineId}`,
    createdAt: tx.timestamp,
  }));

  return NextResponse.json({ ledger: mockLedger });
}
