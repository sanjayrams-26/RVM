import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Alert } from '@/models/Alert';
import { MOCK_ALERTS } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();
    const dbAlerts = await Alert.find()
      .populate('assignedEmployee', 'name email employeeId mobile')
      .populate({ path: 'machine', populate: { path: 'location' } })
      .sort({ createdAt: -1 });

    if (dbAlerts.length > 0) {
      return NextResponse.json({ alerts: dbAlerts });
    }
  } catch (e) {
    console.warn('Serving mock alerts fallback');
  }

  const { searchParams } = new URL(req.url);
  const isResolved = searchParams.get('resolved');
  const severity = searchParams.get('severity');

  let filtered = [...MOCK_ALERTS];
  if (isResolved !== null && isResolved !== '') {
    filtered = filtered.filter((a) => String(a.isResolved) === isResolved);
  }
  if (severity) {
    filtered = filtered.filter((a) => a.severity === severity);
  }

  return NextResponse.json({ alerts: filtered });
}

export async function POST(req: NextRequest) {
  try {
    await connectToDatabase();
    const body = await req.json();
    const alert = await Alert.create(body);
    return NextResponse.json({ success: true, alert }, { status: 201 });
  } catch (e) {
    const body = await req.json();
    const mockAlert = { _id: `alt_${Date.now()}`, ...body, isResolved: false, createdAt: new Date().toISOString() };
    MOCK_ALERTS.unshift(mockAlert);
    return NextResponse.json({ success: true, alert: mockAlert }, { status: 201 });
  }
}
