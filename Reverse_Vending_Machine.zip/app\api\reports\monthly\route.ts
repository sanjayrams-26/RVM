import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Transaction } from '@/models/Transaction';
import { requireRole } from '@/lib/rbac';
import { handleApiError } from '@/lib/apiError';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireRole(req, ['admin']);
    if (authResult instanceof NextResponse) return authResult;

    await connectToDatabase();

    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    const report = await Transaction.aggregate([
      {
        $match: {
          timestamp: { $gte: thirtyDaysAgo },
        },
      },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$timestamp' } },
          date: { $first: { $dateToString: { format: '%Y-%m-%d', date: '$timestamp' } } },
          totalTransactions: { $sum: 1 },
          totalBottles: { $sum: '$bottlesDeposited' },
          totalCoins: { $sum: '$coinsEarned' },
        },
      },
      { $sort: { date: 1 } },
    ]);

    return NextResponse.json({ report });
  } catch (error) {
    return handleApiError(error);
  }
}
