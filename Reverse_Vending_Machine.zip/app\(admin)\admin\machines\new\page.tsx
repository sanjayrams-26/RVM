'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Cpu } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function NewMachinePage() {
  const router = useRouter();
  const { data: locationsData } = useSWR('/api/locations', fetcher);
  const { data: employeesData } = useSWR('/api/employees', fetcher);

  const locations = locationsData?.locations || [];
  const employees = employeesData?.employees || [];

  const [machineId, setMachineId] = useState('');
  const [name, setName] = useState('');
  const [locationId, setLocationId] = useState('');
  const [lat, setLat] = useState(11.0168);
  const [lng, setLng] = useState(76.9558);
  const [storageCapacity, setStorageCapacity] = useState(500);
  const [assignedEmployee, setAssignedEmployee] = useState('');

  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/machines', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          machineId,
          name,
          location: locationId,
          gps: { lat: Number(lat), lng: Number(lng) },
          storageCapacity: Number(storageCapacity),
          assignedEmployee: assignedEmployee || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error?.message || 'Failed to create machine.');
        setIsLoading(false);
        return;
      }

      router.push('/admin/machines');
      router.refresh();
    } catch {
      setErrorMsg('An unexpected error occurred.');
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <Link href="/admin/machines" className="inline-flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-700">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to Machine List
      </Link>

      <div>
        <h1 className="text-2xl font-black text-slate-900">Add New RVM Machine</h1>
        <p className="text-xs text-slate-500 mt-1">Register physical Reverse Vending Machine hardware in the network</p>
      </div>

      <Card>
        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Machine ID</label>
              <input
                type="text"
                required
                placeholder="RVM-CBE-001"
                value={machineId}
                onChange={(e) => setMachineId(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 uppercase"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Machine Name</label>
              <input
                type="text"
                required
                placeholder="Coimbatore Gandhipuram Hub 1"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Location Node</label>
            <select
              required
              value={locationId}
              onChange={(e) => setLocationId(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">-- Choose Location --</option>
              {locations.map((loc: any) => (
                <option key={loc._id} value={loc._id}>
                  {loc.district} - {loc.area} ({loc.exactLocation})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Storage Capacity</label>
              <input
                type="number"
                required
                value={storageCapacity}
                onChange={(e) => setStorageCapacity(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">GPS Latitude</label>
              <input
                type="number"
                step="any"
                required
                value={lat}
                onChange={(e) => setLat(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">GPS Longitude</label>
              <input
                type="number"
                step="any"
                required
                value={lng}
                onChange={(e) => setLng(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Assign Field Staff (Optional)</label>
            <select
              value={assignedEmployee}
              onChange={(e) => setAssignedEmployee(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">-- Unassigned --</option>
              {employees.map((emp: any) => (
                <option key={emp._id} value={emp._id}>
                  {emp.name} ({emp.employeeId})
                </option>
              ))}
            </select>
          </div>

          <div className="pt-4">
            <Button type="submit" isLoading={isLoading} className="w-full py-3">
              Create Machine
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
