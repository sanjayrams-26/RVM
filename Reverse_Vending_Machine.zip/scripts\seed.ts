import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import path from 'path';

// Load .env.local
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  console.error('Missing MONGODB_URI in .env.local');
  process.exit(1);
}

// Schemas & Models
const AdminSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true, lowercase: true },
  passwordHash: { type: String, select: false },
  role: { type: String, default: 'admin' },
}, { timestamps: true });

const LocationSchema = new mongoose.Schema({
  state: String,
  district: String,
  area: String,
  exactLocation: String,
  gps: { lat: Number, lng: Number },
  type: String,
}, { timestamps: true });

const EmployeeSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true, lowercase: true },
  mobile: String,
  passwordHash: { type: String, select: false },
  employeeId: { type: String, unique: true },
  assignedMachines: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Machine' }],
  role: { type: String, default: 'employee' },
  isActive: { type: Boolean, default: true },
  joinDate: { type: Date, default: Date.now },
}, { timestamps: true });

const MachineSchema = new mongoose.Schema({
  machineId: { type: String, unique: true },
  name: String,
  location: { type: mongoose.Schema.Types.ObjectId, ref: 'Location' },
  gps: { lat: Number, lng: Number },
  status: { type: String, default: 'active' },
  storageCapacity: { type: Number, default: 500 },
  currentStorageLevel: { type: Number, default: 0 },
  bottlesCollectedTotal: { type: Number, default: 0 },
  uniqueUsersCount: { type: Number, default: 0 },
  totalGreenCoinsGenerated: { type: Number, default: 0 },
  assignedEmployee: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
  installationDate: { type: Date, default: Date.now },
  connectivity: { type: String, default: 'connected' },
  sensorStatus: { type: String, default: 'ok' },
  powerStatus: { type: String, default: 'on' },
  lastSyncAt: { type: Date, default: Date.now },
}, { timestamps: true });

const UserSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true, lowercase: true },
  mobile: { type: String, unique: true },
  passwordHash: { type: String, select: false },
  registrationDate: { type: Date, default: Date.now },
  totalBottlesRecycled: { type: Number, default: 0 },
  totalGreenCoinsEarned: { type: Number, default: 0 },
  greenCoinsRedeemed: { type: Number, default: 0 },
  greenCoinsWithdrawn: { type: Number, default: 0 },
  currentBalance: { type: Number, default: 0 },
  isActive: { type: Boolean, default: true },
  role: { type: String, default: 'user' },
}, { timestamps: true });

const TransactionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  machine: { type: mongoose.Schema.Types.ObjectId, ref: 'Machine' },
  bottlesDeposited: Number,
  coinsEarned: Number,
  timestamp: { type: Date, default: Date.now },
  status: { type: String, default: 'success' },
}, { timestamps: true });

const GreenCoinLedgerSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  type: String,
  amount: Number,
  balanceAfter: Number,
  relatedTransaction: { type: mongoose.Schema.Types.ObjectId, ref: 'Transaction' },
  relatedMachine: { type: mongoose.Schema.Types.ObjectId, ref: 'Machine' },
  note: String,
}, { timestamps: true });

const AlertSchema = new mongoose.Schema({
  machine: { type: mongoose.Schema.Types.ObjectId, ref: 'Machine' },
  type: String,
  message: String,
  severity: { type: String, default: 'warning' },
  isResolved: { type: Boolean, default: false },
  assignedEmployee: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
}, { timestamps: true });

const CounterSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  seq: { type: Number, default: 0 },
});

const Admin = mongoose.models.Admin || mongoose.model('Admin', AdminSchema);
const Location = mongoose.models.Location || mongoose.model('Location', LocationSchema);
const Employee = mongoose.models.Employee || mongoose.model('Employee', EmployeeSchema);
const Machine = mongoose.models.Machine || mongoose.model('Machine', MachineSchema);
const User = mongoose.models.User || mongoose.model('User', UserSchema);
const Transaction = mongoose.models.Transaction || mongoose.model('Transaction', TransactionSchema);
const GreenCoinLedger = mongoose.models.GreenCoinLedger || mongoose.model('GreenCoinLedger', GreenCoinLedgerSchema);
const Alert = mongoose.models.Alert || mongoose.model('Alert', AlertSchema);
const Counter = mongoose.models.Counter || mongoose.model('Counter', CounterSchema);

async function seed() {
  console.log('Connecting to MongoDB Atlas...');
  await mongoose.connect(MONGODB_URI as string);
  console.log('Connected!');

  console.log('Clearing existing collections...');
  await Promise.all([
    Admin.deleteMany({}),
    Location.deleteMany({}),
    Employee.deleteMany({}),
    Machine.deleteMany({}),
    User.deleteMany({}),
    Transaction.deleteMany({}),
    GreenCoinLedger.deleteMany({}),
    Alert.deleteMany({}),
    Counter.deleteMany({}),
  ]);

  console.log('Seeding Super Admin...');
  const adminPasswordHash = await bcrypt.hash('Admin@1234', 10);
  const superAdmin = await Admin.create({
    name: 'RVM Platform Super Admin',
    email: 'admin@rvmgreencoin.org',
    passwordHash: adminPasswordHash,
    role: 'admin',
  });

  console.log('Seeding Locations...');
  const locationsData = [
    // Coimbatore
    { state: 'Tamil Nadu', district: 'Coimbatore', area: 'Gandhipuram', exactLocation: 'Central Bus Stand Entrance', gps: { lat: 11.0168, lng: 76.9558 }, type: 'station' },
    { state: 'Tamil Nadu', district: 'Coimbatore', area: 'RS Puram', exactLocation: 'DB Road Shopping Complex', gps: { lat: 11.0062, lng: 76.9507 }, type: 'mall' },
    { state: 'Tamil Nadu', district: 'Coimbatore', area: 'Tidel Park', exactLocation: 'ELCOT IT SEZ Main Gate', gps: { lat: 11.0287, lng: 77.0275 }, type: 'public_place' },
    { state: 'Tamil Nadu', district: 'Coimbatore', area: 'Peelamedu', exactLocation: 'PSG Tech Campus Plaza', gps: { lat: 11.0247, lng: 77.0028 }, type: 'street' },

    // Chennai
    { state: 'Tamil Nadu', district: 'Chennai', area: 'T Nagar', exactLocation: 'Ranganathan Street Junction', gps: { lat: 13.0418, lng: 80.2341 }, type: 'street' },
    { state: 'Tamil Nadu', district: 'Chennai', area: 'Velachery', exactLocation: 'Phoenix Marketcity Mall', gps: { lat: 12.9915, lng: 80.217 }, type: 'mall' },
    { state: 'Tamil Nadu', district: 'Chennai', area: 'Central Metro', exactLocation: 'Subway Exit Gate 3', gps: { lat: 13.0827, lng: 80.2707 }, type: 'station' },
    { state: 'Tamil Nadu', district: 'Chennai', area: 'Marina Beach', exactLocation: 'Light House Promenade', gps: { lat: 13.0396, lng: 80.2778 }, type: 'public_place' },

    // Madurai
    { state: 'Tamil Nadu', district: 'Madurai', area: 'Meenakshi Temple', exactLocation: 'East Gopuram Entrance Plaza', gps: { lat: 9.9195, lng: 78.1193 }, type: 'public_place' },
    { state: 'Tamil Nadu', district: 'Madurai', area: 'KK Nagar', exactLocation: 'District Court Walkway', gps: { lat: 9.9329, lng: 78.1408 }, type: 'street' },
    { state: 'Tamil Nadu', district: 'Madurai', area: 'Periyar Bus Stand', exactLocation: 'Bay 4 Departure', gps: { lat: 9.9167, lng: 78.1126 }, type: 'station' },
  ];

  const extraDistrictSeeds = [
    {
      district: 'Tiruchirappalli',
      code: 'TRY',
      sites: [
        { area: 'Cantonment', exactLocation: 'Chatram Bus Stand Entry Plaza', gps: { lat: 10.7905, lng: 78.7047 }, type: 'station', machineName: 'Cantonment Transit RVM' },
        { area: 'Thillai Nagar', exactLocation: 'Centrally Located Shopping Arcade', gps: { lat: 10.8048, lng: 78.6875 }, type: 'mall', machineName: 'Thillai Nagar Retail RVM' },
        { area: 'Srirangam', exactLocation: 'Temple East Gopuram Walkway', gps: { lat: 10.8528, lng: 78.6912 }, type: 'public_place', machineName: 'Srirangam Heritage RVM' },
      ],
    },
    {
      district: 'Salem',
      code: 'SLM',
      sites: [
        { area: 'Five Road', exactLocation: 'Five Road Junction Plaza', gps: { lat: 11.6643, lng: 78.146 }, type: 'street', machineName: 'Five Road Junction RVM' },
        { area: 'Hasthampatti', exactLocation: 'Collectorate Campus Gate', gps: { lat: 11.6751, lng: 78.1571 }, type: 'public_place', machineName: 'Hasthampatti Civic RVM' },
        { area: 'Fairlands', exactLocation: 'Fairlands Shopping Street', gps: { lat: 11.663, lng: 78.1513 }, type: 'mall', machineName: 'Fairlands Market RVM' },
      ],
    },
    {
      district: 'Tirunelveli',
      code: 'TVL',
      sites: [
        { area: 'Palayamkottai', exactLocation: 'Medical College Road Plaza', gps: { lat: 8.7139, lng: 77.7567 }, type: 'street', machineName: 'Palayamkottai Campus RVM' },
        { area: 'Tirunelveli Junction', exactLocation: 'Railway Station Main Forecourt', gps: { lat: 8.7252, lng: 77.6848 }, type: 'station', machineName: 'Junction Forecourt RVM' },
        { area: 'Vannarpettai', exactLocation: 'Vannarpettai Market Entrance', gps: { lat: 8.7088, lng: 77.7178 }, type: 'public_place', machineName: 'Vannarpettai Market RVM' },
      ],
    },
    {
      district: 'Erode',
      code: 'ERD',
      sites: [
        { area: 'PS Park', exactLocation: 'PS Park Bus Stop Plaza', gps: { lat: 11.341, lng: 77.717 }, type: 'station', machineName: 'PS Park Transit RVM' },
        { area: 'Perundurai Road', exactLocation: 'Perundurai Road Retail Cluster', gps: { lat: 11.3308, lng: 77.7087 }, type: 'mall', machineName: 'Perundurai Road RVM' },
        { area: 'Sathy Road', exactLocation: 'Sathy Road Community Center', gps: { lat: 11.3586, lng: 77.6762 }, type: 'public_place', machineName: 'Sathy Road Community RVM' },
      ],
    },
    {
      district: 'Thanjavur',
      code: 'TNJ',
      sites: [
        { area: 'New Bus Stand', exactLocation: 'New Bus Stand Entry Plaza', gps: { lat: 10.7866, lng: 79.1378 }, type: 'station', machineName: 'New Bus Stand RVM' },
        { area: 'Mariamman Kovil', exactLocation: 'Temple Corridor Rest Point', gps: { lat: 10.7819, lng: 79.1398 }, type: 'public_place', machineName: 'Temple Corridor RVM' },
        { area: 'Raja Serfoji Road', exactLocation: 'Raja Serfoji Road Market Spine', gps: { lat: 10.7879, lng: 79.1327 }, type: 'street', machineName: 'Raja Serfoji Road RVM' },
      ],
    },
    {
      district: 'Vellore',
      code: 'VLR',
      sites: [
        { area: 'Katpadi', exactLocation: 'Katpadi Railway Forecourt', gps: { lat: 12.971, lng: 79.136 }, type: 'station', machineName: 'Katpadi Junction RVM' },
        { area: 'Sathuvachari', exactLocation: 'Sathuvachari Commercial Street', gps: { lat: 12.9195, lng: 79.139 }, type: 'street', machineName: 'Sathuvachari Market RVM' },
        { area: 'VIT Campus', exactLocation: 'VIT University Main Plaza', gps: { lat: 12.9698, lng: 79.1559 }, type: 'public_place', machineName: 'VIT Campus Eco RVM' },
      ],
    },
    {
      district: 'Tiruppur',
      code: 'TPR',
      sites: [
        { area: 'Avinashi Road', exactLocation: 'Avinashi Road Transit Hub', gps: { lat: 11.1085, lng: 77.3411 }, type: 'station', machineName: 'Avinashi Road RVM' },
        { area: 'P N Road', exactLocation: 'P N Road Textile Market Front', gps: { lat: 11.1041, lng: 77.3356 }, type: 'mall', machineName: 'P N Road Textile RVM' },
        { area: 'Dharapuram Road', exactLocation: 'Dharapuram Road Community Plaza', gps: { lat: 11.0789, lng: 77.3432 }, type: 'public_place', machineName: 'Dharapuram Road RVM' },
      ],
    },
  ];

  const extraLocationsData = extraDistrictSeeds.flatMap((district) =>
    district.sites.map((site) => ({
      state: 'Tamil Nadu',
      district: district.district,
      area: site.area,
      exactLocation: site.exactLocation,
      gps: site.gps,
      type: site.type,
    }))
  );

  const createdLocations = await Location.insertMany([...locationsData, ...extraLocationsData]);

  console.log('Seeding Employees...');
  const empPasswordHash = await bcrypt.hash('Tech@1234', 10);
  const employeeSeedData = [
    { name: 'Ramesh Kumar', email: 'ramesh@rvm.org', mobile: '9876543210', employeeId: 'EMP-0001', passwordHash: empPasswordHash },
    { name: 'Suresh Babu', email: 'suresh@rvm.org', mobile: '9876543211', employeeId: 'EMP-0002', passwordHash: empPasswordHash },
    { name: 'Karthik Raja', email: 'karthik@rvm.org', mobile: '9876543212', employeeId: 'EMP-0003', passwordHash: empPasswordHash },
    { name: 'Anitha Selvam', email: 'anitha@rvm.org', mobile: '9876543213', employeeId: 'EMP-0004', passwordHash: empPasswordHash },
    { name: 'Vijay Anand', email: 'vijay@rvm.org', mobile: '9876543214', employeeId: 'EMP-0005', passwordHash: empPasswordHash },
  ];

  const createdEmployees = await Employee.insertMany(employeeSeedData);
  await Counter.create({ id: 'employee_id', seq: 5 });

  console.log('Seeding RVM Machines...');
  const extraMachinesSeedData = extraDistrictSeeds.flatMap((district, districtIndex) =>
    district.sites.map((site, siteIndex) => {
      const locationIndex = locationsData.length + districtIndex * 3 + siteIndex;
      const location = createdLocations[locationIndex];
      const employee = createdEmployees[(districtIndex + siteIndex) % createdEmployees.length];
      const storageCapacity = siteIndex === 0 ? 400 : siteIndex === 1 ? 500 : 600;
      const currentStorageLevel = siteIndex === 0 ? 150 + districtIndex * 6 : siteIndex === 1 ? 420 - districtIndex * 4 : 110 + districtIndex * 5;
      const bottlesCollectedTotal = 1500 + districtIndex * 280 + siteIndex * 190;
      const uniqueUsersCount = 70 + districtIndex * 14 + siteIndex * 9;

      return {
        machineId: `RVM-${district.code}-${String(siteIndex + 1).padStart(3, '0')}`,
        name: site.machineName,
        location: location._id,
        gps: location.gps,
        storageCapacity,
        currentStorageLevel,
        bottlesCollectedTotal,
        totalGreenCoinsGenerated: bottlesCollectedTotal * 5,
        uniqueUsersCount,
        status: siteIndex === 0 ? 'active' : siteIndex === 1 ? 'full' : 'under_maintenance',
        assignedEmployee: employee._id,
      };
    })
  );

  const machinesSeedData = [
    { machineId: 'RVM-CBE-001', name: 'Gandhipuram Smart Hub 1', location: createdLocations[0]._id, gps: createdLocations[0].gps, storageCapacity: 500, currentStorageLevel: 440, bottlesCollectedTotal: 3420, totalGreenCoinsGenerated: 17100, status: 'full', assignedEmployee: createdEmployees[0]._id },
    { machineId: 'RVM-CBE-002', name: 'RS Puram Shopping RVM', location: createdLocations[1]._id, gps: createdLocations[1].gps, storageCapacity: 500, currentStorageLevel: 210, bottlesCollectedTotal: 1890, totalGreenCoinsGenerated: 9450, status: 'active', assignedEmployee: createdEmployees[0]._id },
    { machineId: 'RVM-CBE-003', name: 'Tidel Park Eco Station', location: createdLocations[2]._id, gps: createdLocations[2].gps, storageCapacity: 600, currentStorageLevel: 150, bottlesCollectedTotal: 2540, totalGreenCoinsGenerated: 12700, status: 'active', assignedEmployee: createdEmployees[1]._id },
    { machineId: 'RVM-CBE-004', name: 'Peelamedu PSG Tech RVM', location: createdLocations[3]._id, gps: createdLocations[3].gps, storageCapacity: 400, currentStorageLevel: 380, bottlesCollectedTotal: 1200, totalGreenCoinsGenerated: 6000, status: 'active', assignedEmployee: createdEmployees[1]._id },

    { machineId: 'RVM-CHN-001', name: 'T Nagar Junction Recycler', location: createdLocations[4]._id, gps: createdLocations[4].gps, storageCapacity: 500, currentStorageLevel: 480, bottlesCollectedTotal: 5120, totalGreenCoinsGenerated: 25600, status: 'full', assignedEmployee: createdEmployees[2]._id },
    { machineId: 'RVM-CHN-002', name: 'Velachery Mall RVM', location: createdLocations[5]._id, gps: createdLocations[5].gps, storageCapacity: 500, currentStorageLevel: 90, bottlesCollectedTotal: 2900, totalGreenCoinsGenerated: 14500, status: 'active', assignedEmployee: createdEmployees[2]._id },
    { machineId: 'RVM-CHN-003', name: 'Chennai Central Metro Hub', location: createdLocations[6]._id, gps: createdLocations[6].gps, storageCapacity: 800, currentStorageLevel: 320, bottlesCollectedTotal: 6400, totalGreenCoinsGenerated: 32000, status: 'active', assignedEmployee: createdEmployees[3]._id },
    { machineId: 'RVM-CHN-004', name: 'Marina Beach Eco Kiosk', location: createdLocations[7]._id, gps: createdLocations[7].gps, storageCapacity: 500, currentStorageLevel: 0, bottlesCollectedTotal: 1400, totalGreenCoinsGenerated: 7000, status: 'offline', assignedEmployee: createdEmployees[3]._id },

    { machineId: 'RVM-MDU-001', name: 'Meenakshi Temple East Plaza', location: createdLocations[8]._id, gps: createdLocations[8].gps, storageCapacity: 500, currentStorageLevel: 260, bottlesCollectedTotal: 2100, totalGreenCoinsGenerated: 10500, status: 'active', assignedEmployee: createdEmployees[4]._id },
    { machineId: 'RVM-MDU-002', name: 'KK Nagar Court RVM', location: createdLocations[9]._id, gps: createdLocations[9].gps, storageCapacity: 500, currentStorageLevel: 110, bottlesCollectedTotal: 980, totalGreenCoinsGenerated: 4900, status: 'active', assignedEmployee: createdEmployees[4]._id },
    { machineId: 'RVM-MDU-003', name: 'Periyar Bus Stand Unit', location: createdLocations[10]._id, gps: createdLocations[10].gps, storageCapacity: 500, currentStorageLevel: 420, bottlesCollectedTotal: 3100, totalGreenCoinsGenerated: 15500, status: 'active', assignedEmployee: createdEmployees[4]._id },
    ...extraMachinesSeedData,
  ];

  const createdMachines = await Machine.insertMany(machinesSeedData);

  // Sync assigned machines back to employees
  for (const emp of createdEmployees) {
    const assigned = createdMachines.filter((m) => String(m.assignedEmployee) === String(emp._id)).map((m) => m._id);
    await Employee.findByIdAndUpdate(emp._id, { assignedMachines: assigned });
  }

  console.log('Seeding Sample Users & Transactions...');
  const userPasswordHash = await bcrypt.hash('User@1234', 10);
  const sampleUsers = [];

  for (let i = 1; i <= 15; i++) {
    sampleUsers.push({
      name: `Recycler User ${i}`,
      email: `user${i}@example.com`,
      mobile: `91234567${i < 10 ? '0' + i : i}`,
      passwordHash: userPasswordHash,
      role: 'user',
      totalBottlesRecycled: 10 * i,
      totalGreenCoinsEarned: 50 * i,
      currentBalance: 50 * i,
    });
  }

  const createdUsers = await User.insertMany(sampleUsers);

  // Generate 50+ realistic transactions spanning past 30 days
  console.log('Generating 50+ historical deposit transactions...');
  const txDocs = [];
  const ledgerDocs = [];

  for (let i = 0; i < 55; i++) {
    const randomUser = createdUsers[i % createdUsers.length];
    const randomMachine = createdMachines[i % createdMachines.length];
    const bottles = Math.floor(Math.random() * 8) + 1; // 1 to 8 bottles
    const coins = bottles * 5;
    const daysAgo = Math.floor(Math.random() * 28);
    const timestamp = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000 - Math.random() * 3600000);

    const txId = new mongoose.Types.ObjectId();

    txDocs.push({
      _id: txId,
      user: randomUser._id,
      machine: randomMachine._id,
      bottlesDeposited: bottles,
      coinsEarned: coins,
      timestamp,
      status: 'success',
    });

    ledgerDocs.push({
      user: randomUser._id,
      type: 'earn',
      amount: coins,
      balanceAfter: 50 + coins,
      relatedTransaction: txId,
      relatedMachine: randomMachine._id,
      note: `Deposited ${bottles} bottle(s) at ${randomMachine.machineId}`,
      createdAt: timestamp,
    });
  }

  await Transaction.insertMany(txDocs);
  await GreenCoinLedger.insertMany(ledgerDocs);

  console.log('Seeding Sample Alerts...');
  await Alert.insertMany([
    {
      machine: createdMachines[0]._id, // RVM-CBE-001
      type: 'storage',
      message: 'Machine RVM-CBE-001 capacity reached 88% (440/500 bottles). Collection required soon.',
      severity: 'warning',
      isResolved: false,
      assignedEmployee: createdEmployees[0]._id,
    },
    {
      machine: createdMachines[4]._id, // RVM-CHN-001
      type: 'storage',
      message: 'Machine RVM-CHN-001 capacity reached 96% (480/500 bottles). Machine status flipped to full.',
      severity: 'critical',
      isResolved: false,
      assignedEmployee: createdEmployees[2]._id,
    },
    {
      machine: createdMachines[7]._id, // RVM-CHN-004
      type: 'offline',
      message: 'Machine RVM-CHN-004 lost connectivity. Last sync > 30 mins ago.',
      severity: 'critical',
      isResolved: false,
      assignedEmployee: createdEmployees[3]._id,
    },
  ]);

  console.log('----------------------------------------------------');
  console.log('🎉 SEEDING COMPLETE SUCCESS!');
  console.log('----------------------------------------------------');
  console.log('Default Credentials:');
  console.log('👑 Admin:    admin@rvmgreencoin.org  /  Admin@1234');
  console.log('🔧 Employee: ramesh@rvm.org          /  Tech@1234');
  console.log('♻️  User:     user1@example.com       /  User@1234');
  console.log('----------------------------------------------------');

  process.exit(0);
}

seed().catch((err) => {
  console.error('Seed error:', err);
  process.exit(1);
});
