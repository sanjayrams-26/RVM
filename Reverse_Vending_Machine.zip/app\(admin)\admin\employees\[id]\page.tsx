'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { ArrowLeft, User, Mail, Phone, Wrench, Shield, Check } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminEmployeeDetailPage({ params }: { params: { id: string } }) {
  const { data: empData, mutate } = useSWR(`/api/employees/${params.id}`, fetcher);
  const { data: tasksData } = useSWR(`/api/employees/${params.id}/tasks`, fetcher);

  const employee = empData?.employee;
  const tasks = tasksData?.tasks || [];
  const alerts = tasksData?.alerts || [];

  const [isLoading, setIsLoading] = useState(false);

  const toggleStatus = async () => {
    if (!employee) return;
    setIsLoading(true);
    try {
      await fetch(`/api/employees/${employee._id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !employee.isActive }),
      });
      mutate();
    } finally {
      setIsLoading(false);
    }
  };

  if (!employee) {
    return <div className="p-8 text-center text-slate-500">Loading employee details...</div>;
  }

  return (
    <div className="space-y-6">
      <Link href="/admin/employees" className="inline-flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-700">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to Staff List
      </Link>

      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div>
          <div className="flex items-center space-x-3">
            <h1 className="text-2xl font-black text-slate-900">{employee.name}</h1>
            <span className="text-xs font-extrabold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
              {employee.employeeId}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">{employee.email} • {employee.mobile}</p>
          <p className="text-xs text-slate-400 mt-1">Joined: {new Date(employee.joinDate).toLocaleDateString()}</p>
        </div>

        <Button
          onClick={toggleStatus}
          isLoading={isLoading}
          variant={employee.isActive ? 'danger' : 'primary'}
        >
          {employee.isActive ? 'Deactivate Technician' : 'Activate Technician'}
        </Button>
      </div>

      {/* Assigned Machines List */}
      <Card title="Assigned Machines Fleet">
        {employee.assignedMachines?.length === 0 ? (
          <p className="text-xs text-slate-400 italic py-4">No machines currently assigned to this staff member.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {employee.assignedMachines?.map((m: any) => (
              <div key={m._id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex justify-between items-center text-xs">
                <div>
                  <p className="font-bold text-slate-800">{m.machineId} - {m.name}</p>
                  <p className="text-slate-500">{m.location?.district}, {m.location?.area}</p>
                </div>
                <Link href={`/admin/machines/${m._id}`} className="font-bold text-indigo-600 hover:underline">
                  View
                </Link>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Service History */}
      <Card title="Service Task History">
        {tasks.length === 0 ? (
          <p className="text-xs text-slate-400 py-4">No service tasks completed yet.</p>
        ) : (
          <div className="space-y-3">
            {tasks.map((t: any) => (
              <div key={t._id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs flex justify-between">
                <div>
                  <p className="font-bold text-slate-800">{t.serviceType?.toUpperCase()} on {t.machine?.machineId}</p>
                  <p className="text-slate-500">{t.remarks || 'No remarks'}</p>
                </div>
                <span className="font-bold uppercase text-emerald-600">{t.status}</span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
