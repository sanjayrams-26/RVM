import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Employee } from '@/models/Employee';
import { MOCK_EMPLOYEES } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();
    const dbEmps = await Employee.find()
      .populate('assignedMachines')
      .sort({ createdAt: -1 });
    if (dbEmps.length > 0) {
      return NextResponse.json({ employees: dbEmps });
    }
  } catch (e) {
    console.warn('Serving mock employees fallback');
  }

  return NextResponse.json({ employees: MOCK_EMPLOYEES });
}
