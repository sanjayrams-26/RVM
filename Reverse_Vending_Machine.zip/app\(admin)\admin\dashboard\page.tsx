'use client';

import React from 'react';
import useSWR from 'swr';
import { Cpu, CheckCircle2, AlertTriangle, Users, Recycle, Coins, RefreshCw } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { DashboardCharts } from '@/components/charts/DashboardCharts';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminDashboardPage() {
  const { data: stats } = useSWR('/api/dashboard/stats', fetcher);
  const { data: districtReport } = useSWR('/api/reports/district-wise', fetcher);
  const { data: weeklyReport } = useSWR('/api/reports/weekly', fetcher);
  const { data: machinesReport } = useSWR('/api/reports/machine-performance', fetcher);

  const districtData = districtReport?.report || [];
  const weeklyTrendData = weeklyReport?.report || [];
  const topMachinesData = (machinesReport?.report || []).slice(0, 8);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">Admin Command Center</h1>
          <p className="text-xs text-slate-500 mt-1">Real-time IoT telemetry, network status, and waste management analytics</p>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
        <Card className="border-emerald-200/60 bg-emerald-50/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Fleet</p>
              <h3 className="text-3xl font-black text-slate-900 mt-1">{stats?.totalMachines ?? 0}</h3>
              <p className="text-[11px] text-emerald-600 font-bold mt-1">
                {stats?.activeMachines ?? 0} Online & Active
              </p>
            </div>
            <div className="w-11 h-11 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-600">
              <Cpu className="w-5 h-5" />
            </div>
          </div>
        </Card>

        <Card className="border-amber-200/60 bg-amber-50/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Requires Service</p>
              <h3 className="text-3xl font-black text-amber-700 mt-1">
                {stats?.machinesRequiringService ?? 0}
              </h3>
              <p className="text-[11px] text-amber-600 font-bold mt-1">
                Full / Maintenance Alert
              </p>
            </div>
            <div className="w-11 h-11 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-600">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Recyclers</p>
              <h3 className="text-3xl font-black text-slate-900 mt-1">{stats?.totalUsers ?? 0}</h3>
              <p className="text-[11px] text-slate-400 mt-1">Registered citizen accounts</p>
            </div>
            <div className="w-11 h-11 rounded-2xl bg-indigo-100 flex items-center justify-center text-indigo-600">
              <Users className="w-5 h-5" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Bottles Recycled</p>
              <h3 className="text-3xl font-black text-emerald-600 mt-1">
                {stats?.totalBottlesCollected ?? 0}
              </h3>
              <p className="text-[11px] text-slate-400 mt-1">
                {stats?.totalGreenCoinsGenerated ?? 0} Coins Issued
              </p>
            </div>
            <div className="w-11 h-11 rounded-2xl bg-sky-100 flex items-center justify-center text-sky-600">
              <Recycle className="w-5 h-5" />
            </div>
          </div>
        </Card>
      </div>

      {/* Recharts Analytics Component */}
      <DashboardCharts
        districtData={districtData}
        weeklyTrendData={weeklyTrendData}
        topMachinesData={topMachinesData}
      />
    </div>
  );
}
