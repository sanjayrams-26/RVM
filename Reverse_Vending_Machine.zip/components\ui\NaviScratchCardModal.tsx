'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Trophy, Flame, CheckCircle2, RefreshCw, Zap } from 'lucide-react';
import { NaviRewardCalculation, BottleRewardResult } from '@/lib/naviRewardEngine';

interface NaviScratchCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  rewardData: NaviRewardCalculation | null;
  machineName?: string;
}

export function NaviScratchCardModal({
  isOpen,
  onClose,
  rewardData,
  machineName = 'RVM Machine',
}: NaviScratchCardModalProps) {
  const [isRevealed, setIsRevealed] = useState(false);
  const [displayedCoins, setDisplayedCoins] = useState(0);
  const [scratchProgress, setScratchProgress] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isScratchingRef = useRef(false);

  // Reset state on modal open
  useEffect(() => {
    if (isOpen) {
      setIsRevealed(false);
      setDisplayedCoins(0);
      setScratchProgress(0);
    }
  }, [isOpen, rewardData]);

  // Initialize Canvas Scratch Cover
  useEffect(() => {
    if (!isOpen || isRevealed) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fill with metallic gold scratch coating
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, '#D97706');
    gradient.addColorStop(0.5, '#FBBF24');
    gradient.addColorStop(1, '#B45309');

    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add pattern text / sparkles to scratch layer
    ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.font = 'bold 16px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('✨ SCRATCH HERE WITH CURSOR ✨', canvas.width / 2, canvas.height / 2 - 10);
    ctx.font = '12px sans-serif';
    ctx.fillText('NAVI APP RANDOM REWARD CARD', canvas.width / 2, canvas.height / 2 + 15);
  }, [isOpen, isRevealed]);

  // Coin counter animation on reveal
  useEffect(() => {
    if (!isRevealed || !rewardData) return;

    let start = 0;
    const end = rewardData.totalCoinsEarned;
    const duration = 1200; // ms
    const increment = Math.max(1, Math.ceil(end / (duration / 30)));

    const timer = setInterval(() => {
      start += increment;
      if (start >= end) {
        setDisplayedCoins(end);
        clearInterval(timer);
      } else {
        setDisplayedCoins(start);
      }
    }, 30);

    return () => clearInterval(timer);
  }, [isRevealed, rewardData]);

  if (!isOpen || !rewardData) return null;

  // Scratch mouse/touch events
  const scratch = (x: number, y: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, 28, 0, Math.PI * 2);
    ctx.fill();

    // Check scratched percentage
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    let transparentCount = 0;
    for (let i = 3; i < pixels.length; i += 4) {
      if (pixels[i] === 0) transparentCount++;
    }
    const percent = Math.round((transparentCount / (pixels.length / 4)) * 100);
    setScratchProgress(percent);

    if (percent > 45 && !isRevealed) {
      setIsRevealed(true);
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isScratchingRef.current = true;
    const rect = e.currentTarget.getBoundingClientRect();
    scratch(e.clientX - rect.left, e.clientY - rect.top);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isScratchingRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    scratch(e.clientX - rect.left, e.clientY - rect.top);
  };

  const handleMouseUp = () => {
    isScratchingRef.current = false;
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const touch = e.touches[0];
    scratch(touch.clientX - rect.left, touch.clientY - rect.top);
  };

  const forceReveal = () => {
    setIsRevealed(true);
    setScratchProgress(100);
  };

  const getTierBadge = (tier: string) => {
    switch (tier) {
      case 'jackpot':
        return {
          label: '🎉 MEGA JACKPOT',
          bg: 'bg-gradient-to-r from-purple-600 via-pink-600 to-amber-500 text-white',
          border: 'border-amber-300',
        };
      case 'gold':
        return {
          label: '🌟 GOLDEN LUCKY ROLL',
          bg: 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-900',
          border: 'border-yellow-200',
        };
      case 'silver':
        return {
          label: '⚡ SILVER BOOST',
          bg: 'bg-gradient-to-r from-slate-600 to-slate-400 text-white',
          border: 'border-slate-300',
        };
      default:
        return {
          label: '🌱 RECYCLER BRONZE',
          bg: 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white',
          border: 'border-emerald-300',
        };
    }
  };

  const topBadge = getTierBadge(rewardData.highestTier);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden border border-amber-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 p-6 text-white text-center relative overflow-hidden shrink-0">
          <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4 w-24 h-24 bg-amber-500/20 rounded-full blur-xl pointer-events-none" />
          <div className="flex justify-center items-center space-x-2 text-amber-400 text-xs font-black uppercase tracking-widest mb-1">
            <Sparkles className="w-4 h-4 animate-spin-slow" />
            <span>Navi App Reward Algorithm</span>
            <Sparkles className="w-4 h-4 animate-spin-slow" />
          </div>
          <h2 className="text-2xl font-black">Scratch to Claim Coins!</h2>
          <p className="text-xs text-slate-300 mt-1">
            {rewardData.totalBottles} Bottle{rewardData.totalBottles > 1 ? 's' : ''} Deposited at {machineName}
          </p>
        </div>

        {/* Card Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Scratch Card Box */}
          <div className="relative w-full h-52 rounded-2xl overflow-hidden shadow-inner border-2 border-amber-200 bg-gradient-to-br from-amber-50 via-emerald-50 to-teal-50 flex flex-col items-center justify-center p-4 text-center">
            {/* Scratched Revealed Content */}
            <div className={`transition-all duration-700 flex flex-col items-center ${isRevealed ? 'opacity-100 scale-100' : 'opacity-40 scale-95'}`}>
              <span className={`px-4 py-1.5 rounded-full text-xs font-black tracking-wider shadow-md mb-2 ${topBadge.bg}`}>
                {topBadge.label}
              </span>

              <div className="text-5xl font-black text-slate-900 tracking-tight flex items-baseline justify-center space-x-2 my-1">
                <span className="text-amber-500">+{displayedCoins}</span>
                <span className="text-sm font-extrabold text-slate-500 uppercase">Green Coins</span>
              </div>

              <div className="flex items-center space-x-2 text-xs font-bold text-slate-600 mt-1">
                <span>Base: {rewardData.baseCoins} coins</span>
                {rewardData.streakBonus > 0 && (
                  <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full flex items-center">
                    <Flame className="w-3.5 h-3.5 mr-1 text-amber-600 fill-amber-500" />
                    +{rewardData.streakBonus} Streak Bonus
                  </span>
                )}
              </div>
            </div>

            {/* Canvas Overlay for Scratching */}
            {!isRevealed && (
              <canvas
                ref={canvasRef}
                width={360}
                height={190}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                onTouchMove={handleTouchMove}
                className="absolute inset-0 w-full h-full cursor-pointer touch-none z-10 rounded-2xl"
              />
            )}
          </div>

          {/* Quick Reveal Button if not revealed */}
          {!isRevealed && (
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400 font-semibold">Scratched: {scratchProgress}%</span>
              <button
                onClick={forceReveal}
                className="text-amber-700 font-extrabold hover:underline flex items-center"
              >
                <Zap className="w-3.5 h-3.5 mr-1" /> Tap to Instant Reveal
              </button>
            </div>
          )}

          {/* Per Bottle Dynamic Coin Breakdown */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center">
                <Trophy className="w-4 h-4 text-amber-500 mr-1.5" /> Navi Algorithm Per-Bottle Breakdown
              </h3>
              <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                Randomized RNG
              </span>
            </div>

            <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
              {rewardData.bottleBreakdown.map((item: BottleRewardResult) => {
                const tierInfo = getTierBadge(item.tier);
                return (
                  <div
                    key={item.bottleNumber}
                    className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                      item.isJackpot
                        ? 'bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200'
                        : item.tier === 'gold'
                        ? 'bg-amber-50/70 border-amber-200'
                        : item.tier === 'silver'
                        ? 'bg-slate-50 border-slate-200'
                        : 'bg-emerald-50/50 border-emerald-100'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs ${
                        item.tier === 'jackpot' ? 'bg-purple-600 text-white' :
                        item.tier === 'gold' ? 'bg-amber-500 text-white' :
                        item.tier === 'silver' ? 'bg-slate-600 text-white' : 'bg-emerald-600 text-white'
                      }`}>
                        #{item.bottleNumber}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800">{item.message}</p>
                        <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide">
                          Bottle #{item.bottleNumber} Insert
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-black text-emerald-700">+{item.coins} Coins</span>
                      <p className="text-[9px] uppercase font-bold text-slate-400">{item.tier}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Navi Algorithm Note */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-[11px] text-slate-500 space-y-1">
            <p className="font-bold text-slate-700">💡 How Navi Algorithm calculated your coins:</p>
            <p>
              Each bottle gets a probabilistic random coin roll (Bronze 65%, Silver 22%, Gold 10%, Jackpot 3%).
              Depositing 3+ bottles grants a Navi Streak multiplier boost!
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white font-extrabold text-sm shadow-md hover:from-emerald-700 hover:to-teal-800 transition-all flex items-center justify-center"
          >
            <CheckCircle2 className="w-4 h-4 mr-2" /> Collect {rewardData.totalCoinsEarned} Green Coins
          </button>
        </div>
      </div>
    </div>
  );
}
