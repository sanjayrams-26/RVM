'use client';

import React, { useState } from 'react';
import useSWR from 'swr';
import { Wrench, Plus, CheckCircle2, Clock } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function AdminMaintenancePage() {
  const { data: mainData, isLoading, mutate } = useSWR('/api/maintenance', fetcher);
  const { data: machinesData } = useSWR('/api/machines', fetcher);
  const { data: employeesData } = useSWR('/api/employees', fetcher);

  const maintenance = mainData?.maintenance || [];
  const machines = machinesData?.machines || [];
  const employees = employeesData?.employees || [];

  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [serviceType, setServiceType] = useState('collection');
  const [problemReported, setProblemReported] = useState('');
  const [remarks, setRemarks] = useState('');

  const [statusMsg, setStatusMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setStatusMsg('');

    try {
      const res = await fetch('/api/maintenance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          machine: selectedMachine,
          employee: selectedEmployee,
          serviceType,
          problemReported,
          remarks,
        }),
      });

      const resData = await res.json();
      if (!res.ok) {
        setStatusMsg(resData.error?.message || 'Failed to create task');
      } else {
        setStatusMsg('Task created and assigned successfully!');
        mutate();
        setTimeout(() => {
          setIsTaskModalOpen(false);
          setStatusMsg('');
        }, 1200);
      }
    } catch {
      setStatusMsg('An error occurred.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">Maintenance & Servicing Hub</h1>
          <p className="text-xs text-slate-500 mt-1">Assign collection routes, repairs, and monitor completed service actions</p>
        </div>
        <Button onClick={() => setIsTaskModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" /> Dispatch Service Task
        </Button>
      </div>

      <Card>
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">Loading maintenance records...</div>
        ) : maintenance.length === 0 ? (
          <div className="text-center py-12 text-slate-400">No maintenance records found.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                  <th className="py-3.5 px-4">Service Date</th>
                  <th className="py-3.5 px-4">Machine ID</th>
                  <th className="py-3.5 px-4">Service Type</th>
                  <th className="py-3.5 px-4">Assigned Tech</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Waste Collected</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {maintenance.map((m: any) => (
                  <tr key={m._id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 text-slate-600 font-medium">
                      {new Date(m.serviceDate || m.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-800">
                      {m.machine?.machineId} ({m.machine?.location?.district})
                    </td>
                    <td className="py-3.5 px-4 uppercase text-xs font-bold text-indigo-600">
                      {m.serviceType}
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-700">
                      {m.employee?.name} ({m.employee?.employeeId})
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`text-xs font-bold px-2.5 py-1 rounded-full uppercase border ${
                          m.status === 'completed'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : m.status === 'in_progress'
                            ? 'bg-amber-50 text-amber-700 border-amber-200'
                            : 'bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                      >
                        {m.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-emerald-600">
                      {m.wasteCollected !== undefined ? `${m.wasteCollected} bottles` : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Dispatch Task Modal */}
      <Modal isOpen={isTaskModalOpen} onClose={() => setIsTaskModalOpen(false)} title="Dispatch Maintenance Task">
        <form onSubmit={handleCreateTask} className="space-y-4">
          {statusMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl">
              {statusMsg}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Target Machine</label>
            <select
              required
              value={selectedMachine}
              onChange={(e) => setSelectedMachine(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">-- Choose Machine --</option>
              {machines.map((m: any) => (
                <option key={m._id} value={m._id}>
                  {m.machineId} ({m.name}) - Storage: {m.storagePercent}%
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Assign Tech Staff</label>
            <select
              required
              value={selectedEmployee}
              onChange={(e) => setSelectedEmployee(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">-- Select Field Technician --</option>
              {employees.map((emp: any) => (
                <option key={emp._id} value={emp._id}>
                  {emp.name} ({emp.employeeId})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Service Action Type</label>
            <select
              value={serviceType}
              onChange={(e) => setServiceType(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="collection">Waste Collection & Bin Reset</option>
              <option value="repair">Sensor / Mechanical Repair</option>
              <option value="cleaning">Sanitation & Cleaning</option>
              <option value="inspection">Routine Inspection</option>
              <option value="other">Other Maintenance</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Problem / Work Order Description</label>
            <textarea
              rows={2}
              placeholder="Capacity reached 90% alert..."
              value={problemReported}
              onChange={(e) => setProblemReported(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <Button type="submit" isLoading={isSubmitting} className="w-full py-3">
            Dispatch Work Order
          </Button>
        </form>
      </Modal>
    </div>
  );
}
