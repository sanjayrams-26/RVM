import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IGreenCoinLedger extends Document {
  user: mongoose.Types.ObjectId;
  type: 'earn' | 'redeem' | 'withdraw' | 'adjustment';
  amount: number;
  balanceAfter?: number;
  relatedTransaction?: mongoose.Types.ObjectId;
  relatedMachine?: mongoose.Types.ObjectId;
  note?: string;
  createdAt: Date;
  updatedAt: Date;
}

const GreenCoinLedgerSchema = new Schema<IGreenCoinLedger>(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    type: {
      type: String,
      enum: ['earn', 'redeem', 'withdraw', 'adjustment'],
      required: true,
    },
    amount: { type: Number, required: true },
    balanceAfter: Number,
    relatedTransaction: { type: Schema.Types.ObjectId, ref: 'Transaction' },
    relatedMachine: { type: Schema.Types.ObjectId, ref: 'Machine' },
    note: String,
  },
  { timestamps: true }
);

GreenCoinLedgerSchema.index({ user: 1, createdAt: -1 });

export const GreenCoinLedger: Model<IGreenCoinLedger> =
  mongoose.models.GreenCoinLedger ||
  mongoose.model<IGreenCoinLedger>('GreenCoinLedger', GreenCoinLedgerSchema);
