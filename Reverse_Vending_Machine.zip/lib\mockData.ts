export interface MockLocation {
  _id: string;
  state: string;
  district: string;
  area: string;
  exactLocation: string;
  gps: { lat: number; lng: number };
  type: string;
}

export interface MockMachine {
  _id: string;
  machineId: string;
  name: string;
  location: MockLocation;
  gps: { lat: number; lng: number };
  status: 'online' | 'offline' | 'active' | 'full' | 'under_maintenance' | 'damaged' | 'inactive';
  storageCapacity: number;
  currentStorageLevel: number;
  storagePercent: number;
  bottlesCollectedTotal: number;
  uniqueUsersCount: number;
  totalGreenCoinsGenerated: number;
  assignedEmployee?: { _id: string; name: string; employeeId: string; mobile: string };
  installationDate: string;
  lastMaintenanceDate?: string;
  nextMaintenanceDate?: string;
  connectivity: 'connected' | 'disconnected';
  sensorStatus: 'ok' | 'error' | 'unknown';
  powerStatus: 'on' | 'off' | 'battery';
  lastSyncAt: string;
  errorLog: Array<{ code: string; message: string; timestamp: string }>;
}

export interface MockEmployee {
  _id: string;
  name: string;
  email: string;
  mobile: string;
  employeeId: string;
  assignedMachines: any[];
  role: 'employee';
  isActive: boolean;
  joinDate: string;
}

export interface MockUser {
  _id: string;
  name: string;
  email: string;
  mobile: string;
  role: 'user';
  registrationDate: string;
  totalBottlesRecycled: number;
  totalGreenCoinsEarned: number;
  greenCoinsRedeemed: number;
  greenCoinsWithdrawn: number;
  currentBalance: number;
  isActive: boolean;
}

export interface MockTransaction {
  _id: string;
  user: { _id: string; name: string; email: string; mobile: string };
  machine: MockMachine;
  bottlesDeposited: number;
  coinsEarned: number;
  timestamp: string;
  status: 'success' | 'failed' | 'flagged';
}

export interface MockAlert {
  _id: string;
  machine: MockMachine;
  type: 'storage' | 'maintenance' | 'offline' | 'error' | 'service_required';
  message: string;
  severity: 'info' | 'warning' | 'critical';
  isResolved: boolean;
  assignedEmployee?: { _id: string; name: string; employeeId: string };
  createdAt: string;
}

export interface MockMaintenance {
  _id: string;
  machine: MockMachine;
  employee: MockEmployee;
  serviceDate: string;
  serviceType: 'collection' | 'repair' | 'cleaning' | 'inspection' | 'other';
  problemReported?: string;
  actionTaken?: string;
  wasteCollected?: number;
  completionTime?: string;
  remarks?: string;
  status: 'assigned' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: string;
}

// Data Sets
const BASE_MOCK_LOCATIONS: MockLocation[] = [
  { _id: 'loc_1', state: 'Tamil Nadu', district: 'Coimbatore', area: 'Gandhipuram', exactLocation: 'Central Bus Stand Entrance', gps: { lat: 11.0168, lng: 76.9558 }, type: 'station' },
  { _id: 'loc_2', state: 'Tamil Nadu', district: 'Coimbatore', area: 'RS Puram', exactLocation: 'DB Road Shopping Complex', gps: { lat: 11.0062, lng: 76.9507 }, type: 'mall' },
  { _id: 'loc_3', state: 'Tamil Nadu', district: 'Coimbatore', area: 'Tidel Park', exactLocation: 'ELCOT IT SEZ Main Gate', gps: { lat: 11.0287, lng: 77.0275 }, type: 'public_place' },
  { _id: 'loc_4', state: 'Tamil Nadu', district: 'Coimbatore', area: 'Peelamedu', exactLocation: 'PSG Tech Campus Plaza', gps: { lat: 11.0247, lng: 77.0028 }, type: 'street' },
  { _id: 'loc_5', state: 'Tamil Nadu', district: 'Chennai', area: 'T Nagar', exactLocation: 'Ranganathan Street Junction', gps: { lat: 13.0418, lng: 80.2341 }, type: 'street' },
  { _id: 'loc_6', state: 'Tamil Nadu', district: 'Chennai', area: 'Velachery', exactLocation: 'Phoenix Marketcity Mall', gps: { lat: 12.9915, lng: 80.217 }, type: 'mall' },
  { _id: 'loc_7', state: 'Tamil Nadu', district: 'Chennai', area: 'Central Metro', exactLocation: 'Subway Exit Gate 3', gps: { lat: 13.0827, lng: 80.2707 }, type: 'station' },
  { _id: 'loc_8', state: 'Tamil Nadu', district: 'Chennai', area: 'Marina Beach', exactLocation: 'Light House Promenade', gps: { lat: 13.0396, lng: 80.2778 }, type: 'public_place' },
  { _id: 'loc_9', state: 'Tamil Nadu', district: 'Madurai', area: 'Meenakshi Temple', exactLocation: 'East Gopuram Entrance Plaza', gps: { lat: 9.9195, lng: 78.1193 }, type: 'public_place' },
  { _id: 'loc_10', state: 'Tamil Nadu', district: 'Madurai', area: 'KK Nagar', exactLocation: 'District Court Walkway', gps: { lat: 9.9329, lng: 78.1408 }, type: 'street' },
  { _id: 'loc_11', state: 'Tamil Nadu', district: 'Madurai', area: 'Periyar Bus Stand', exactLocation: 'Bay 4 Departure', gps: { lat: 9.9167, lng: 78.1126 }, type: 'station' },
];

export const MOCK_EMPLOYEES: MockEmployee[] = [
  { _id: 'emp_1', name: 'Ramesh Kumar', email: 'ramesh@rvm.org', mobile: '9876543210', employeeId: 'EMP-0001', assignedMachines: [], role: 'employee', isActive: true, joinDate: '2025-01-15T00:00:00Z' },
  { _id: 'emp_2', name: 'Suresh Babu', email: 'suresh@rvm.org', mobile: '9876543211', employeeId: 'EMP-0002', assignedMachines: [], role: 'employee', isActive: true, joinDate: '2025-02-01T00:00:00Z' },
  { _id: 'emp_3', name: 'Karthik Raja', email: 'karthik@rvm.org', mobile: '9876543212', employeeId: 'EMP-0003', assignedMachines: [], role: 'employee', isActive: true, joinDate: '2025-03-10T00:00:00Z' },
  { _id: 'emp_4', name: 'Anitha Selvam', email: 'anitha@rvm.org', mobile: '9876543213', employeeId: 'EMP-0004', assignedMachines: [], role: 'employee', isActive: true, joinDate: '2025-04-05T00:00:00Z' },
  { _id: 'emp_5', name: 'Vijay Anand', email: 'vijay@rvm.org', mobile: '9876543214', employeeId: 'EMP-0005', assignedMachines: [], role: 'employee', isActive: true, joinDate: '2025-05-12T00:00:00Z' },
];

const BASE_MOCK_MACHINES: MockMachine[] = [
  {
    _id: 'mach_1',
    machineId: 'RVM-CBE-001',
    name: 'Gandhipuram Smart Hub 1',
    location: BASE_MOCK_LOCATIONS[0],
    gps: BASE_MOCK_LOCATIONS[0].gps,
    status: 'full',
    storageCapacity: 500,
    currentStorageLevel: 460,
    storagePercent: 92,
    bottlesCollectedTotal: 3420,
    uniqueUsersCount: 142,
    totalGreenCoinsGenerated: 17100,
    assignedEmployee: { _id: MOCK_EMPLOYEES[0]._id, name: MOCK_EMPLOYEES[0].name, employeeId: MOCK_EMPLOYEES[0].employeeId, mobile: MOCK_EMPLOYEES[0].mobile },
    installationDate: '2025-01-10T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
  {
    _id: 'mach_2',
    machineId: 'RVM-CBE-002',
    name: 'RS Puram Shopping RVM',
    location: BASE_MOCK_LOCATIONS[1],
    gps: BASE_MOCK_LOCATIONS[1].gps,
    status: 'active',
    storageCapacity: 500,
    currentStorageLevel: 210,
    storagePercent: 42,
    bottlesCollectedTotal: 1890,
    uniqueUsersCount: 88,
    totalGreenCoinsGenerated: 9450,
    assignedEmployee: { _id: MOCK_EMPLOYEES[0]._id, name: MOCK_EMPLOYEES[0].name, employeeId: MOCK_EMPLOYEES[0].employeeId, mobile: MOCK_EMPLOYEES[0].mobile },
    installationDate: '2025-01-20T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
  {
    _id: 'mach_3',
    machineId: 'RVM-CBE-003',
    name: 'Tidel Park Eco Station',
    location: BASE_MOCK_LOCATIONS[2],
    gps: BASE_MOCK_LOCATIONS[2].gps,
    status: 'active',
    storageCapacity: 600,
    currentStorageLevel: 150,
    storagePercent: 25,
    bottlesCollectedTotal: 2540,
    uniqueUsersCount: 110,
    totalGreenCoinsGenerated: 12700,
    assignedEmployee: { _id: MOCK_EMPLOYEES[1]._id, name: MOCK_EMPLOYEES[1].name, employeeId: MOCK_EMPLOYEES[1].employeeId, mobile: MOCK_EMPLOYEES[1].mobile },
    installationDate: '2025-02-01T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
  {
    _id: 'mach_4',
    machineId: 'RVM-CBE-004',
    name: 'Peelamedu PSG Tech RVM',
    location: BASE_MOCK_LOCATIONS[3],
    gps: BASE_MOCK_LOCATIONS[3].gps,
    status: 'active',
    storageCapacity: 400,
    currentStorageLevel: 330,
    storagePercent: 82.5,
    bottlesCollectedTotal: 1200,
    uniqueUsersCount: 65,
    totalGreenCoinsGenerated: 6000,
    assignedEmployee: { _id: MOCK_EMPLOYEES[1]._id, name: MOCK_EMPLOYEES[1].name, employeeId: MOCK_EMPLOYEES[1].employeeId, mobile: MOCK_EMPLOYEES[1].mobile },
    installationDate: '2025-02-15T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
  {
    _id: 'mach_5',
    machineId: 'RVM-CHN-001',
    name: 'T Nagar Junction Recycler',
    location: BASE_MOCK_LOCATIONS[4],
    gps: BASE_MOCK_LOCATIONS[4].gps,
    status: 'full',
    storageCapacity: 500,
    currentStorageLevel: 480,
    storagePercent: 96,
    bottlesCollectedTotal: 5120,
    uniqueUsersCount: 230,
    totalGreenCoinsGenerated: 25600,
    assignedEmployee: { _id: MOCK_EMPLOYEES[2]._id, name: MOCK_EMPLOYEES[2].name, employeeId: MOCK_EMPLOYEES[2].employeeId, mobile: MOCK_EMPLOYEES[2].mobile },
    installationDate: '2025-01-05T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
  {
    _id: 'mach_6',
    machineId: 'RVM-CHN-002',
    name: 'Velachery Mall RVM',
    location: BASE_MOCK_LOCATIONS[5],
    gps: BASE_MOCK_LOCATIONS[5].gps,
    status: 'active',
    storageCapacity: 500,
    currentStorageLevel: 90,
    storagePercent: 18,
    bottlesCollectedTotal: 2900,
    uniqueUsersCount: 140,
    totalGreenCoinsGenerated: 14500,
    assignedEmployee: { _id: MOCK_EMPLOYEES[2]._id, name: MOCK_EMPLOYEES[2].name, employeeId: MOCK_EMPLOYEES[2].employeeId, mobile: MOCK_EMPLOYEES[2].mobile },
    installationDate: '2025-01-25T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
  {
    _id: 'mach_7',
    machineId: 'RVM-CHN-003',
    name: 'Chennai Central Metro Hub',
    location: BASE_MOCK_LOCATIONS[6],
    gps: BASE_MOCK_LOCATIONS[6].gps,
    status: 'active',
    storageCapacity: 800,
    currentStorageLevel: 320,
    storagePercent: 40,
    bottlesCollectedTotal: 6400,
    uniqueUsersCount: 310,
    totalGreenCoinsGenerated: 32000,
    assignedEmployee: { _id: MOCK_EMPLOYEES[3]._id, name: MOCK_EMPLOYEES[3].name, employeeId: MOCK_EMPLOYEES[3].employeeId, mobile: MOCK_EMPLOYEES[3].mobile },
    installationDate: '2025-01-01T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
  {
    _id: 'mach_8',
    machineId: 'RVM-CHN-004',
    name: 'Marina Beach Eco Kiosk',
    location: BASE_MOCK_LOCATIONS[7],
    gps: BASE_MOCK_LOCATIONS[7].gps,
    status: 'offline',
    storageCapacity: 500,
    currentStorageLevel: 120,
    storagePercent: 24,
    bottlesCollectedTotal: 1400,
    uniqueUsersCount: 75,
    totalGreenCoinsGenerated: 7000,
    assignedEmployee: { _id: MOCK_EMPLOYEES[3]._id, name: MOCK_EMPLOYEES[3].name, employeeId: MOCK_EMPLOYEES[3].employeeId, mobile: MOCK_EMPLOYEES[3].mobile },
    installationDate: '2025-02-10T00:00:00Z',
    connectivity: 'disconnected',
    sensorStatus: 'error',
    powerStatus: 'off',
    lastSyncAt: '2026-08-10T12:00:00Z',
    errorLog: [{ code: 'ERR_NET_DISCONNECT', message: 'Radio signal lost', timestamp: '2026-08-10T12:00:00Z' }],
  },
  {
    _id: 'mach_9',
    machineId: 'RVM-MDU-001',
    name: 'Meenakshi Temple East Plaza',
    location: BASE_MOCK_LOCATIONS[8],
    gps: BASE_MOCK_LOCATIONS[8].gps,
    status: 'active',
    storageCapacity: 500,
    currentStorageLevel: 260,
    storagePercent: 52,
    bottlesCollectedTotal: 2100,
    uniqueUsersCount: 95,
    totalGreenCoinsGenerated: 10500,
    assignedEmployee: { _id: MOCK_EMPLOYEES[4]._id, name: MOCK_EMPLOYEES[4].name, employeeId: MOCK_EMPLOYEES[4].employeeId, mobile: MOCK_EMPLOYEES[4].mobile },
    installationDate: '2025-02-20T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
  {
    _id: 'mach_10',
    machineId: 'RVM-MDU-002',
    name: 'KK Nagar Court RVM',
    location: BASE_MOCK_LOCATIONS[9],
    gps: BASE_MOCK_LOCATIONS[9].gps,
    status: 'active',
    storageCapacity: 500,
    currentStorageLevel: 110,
    storagePercent: 22,
    bottlesCollectedTotal: 980,
    uniqueUsersCount: 45,
    totalGreenCoinsGenerated: 4900,
    assignedEmployee: { _id: MOCK_EMPLOYEES[4]._id, name: MOCK_EMPLOYEES[4].name, employeeId: MOCK_EMPLOYEES[4].employeeId, mobile: MOCK_EMPLOYEES[4].mobile },
    installationDate: '2025-03-01T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
  {
    _id: 'mach_11',
    machineId: 'RVM-MDU-003',
    name: 'Periyar Bus Stand Unit',
    location: BASE_MOCK_LOCATIONS[10],
    gps: BASE_MOCK_LOCATIONS[10].gps,
    status: 'active',
    storageCapacity: 500,
    currentStorageLevel: 420,
    storagePercent: 84,
    bottlesCollectedTotal: 3100,
    uniqueUsersCount: 160,
    totalGreenCoinsGenerated: 15500,
    assignedEmployee: { _id: MOCK_EMPLOYEES[4]._id, name: MOCK_EMPLOYEES[4].name, employeeId: MOCK_EMPLOYEES[4].employeeId, mobile: MOCK_EMPLOYEES[4].mobile },
    installationDate: '2025-03-05T00:00:00Z',
    connectivity: 'connected',
    sensorStatus: 'ok',
    powerStatus: 'on',
    lastSyncAt: new Date().toISOString(),
    errorLog: [],
  },
];

type ExtraDistrictSeed = {
  district: string;
  code: string;
  sites: Array<{
    area: string;
    exactLocation: string;
    gps: { lat: number; lng: number };
    type: string;
    machineName: string;
  }>;
};

const EXTRA_DISTRICT_SEEDS: ExtraDistrictSeed[] = [
  {
    district: 'Tiruchirappalli',
    code: 'TRY',
    sites: [
      { area: 'Cantonment', exactLocation: 'Chatram Bus Stand Entry Plaza', gps: { lat: 10.7905, lng: 78.7047 }, type: 'station', machineName: 'Cantonment Transit RVM' },
      { area: 'Thillai Nagar', exactLocation: 'Centrally Located Shopping Arcade', gps: { lat: 10.8048, lng: 78.6875 }, type: 'mall', machineName: 'Thillai Nagar Retail RVM' },
      { area: 'Srirangam', exactLocation: 'Temple East Gopuram Walkway', gps: { lat: 10.8528, lng: 78.6912 }, type: 'public_place', machineName: 'Srirangam Heritage RVM' },
    ],
  },
  {
    district: 'Salem',
    code: 'SLM',
    sites: [
      { area: 'Five Road', exactLocation: 'Five Road Junction Plaza', gps: { lat: 11.6643, lng: 78.146 }, type: 'street', machineName: 'Five Road Junction RVM' },
      { area: 'Hasthampatti', exactLocation: 'Collectorate Campus Gate', gps: { lat: 11.6751, lng: 78.1571 }, type: 'public_place', machineName: 'Hasthampatti Civic RVM' },
      { area: 'Fairlands', exactLocation: 'Fairlands Shopping Street', gps: { lat: 11.663, lng: 78.1513 }, type: 'mall', machineName: 'Fairlands Market RVM' },
    ],
  },
  {
    district: 'Tirunelveli',
    code: 'TVL',
    sites: [
      { area: 'Palayamkottai', exactLocation: 'Medical College Road Plaza', gps: { lat: 8.7139, lng: 77.7567 }, type: 'street', machineName: 'Palayamkottai Campus RVM' },
      { area: 'Tirunelveli Junction', exactLocation: 'Railway Station Main Forecourt', gps: { lat: 8.7252, lng: 77.6848 }, type: 'station', machineName: 'Junction Forecourt RVM' },
      { area: 'Vannarpettai', exactLocation: 'Vannarpettai Market Entrance', gps: { lat: 8.7088, lng: 77.7178 }, type: 'public_place', machineName: 'Vannarpettai Market RVM' },
    ],
  },
  {
    district: 'Erode',
    code: 'ERD',
    sites: [
      { area: 'PS Park', exactLocation: 'PS Park Bus Stop Plaza', gps: { lat: 11.341, lng: 77.717 }, type: 'station', machineName: 'PS Park Transit RVM' },
      { area: 'Perundurai Road', exactLocation: 'Perundurai Road Retail Cluster', gps: { lat: 11.3308, lng: 77.7087 }, type: 'mall', machineName: 'Perundurai Road RVM' },
      { area: 'Sathy Road', exactLocation: 'Sathy Road Community Center', gps: { lat: 11.3586, lng: 77.6762 }, type: 'public_place', machineName: 'Sathy Road Community RVM' },
    ],
  },
  {
    district: 'Thanjavur',
    code: 'TNJ',
    sites: [
      { area: 'New Bus Stand', exactLocation: 'New Bus Stand Entry Plaza', gps: { lat: 10.7866, lng: 79.1378 }, type: 'station', machineName: 'New Bus Stand RVM' },
      { area: 'Mariamman Kovil', exactLocation: 'Temple Corridor Rest Point', gps: { lat: 10.7819, lng: 79.1398 }, type: 'public_place', machineName: 'Temple Corridor RVM' },
      { area: 'Raja Serfoji Road', exactLocation: 'Raja Serfoji Road Market Spine', gps: { lat: 10.7879, lng: 79.1327 }, type: 'street', machineName: 'Raja Serfoji Road RVM' },
    ],
  },
  {
    district: 'Vellore',
    code: 'VLR',
    sites: [
      { area: 'Katpadi', exactLocation: 'Katpadi Railway Forecourt', gps: { lat: 12.971, lng: 79.136 }, type: 'station', machineName: 'Katpadi Junction RVM' },
      { area: 'Sathuvachari', exactLocation: 'Sathuvachari Commercial Street', gps: { lat: 12.9195, lng: 79.139 }, type: 'street', machineName: 'Sathuvachari Market RVM' },
      { area: 'VIT Campus', exactLocation: 'VIT University Main Plaza', gps: { lat: 12.9698, lng: 79.1559 }, type: 'public_place', machineName: 'VIT Campus Eco RVM' },
    ],
  },
  {
    district: 'Tiruppur',
    code: 'TPR',
    sites: [
      { area: 'Avinashi Road', exactLocation: 'Avinashi Road Transit Hub', gps: { lat: 11.1085, lng: 77.3411 }, type: 'station', machineName: 'Avinashi Road RVM' },
      { area: 'P N Road', exactLocation: 'P N Road Textile Market Front', gps: { lat: 11.1041, lng: 77.3356 }, type: 'mall', machineName: 'P N Road Textile RVM' },
      { area: 'Dharapuram Road', exactLocation: 'Dharapuram Road Community Plaza', gps: { lat: 11.0789, lng: 77.3432 }, type: 'public_place', machineName: 'Dharapuram Road RVM' },
    ],
  },
];

const EXTRA_LOCATIONS: MockLocation[] = EXTRA_DISTRICT_SEEDS.flatMap((district, districtIndex) =>
  district.sites.map((site, siteIndex) => ({
    _id: `loc_${12 + districtIndex * 3 + siteIndex}`,
    state: 'Tamil Nadu',
    district: district.district,
    area: site.area,
    exactLocation: site.exactLocation,
    gps: site.gps,
    type: site.type,
  }))
);

const buildExtraMachines = (locations: MockLocation[]): MockMachine[] =>
  EXTRA_DISTRICT_SEEDS.flatMap((district, districtIndex) =>
    district.sites.map((site, siteIndex) => {
      const locationIndex = 11 + districtIndex * 3 + siteIndex;
      const location = locations[locationIndex];
      const employee = MOCK_EMPLOYEES[(districtIndex + siteIndex) % MOCK_EMPLOYEES.length];
      const machineOrdinal = 12 + districtIndex * 3 + siteIndex;
      const storageCapacity = siteIndex === 0 ? 400 : siteIndex === 1 ? 500 : 600;
      const currentStorageLevel = siteIndex === 0 ? 150 + districtIndex * 6 : siteIndex === 1 ? 420 - districtIndex * 4 : 110 + districtIndex * 5;
      const status: MockMachine['status'] = siteIndex === 0 ? 'active' : siteIndex === 1 ? 'full' : 'under_maintenance';
      const connectivity: MockMachine['connectivity'] = siteIndex === 2 ? 'disconnected' : 'connected';
      const sensorStatus: MockMachine['sensorStatus'] = siteIndex === 2 ? 'error' : 'ok';
      const powerStatus: MockMachine['powerStatus'] = siteIndex === 2 ? 'off' : 'on';
      const bottlesCollectedTotal = 1500 + districtIndex * 280 + siteIndex * 190;
      const uniqueUsersCount = 70 + districtIndex * 14 + siteIndex * 9;
      const totalGreenCoinsGenerated = bottlesCollectedTotal * 5;
      const storagePercent = Math.round((currentStorageLevel / storageCapacity) * 100);

      return {
        _id: `mach_${machineOrdinal}`,
        machineId: `RVM-${district.code}-${String(siteIndex + 1).padStart(3, '0')}`,
        name: site.machineName,
        location,
        gps: location.gps,
        status,
        storageCapacity,
        currentStorageLevel,
        storagePercent,
        bottlesCollectedTotal,
        uniqueUsersCount,
        totalGreenCoinsGenerated,
        assignedEmployee: { _id: employee._id, name: employee.name, employeeId: employee.employeeId, mobile: employee.mobile },
        installationDate: new Date(Date.UTC(2025, 2, 1 + districtIndex * 2 + siteIndex)).toISOString(),
        connectivity,
        sensorStatus,
        powerStatus,
        lastSyncAt: new Date().toISOString(),
        errorLog: siteIndex === 2 ? [{ code: 'ERR_NET_DISCONNECT', message: 'Radio signal lost', timestamp: '2026-08-10T12:00:00Z' }] : [],
      };
    })
  );

export const MOCK_LOCATIONS: MockLocation[] = [...BASE_MOCK_LOCATIONS, ...EXTRA_LOCATIONS];

export const MOCK_MACHINES: MockMachine[] = [...BASE_MOCK_MACHINES, ...buildExtraMachines(MOCK_LOCATIONS)];

export const MOCK_USERS: MockUser[] = [
  { _id: 'usr_1', name: 'Mohammed Suhail', email: 'user1@example.com', mobile: '9876543210', role: 'user', registrationDate: '2025-01-01T00:00:00Z', totalBottlesRecycled: 42, totalGreenCoinsEarned: 210, greenCoinsRedeemed: 50, greenCoinsWithdrawn: 0, currentBalance: 160, isActive: true },
  { _id: 'usr_2', name: 'Priya Dharshini', email: 'user2@example.com', mobile: '9876543211', role: 'user', registrationDate: '2025-01-10T00:00:00Z', totalBottlesRecycled: 80, totalGreenCoinsEarned: 400, greenCoinsRedeemed: 100, greenCoinsWithdrawn: 100, currentBalance: 200, isActive: true },
  { _id: 'usr_3', name: 'Arun Prakash', email: 'user3@example.com', mobile: '9876543212', role: 'user', registrationDate: '2025-01-15T00:00:00Z', totalBottlesRecycled: 120, totalGreenCoinsEarned: 600, greenCoinsRedeemed: 250, greenCoinsWithdrawn: 0, currentBalance: 350, isActive: true },
  { _id: 'usr_4', name: 'Deepa Lakshmi', email: 'user4@example.com', mobile: '9876543213', role: 'user', registrationDate: '2025-02-01T00:00:00Z', totalBottlesRecycled: 30, totalGreenCoinsEarned: 150, greenCoinsRedeemed: 0, greenCoinsWithdrawn: 0, currentBalance: 150, isActive: true },
  { _id: 'usr_5', name: 'Vijay Sundar', email: 'user5@example.com', mobile: '9876543214', role: 'user', registrationDate: '2025-02-14T00:00:00Z', totalBottlesRecycled: 95, totalGreenCoinsEarned: 475, greenCoinsRedeemed: 100, greenCoinsWithdrawn: 200, currentBalance: 175, isActive: true },
];

export const MOCK_TRANSACTIONS: MockTransaction[] = [
  { _id: 'tx_101', user: { _id: MOCK_USERS[0]._id, name: MOCK_USERS[0].name, email: MOCK_USERS[0].email, mobile: MOCK_USERS[0].mobile }, machine: MOCK_MACHINES[0], bottlesDeposited: 4, coinsEarned: 20, timestamp: '2026-08-10T10:15:00Z', status: 'success' },
  { _id: 'tx_102', user: { _id: MOCK_USERS[0]._id, name: MOCK_USERS[0].name, email: MOCK_USERS[0].email, mobile: MOCK_USERS[0].mobile }, machine: MOCK_MACHINES[1], bottlesDeposited: 6, coinsEarned: 30, timestamp: '2026-08-09T16:20:00Z', status: 'success' },
  { _id: 'tx_103', user: { _id: MOCK_USERS[1]._id, name: MOCK_USERS[1].name, email: MOCK_USERS[1].email, mobile: MOCK_USERS[1].mobile }, machine: MOCK_MACHINES[4], bottlesDeposited: 10, coinsEarned: 50, timestamp: '2026-08-09T14:10:00Z', status: 'success' },
  { _id: 'tx_104', user: { _id: MOCK_USERS[2]._id, name: MOCK_USERS[2].name, email: MOCK_USERS[2].email, mobile: MOCK_USERS[2].mobile }, machine: MOCK_MACHINES[6], bottlesDeposited: 12, coinsEarned: 60, timestamp: '2026-08-08T11:45:00Z', status: 'success' },
  { _id: 'tx_105', user: { _id: MOCK_USERS[3]._id, name: MOCK_USERS[3].name, email: MOCK_USERS[3].email, mobile: MOCK_USERS[3].mobile }, machine: MOCK_MACHINES[8], bottlesDeposited: 5, coinsEarned: 25, timestamp: '2026-08-07T09:30:00Z', status: 'success' },
];

export const MOCK_ALERTS: MockAlert[] = [
  {
    _id: 'alt_1',
    machine: MOCK_MACHINES[0],
    type: 'storage',
    message: 'Machine RVM-CBE-001 capacity reached 92% (460/500 bottles). Collection required.',
    severity: 'critical',
    isResolved: false,
    assignedEmployee: { _id: MOCK_EMPLOYEES[0]._id, name: MOCK_EMPLOYEES[0].name, employeeId: MOCK_EMPLOYEES[0].employeeId },
    createdAt: '2026-08-10T08:00:00Z',
  },
  {
    _id: 'alt_2',
    machine: MOCK_MACHINES[4],
    type: 'storage',
    message: 'Machine RVM-CHN-001 capacity reached 96% (480/500 bottles). Status set to FULL.',
    severity: 'critical',
    isResolved: false,
    assignedEmployee: { _id: MOCK_EMPLOYEES[2]._id, name: MOCK_EMPLOYEES[2].name, employeeId: MOCK_EMPLOYEES[2].employeeId },
    createdAt: '2026-08-10T09:30:00Z',
  },
  {
    _id: 'alt_3',
    machine: MOCK_MACHINES[7],
    type: 'offline',
    message: 'Machine RVM-CHN-004 lost connectivity. Last sync > 30 mins ago.',
    severity: 'critical',
    isResolved: false,
    assignedEmployee: { _id: MOCK_EMPLOYEES[3]._id, name: MOCK_EMPLOYEES[3].name, employeeId: MOCK_EMPLOYEES[3].employeeId },
    createdAt: '2026-08-10T12:00:00Z',
  },
];

export const MOCK_MAINTENANCE: MockMaintenance[] = [
  {
    _id: 'maint_1',
    machine: MOCK_MACHINES[0],
    employee: MOCK_EMPLOYEES[0],
    serviceDate: '2026-08-10T08:30:00Z',
    serviceType: 'collection',
    problemReported: 'Storage 92% capacity alert dispatched',
    status: 'assigned',
    createdAt: '2026-08-10T08:30:00Z',
  },
  {
    _id: 'maint_2',
    machine: MOCK_MACHINES[4],
    employee: MOCK_EMPLOYEES[2],
    serviceDate: '2026-08-10T09:45:00Z',
    serviceType: 'collection',
    problemReported: 'Full bin alert dispatched',
    status: 'in_progress',
    createdAt: '2026-08-10T09:45:00Z',
  },
  {
    _id: 'maint_3',
    machine: MOCK_MACHINES[2],
    employee: MOCK_EMPLOYEES[1],
    serviceDate: '2026-08-05T14:00:00Z',
    serviceType: 'cleaning',
    actionTaken: 'Emptied 300 bottles, cleaned conveyor lens.',
    wasteCollected: 300,
    status: 'completed',
    createdAt: '2026-08-05T14:00:00Z',
  },
];
