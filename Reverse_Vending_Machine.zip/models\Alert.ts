import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IAlert extends Document {
  machine: mongoose.Types.ObjectId;
  type: 'storage' | 'maintenance' | 'offline' | 'error' | 'service_required';
  message: string;
  severity: 'info' | 'warning' | 'critical';
  isResolved: boolean;
  assignedEmployee?: mongoose.Types.ObjectId;
  createdAt: Date;
  resolvedAt?: Date;
  updatedAt: Date;
}

const AlertSchema = new Schema<IAlert>(
  {
    machine: { type: Schema.Types.ObjectId, ref: 'Machine', required: true },
    type: {
      type: String,
      enum: ['storage', 'maintenance', 'offline', 'error', 'service_required'],
      required: true,
    },
    message: { type: String, required: true },
    severity: {
      type: String,
      enum: ['info', 'warning', 'critical'],
      default: 'warning',
    },
    isResolved: { type: Boolean, default: false },
    assignedEmployee: { type: Schema.Types.ObjectId, ref: 'Employee' },
    resolvedAt: Date,
  },
  { timestamps: true }
);

AlertSchema.index({ machine: 1, isResolved: 1 });
AlertSchema.index({ severity: 1, isResolved: 1 });

export const Alert: Model<IAlert> =
  mongoose.models.Alert || mongoose.model<IAlert>('Alert', AlertSchema);
