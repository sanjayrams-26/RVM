import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { Maintenance } from '@/models/Maintenance';
import { MOCK_MAINTENANCE } from '@/lib/mockData';

export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();
    const dbMaint = await Maintenance.find()
      .populate('employee', 'name email employeeId mobile')
      .populate({ path: 'machine', populate: { path: 'location' } })
      .sort({ createdAt: -1 });

    if (dbMaint.length > 0) {
      return NextResponse.json({ maintenance: dbMaint });
    }
  } catch (e) {
    console.warn('Serving mock maintenance fallback');
  }

  return NextResponse.json({ maintenance: MOCK_MAINTENANCE });
}

export async function POST(req: NextRequest) {
  try {
    await connectToDatabase();
    const body = await req.json();
    const task = await Maintenance.create(body);
    return NextResponse.json({ success: true, task }, { status: 201 });
  } catch (e) {
    const body = await req.json();
    const mockTask = { _id: `maint_${Date.now()}`, ...body, status: 'assigned', createdAt: new Date().toISOString() };
    MOCK_MAINTENANCE.unshift(mockTask as any);
    return NextResponse.json({ success: true, task: mockTask }, { status: 201 });
  }
}
